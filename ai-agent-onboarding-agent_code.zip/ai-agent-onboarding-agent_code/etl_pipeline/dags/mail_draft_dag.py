"""
Airflow DAG: Mail Drafting Scheduler
Runs daily at 9 AM IST (3:30 AM UTC) to draft and queue emails for candidates.

Checks JOB_TRACKER for:
1. Job type = mail sent (1), status = pending, ACTION_DATE <= today -> draft initial email
2. Job type = follow up (2), status = pending, ACTION_DATE <= today -> draft follow-up email
"""
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, date, timedelta
import os
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from etl_pipeline.models.schema import (
    JobTracker, CandidateInfo, DocumentTypeMaster, DocumentTracker, MailTypeMaster,
)

EXCEL_PATH = os.getenv("EXCEL_PATH", "/shared/excel_offer_tracker/Offer_tracker.xlsx")
DB_URI = os.getenv("DB_URI", "oracle+oracledb://user:pass@localhost:1521/?service_name=orcl")

default_args = {
    "owner": "hr_automation",
    "depends_on_past": False,
    "start_date": datetime(2023, 1, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

logger = logging.getLogger(__name__)


def _get_candidate_type_column(candidate_type_id: int) -> str:
    """Returns the DocumentTypeMaster column name for the candidate type."""
    return {1: "FRESHER", 2: "EXPERIENCE", 3: "DEV_PARTNER"}.get(candidate_type_id, "EXPERIENCE")


def _get_missing_docs(session, candidate_id: int, candidate_type_id: int) -> list:
    """Fetches the list of missing document names for a candidate."""
    col_name = _get_candidate_type_column(candidate_type_id)
    required_docs = session.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()

    tracked = session.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()
    verified_ids = {d.DOCUMENT_TYPE_ID for d in tracked if d.STATUS_ID in (5, 7)}

    return [doc.DOCUMENT_NAME for doc in required_docs if doc.DOCUMENT_TYPE_ID not in verified_ids]


def _get_mail_template(session, mail_type: str) -> str:
    """Fetches the mail template from MAIL_TYPE_MASTER."""
    record = session.query(MailTypeMaster).filter(
        MailTypeMaster.MAIL_TYPE == mail_type,
        MailTypeMaster.IS_ACTIVE == 1,
    ).first()
    return record.MAIL_DESCRIPTION if record else None


def _generate_draft(candidate_name: str, missing_docs: list, cin: str, mail_template: str = None) -> str:
    """
    Generates a draft email. Tries LLM first, falls back to template.
    """
    try:
        from mcp_server.draft_prepare.engine.helper_func import generate_draft
        return generate_draft(candidate_name, missing_docs, cin, mail_template)
    except Exception as e:
        logger.warning(f"LLM draft generation failed, using template: {e}")
        doc_list = "\n".join(f"- {doc}" for doc in missing_docs)
        return (
            f"Dear {candidate_name},\n\n"
            f"As part of your onboarding (CIN: {cin}), please submit the following documents:\n"
            f"{doc_list}\n\n"
            f"Please reply to this email with the documents attached. "
            f"Include your CIN in the subject line.\n\n"
            f"Regards,\nHR Onboarding Team"
        )


def mail_draft_task_callable():
    """
    Main task: queries JOB_TRACKER for pending mail/follow-up jobs where ACTION_DATE <= today.
    For each, generates a draft email and updates the job entry.
    """
    logger.info("Starting mail draft execution")

    engine = create_engine(DB_URI)
    Session = sessionmaker(bind=engine)
    session = Session()

    today = date.today()

    try:
        # Find all pending jobs (mail sent + follow up) with ACTION_DATE <= today
        pending_jobs = session.query(JobTracker, CandidateInfo).join(
            CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID
        ).filter(
            JobTracker.JOB_TYPE_ID.in_([1, 2]),  # Mail Sent or Follow Up
            JobTracker.STATUS_ID == 1,             # Pending
            JobTracker.ACTION_DATE <= today,
        ).all()

        drafted_count = 0
        for job, candidate in pending_jobs:
            candidate_type_id = candidate.CANDIDATE_TYPE_ID or 2
            candidate_name = candidate.CANDIDATE_NAME or candidate.CIN

            # Determine email type for template
            mail_type = "initial_documents" if job.JOB_TYPE_ID == 1 else "followup_documents"
            mail_template = _get_mail_template(session, mail_type)

            # Get missing documents
            missing_docs = _get_missing_docs(session, candidate.CANDIDATE_ID, candidate_type_id)

            if not missing_docs and job.JOB_TYPE_ID == 2:
                # No missing docs for follow-up, mark as completed
                job.STATUS_ID = 7  # Completed
                job.UPDATED_ON = today
                continue

            # Generate draft
            draft = _generate_draft(candidate_name, missing_docs, candidate.CIN, mail_template)

            # Update job entry
            job.DRAFT_MAIL = draft
            job.STATUS_ID = 2  # Mail Drafted
            job.HUMAN_ACTION_REQUIRED = 1  # Needs HR review
            job.UPDATED_ON = today

            drafted_count += 1
            logger.info(f"Draft generated for CIN {candidate.CIN}, job {job.JOB_ID}")

        session.commit()
        logger.info(f"Mail draft execution complete. Drafted {drafted_count} emails.")
    except Exception as e:
        session.rollback()
        logger.error(f"Mail draft execution failed: {e}")
        raise
    finally:
        session.close()


# DAG runs daily at 9 AM IST (3:30 AM UTC)
dag = DAG(
    "mail_draft_scheduler",
    default_args=default_args,
    description="Daily mail drafting for candidates pending document requests",
    schedule_interval="30 3 * * *",  # 3:30 AM UTC -> 9 AM IST
    catchup=False,
)

mail_draft_task = PythonOperator(
    task_id="run_mail_draft",
    python_callable=mail_draft_task_callable,
    dag=dag,
)
