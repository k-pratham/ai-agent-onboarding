"""
Airflow DAG: Inbox Reader Scheduler
Runs daily at 9 PM IST (3:30 PM UTC) to read candidate reply emails.

Process:
1. Read all unread emails from the inbox.
2. Extract CIN from subject lines to identify distinct candidates.
3. Classify emails: has_attachments vs no_attachments.
4. For candidates who replied: deactivate pending follow-up jobs.
5. For candidates with attachments: save attachments and trigger the agent.
"""
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, date, timedelta
import os
import asyncio
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from etl_pipeline.models.schema import JobTracker, CandidateInfo

DB_URI = os.getenv("DB_URI", "oracle+oracledb://user:pass@localhost:1521/?service_name=orcl")

default_args = {
    "owner": "hr_automation",
    "depends_on_past": False,
    "start_date": datetime(2023, 1, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

logger = logging.getLogger(__name__)


def _run_async(coro):
    """Helper to run async functions in a sync context."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


def inbox_reader_task_callable():
    """
    Main task: reads inbox, processes candidate replies, saves attachments,
    and triggers the agent for document verification.
    """
    logger.info("Starting inbox reader execution")

    # Step 1: Read inbox via MCP tool
    from mcp_server.read_inbox.tools.read_inbox import tool_read_inbox

    inbox_result = _run_async(tool_read_inbox())

    if inbox_result.get("status") == "empty":
        logger.info("No unread emails found. Exiting.")
        return

    candidates = inbox_result.get("candidates", [])
    logger.info(f"Found {len(candidates)} distinct candidates with replies.")

    # Step 2: Process candidates with attachments
    from mcp_server.save_attachment.tools.save_attachment import tool_save_attachment

    for candidate_data in candidates:
        cin = candidate_data["cin"]
        candidate_id = candidate_data["candidate_id"]
        has_attachments = candidate_data["has_attachments"]
        attachments = candidate_data.get("attachments", [])
        job_id = candidate_data.get("job_id")

        if not has_attachments:
            logger.info(f"CIN {cin}: No attachments. Follow-up deactivated.")
            continue

        # Save each attachment
        saved_files = []
        for attachment in attachments:
            file_name = attachment["filename"]
            base64_data = attachment["data"]

            result = _run_async(tool_save_attachment(cin, file_name, base64_data, job_id))
            saved_files.append(result)
            logger.info(f"CIN {cin}: Saved attachment {file_name}")

        # Step 3: Trigger agent for document verification
        logger.info(f"CIN {cin}: {len(saved_files)} attachments saved. Triggering agent.")
        try:
            _trigger_agent_for_candidate(cin, candidate_id, saved_files)
        except Exception as e:
            logger.error(f"Agent trigger failed for CIN {cin}: {e}")

    logger.info("Inbox reader execution completed.")


def _trigger_agent_for_candidate(cin: str, candidate_id: int, saved_files: list):
    """
    Triggers the LangGraph agent for a specific candidate to process
    their uploaded documents (OCR, gap analysis, draft follow-up).
    """
    from ai_onboarding_brain.src.core.agent import get_compiled_orchestrator
    from ai_onboarding_brain.src.core.database import SessionLocal
    from langchain_core.messages import HumanMessage

    db = SessionLocal()
    try:
        orchestrator = get_compiled_orchestrator(db)
        config = {"configurable": {"thread_id": f"CANDIDATE_{cin}"}}

        prompt = (
            f"Candidate CIN {cin} has uploaded {len(saved_files)} document(s). "
            f"Process each document: run OCR classification, validate identity, "
            f"perform gap analysis, and draft a follow-up email if documents are missing."
        )

        result = orchestrator.invoke(
            {"messages": [HumanMessage(content=prompt)]},
            config=config,
        )
        logger.info(f"Agent completed for CIN {cin}. Messages: {len(result['messages'])}")
    except Exception as e:
        logger.error(f"Agent execution failed for CIN {cin}: {e}")
        raise
    finally:
        db.close()


# DAG runs daily at 9 PM IST (3:30 PM UTC)
dag = DAG(
    "inbox_reader_scheduler",
    default_args=default_args,
    description="Daily inbox reader for candidate document replies and agent trigger",
    schedule_interval="30 15 * * *",  # 3:30 PM UTC -> 9 PM IST
    catchup=False,
)

inbox_task = PythonOperator(
    task_id="run_inbox_reader",
    python_callable=inbox_reader_task_callable,
    dag=dag,
)
