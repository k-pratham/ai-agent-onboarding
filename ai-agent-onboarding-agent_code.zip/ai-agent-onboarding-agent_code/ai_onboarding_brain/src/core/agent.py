import os
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langchain_core.messages import BaseMessage, SystemMessage
from langchain_openai import ChatOpenAI

from ai_onboarding_brain.src.core.tools import AGENT_TOOLS
from ai_onboarding_brain.src.core.checkpointer import OracleCheckpointer
from mcp_server.constants.common_functions import get_vllm_base_url, get_config


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]


def _get_llm():
    """Creates the vLLM-backed ChatOpenAI instance for the agent model (gpt-oss-20b)."""
    cfg = get_config()
    model_name = cfg.get("vllm", "agent_model", fallback="gpt-oss-20b")
    base_url = get_vllm_base_url()
    return ChatOpenAI(
        model=model_name,
        temperature=0,
        openai_api_base=base_url,
        openai_api_key="vllm",
    )


llm = _get_llm()
llm_with_tools = llm.bind_tools(AGENT_TOOLS)

system_prompt = SystemMessage(content="""You are an autonomous HR Onboarding Agent responsible for end-to-end candidate document verification.

Your workflow for each candidate (identified by CIN):
1. SAVE ATTACHMENTS: When candidate documents arrive, save each attachment to the CIN folder.
2. OCR & CLASSIFY: For each saved document, run OCR extraction and classify the document type (Aadhaar, PAN, Marksheet, Experience Letter, etc.). The classification also segregates files into subfolders (education/, employment/, personal_details/, unmatched/).
3. VALIDATE IDENTITY: Cross-check candidate name and date of birth across all classified documents. Verify experience duration against CANDIDATE_INFO records using experience/relieving letters.
4. GAP ANALYSIS: Compare received and verified documents against the required document list (based on candidate type: Fresher, Experience, or Dev Partner). Update document statuses in the tracker.
5. DRAFT FOLLOW-UP: If documents are missing, generate a follow-up email draft requesting the pending documents. The draft is saved to the Job Tracker for HR review.
6. DISPATCH EMAIL: Once HR approves, send the follow-up email to the candidate.

Decision rules:
- If all documents are verified and complete, mark the candidate as 'Completed'.
- If documents are missing, generate a draft follow-up email for HR approval.
- If a document fails OCR validation, place it in 'unmatched' and keep status as 'Pending'.
- Always validate candidate name consistency across documents before marking as verified.
- If experience is recorded but no experience/relieving letters are provided, flag this discrepancy.

You have access to the following tools:
- extract_and_validate_document: OCR classification and file segregation
- analyze_gap_tracker: Document gap analysis with DB updates
- validate_candidate_identity: Cross-document name/DOB/experience validation
- dispatch_followup_email: Send emails to candidates
- prepare_draft_email: Generate follow-up email drafts via LLM
- save_candidate_attachment: Save attachments to disk with DB tracking

Process documents methodically. After each tool call, analyze the result before deciding the next action.
""")


def run_agent(state: AgentState):
    """Node that invokes the LLM with tools."""
    messages = state["messages"]
    if not any(isinstance(m, SystemMessage) for m in messages):
        messages = [system_prompt] + messages
    response = llm_with_tools.invoke(messages)
    return {"messages": [response]}


def route_condition(state: AgentState):
    """Decide whether to run tools or finish."""
    messages = state["messages"]
    last_message = messages[-1]
    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
        return "tools"
    return END


# Construct the StateGraph
workflow = StateGraph(AgentState)
workflow.add_node("agent", run_agent)
workflow.add_node("tools", ToolNode(AGENT_TOOLS))

workflow.add_edge(START, "agent")
workflow.add_conditional_edges("agent", route_condition, ["tools", END])
workflow.add_edge("tools", "agent")


def get_compiled_orchestrator(db_session):
    """Returns the compiled graph instance bound with the Oracle DB Checkpointer."""
    checkpointer = OracleCheckpointer(db_session)
    app = workflow.compile(checkpointer=checkpointer)
    return app
