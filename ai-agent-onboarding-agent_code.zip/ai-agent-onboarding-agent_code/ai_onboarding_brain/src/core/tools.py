import os
import base64
import logging
from langchain_core.tools import tool
from ai_onboarding_brain.src.core.config import get_logger

try:
    from mcp_server.mcp_tools_registry import MCP_TOOLS
except ImportError:
    MCP_TOOLS = {}

try:
    from mcp_server.send_email.tools.send_email import tool_send_email
except ImportError:
    tool_send_email = None

logger = get_logger(__name__)


async def _notify_hr_on_failure(tool_name: str, error_msg: str):
    """Escalate tool failures directly to the HR admins."""
    logger.error(f"HR escalation for {tool_name} failure: {error_msg}")
    if tool_send_email:
        try:
            await tool_send_email(
                "hr-admin@example.com",
                f"Agent Alert: {tool_name} Failed",
                f"The automated workflow encountered an error: {error_msg}",
            )
        except Exception as e:
            logger.critical(f"Could not send HR admin alert: {e}")


@tool
async def extract_and_validate_document(file_path: str, cin: str) -> dict:
    """
    Reads a document off disk, performs OCR text extraction, classifies the document
    using the numarkdown-8b-thinking model, segregates it into the correct folder,
    and validates candidate name/DOB consistency.

    Args:
        file_path: Path to the document file on disk.
        cin: Candidate CIN identifier.

    Returns:
        Dict with classification result, validation details, and new file path.
    """
    try:
        logger.info(f"Tool: OCR validation for {file_path}, CIN: {cin}")

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Cannot locate attachment at {file_path}")

        # Delegate to the MCP OCR tool
        ocr_tool = MCP_TOOLS.get("ocr_and_segregate")
        if ocr_tool:
            result = await ocr_tool(cin=cin, file_path=file_path)
            return result
        else:
            # Fallback: direct vLLM call for classification
            import fitz
            from langchain_openai import ChatOpenAI
            from langchain_core.messages import HumanMessage

            base64_image = ""
            if file_path.lower().endswith(".pdf"):
                doc = fitz.open(file_path)
                if len(doc) == 0:
                    raise ValueError("PDF is completely empty.")
                page = doc.load_page(0)
                pix = page.get_pixmap()
                image_bytes = pix.tobytes("png")
                base64_image = base64.b64encode(image_bytes).decode("utf-8")
            else:
                with open(file_path, "rb") as image_file:
                    base64_image = base64.b64encode(image_file.read()).decode("utf-8")

            vllm_base_url = os.getenv("VLLM_BASE_URL", "http://localhost:8000/v1")
            llm = ChatOpenAI(
                model="numarkdown-8b-thinking",
                temperature=0,
                openai_api_base=vllm_base_url,
                openai_api_key="vllm",
            )

            message = HumanMessage(
                content=[
                    {"type": "text", "text": "Classify this HR document type and extract candidate name, DOB."},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}},
                ]
            )
            response = llm.invoke([message])
            return {"classification": response.content, "cin": cin, "file_path": file_path}

    except Exception as e:
        error_payload = f"OCR validation failed on {file_path}: {str(e)}"
        await _notify_hr_on_failure("OCR Validation", error_payload)
        return {"error": error_payload}


@tool
async def analyze_gap_tracker(cin: str, validated_doc_type_ids: list = None) -> dict:
    """
    Performs gap analysis checking what candidate documents are still missing.
    Filters required documents by candidate type (Fresher/Experience/Dev Partner).
    Updates verified documents in the database.

    Args:
        cin: Candidate CIN identifier.
        validated_doc_type_ids: List of document type IDs validated by OCR.

    Returns:
        Dict with missing, completed, pending documents and overall status.
    """
    try:
        logger.info(f"Tool: Gap analysis for CIN: {cin}")

        # Delegate to the MCP gap analysis tool
        gap_tool = MCP_TOOLS.get("gap_analysis")
        if gap_tool:
            return await gap_tool(cin=cin, validated_doc_type_ids=validated_doc_type_ids)
        else:
            # Fallback: direct DB query
            from ai_onboarding_brain.src.core.database import SessionLocal
            from etl_pipeline.models.schema import CandidateInfo, DocumentTracker, DocumentTypeMaster

            db = SessionLocal()
            try:
                candidate = db.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()
                if not candidate:
                    return {"error": f"Candidate CIN {cin} not found."}

                candidate_type_id = candidate.CANDIDATE_TYPE_ID or 2
                type_col_map = {1: "FRESHER", 2: "EXPERIENCE", 3: "DEV_PARTNER"}
                col_name = type_col_map.get(candidate_type_id, "EXPERIENCE")

                expected_docs = db.query(DocumentTypeMaster).filter(
                    DocumentTypeMaster.IS_ACTIVE == 1,
                    getattr(DocumentTypeMaster, col_name) == 1,
                ).all()

                tracked_docs = db.query(DocumentTracker).filter(
                    DocumentTracker.CANDIDATE_ID == candidate.CANDIDATE_ID
                ).all()

                tracked_map = {doc.DOCUMENT_TYPE_ID: doc.STATUS_ID for doc in tracked_docs}
                missing = []
                completed = []
                for expected in expected_docs:
                    status = tracked_map.get(expected.DOCUMENT_TYPE_ID)
                    if status in (5, 7):
                        completed.append(expected.DOCUMENT_NAME)
                    else:
                        missing.append(expected.DOCUMENT_NAME)

                overall = "completed" if not missing else "pending_documents"
                return {
                    "cin": cin,
                    "candidate_name": candidate.CANDIDATE_NAME,
                    "missing_documents": missing,
                    "completed_documents": completed,
                    "status": overall,
                }
            finally:
                db.close()

    except Exception as e:
        error_payload = f"Gap tracker failure for {cin}: {str(e)}"
        await _notify_hr_on_failure("Gap Tracker", error_payload)
        return {"error": error_payload}


@tool
async def validate_candidate_identity(cin: str, doc_results: list) -> dict:
    """
    Cross-validates candidate identity across multiple documents.
    Checks that candidate name and date of birth are consistent across all verified documents.
    Validates previous experience against CANDIDATE_INFO.PREVIOUS_EXPERIENCE using
    relieving letters and experience letters.

    Args:
        cin: Candidate CIN identifier.
        doc_results: List of OCR classification results (each with candidate_name_on_doc, dob_on_doc).

    Returns:
        Dict with name match status, DOB match status, and experience validation.
    """
    try:
        logger.info(f"Tool: Identity validation for CIN: {cin}")
        from ai_onboarding_brain.src.core.database import SessionLocal
        from etl_pipeline.models.schema import CandidateInfo

        db = SessionLocal()
        try:
            candidate = db.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()
            if not candidate:
                return {"error": f"Candidate CIN {cin} not found."}

            db_name = (candidate.CANDIDATE_NAME or "").strip().upper()
            db_experience = candidate.PREVIOUS_EXPERIENCE

            # Collect names and DOBs from all documents
            names_on_docs = []
            dobs_on_docs = []
            experience_docs = []

            for result in doc_results:
                name = result.get("candidate_name_on_doc")
                dob = result.get("dob_on_doc")
                category = result.get("classified_as", "")

                if name:
                    names_on_docs.append(name.strip().upper())
                if dob:
                    dobs_on_docs.append(dob)
                if category in ("EXPERIENCE_LETTER", "RELIEVING_LETTER"):
                    experience_docs.append(result)

            # Name consistency check
            name_match = True
            name_issues = []
            for doc_name in names_on_docs:
                if db_name and doc_name != db_name:
                    # Fuzzy check: at least first and last name match
                    db_parts = set(db_name.split())
                    doc_parts = set(doc_name.split())
                    overlap = db_parts & doc_parts
                    if len(overlap) < min(2, len(db_parts)):
                        name_match = False
                        name_issues.append(f"Name mismatch: DB='{db_name}', Doc='{doc_name}'")

            # DOB consistency check
            dob_match = True
            dob_issues = []
            unique_dobs = set(dobs_on_docs)
            if len(unique_dobs) > 1:
                dob_match = False
                dob_issues.append(f"Multiple DOBs found: {unique_dobs}")

            # Experience validation
            experience_valid = True
            experience_notes = []
            if db_experience and experience_docs:
                experience_notes.append(
                    f"DB records {db_experience} years experience. "
                    f"Found {len(experience_docs)} experience/relieving letter(s)."
                )
            elif db_experience and db_experience != "0" and not experience_docs:
                experience_valid = False
                experience_notes.append(
                    f"DB records {db_experience} years experience but no experience/relieving letters found."
                )

            return {
                "cin": cin,
                "candidate_name_db": db_name,
                "name_match": name_match,
                "name_issues": name_issues,
                "dob_match": dob_match,
                "dob_issues": dob_issues,
                "experience_valid": experience_valid,
                "experience_notes": experience_notes,
                "documents_checked": len(doc_results),
            }
        finally:
            db.close()

    except Exception as e:
        error_payload = f"Identity validation failed for {cin}: {str(e)}"
        await _notify_hr_on_failure("Identity Validation", error_payload)
        return {"error": error_payload}


@tool
async def dispatch_followup_email(candidate_email: str, subject: str, draft_content: str) -> str:
    """
    Dispatches a follow-up or warning email to a candidate about missing documents.

    Args:
        candidate_email: Candidate's email address.
        subject: Email subject line.
        draft_content: The email body content approved by HR.

    Returns:
        Status message confirming the send operation.
    """
    try:
        logger.info(f"Tool: Dispatching email to {candidate_email}")
        send_tool = MCP_TOOLS.get("send_email")
        if send_tool:
            return await send_tool(candidate_email, subject, draft_content)
        elif tool_send_email:
            return await tool_send_email(candidate_email, subject, draft_content)
        return f"Mocked email success to {candidate_email}"
    except Exception as e:
        error_payload = f"SMTP dispatch failed: {str(e)}"
        await _notify_hr_on_failure("Email Dispatch", error_payload)
        return f"Error: {error_payload}"


@tool
async def prepare_draft_email(cin: str, candidate_name: str, missing_docs: list, job_id: int = None) -> str:
    """
    Generates a draft follow-up email for a candidate requesting missing documents.
    Uses the MailTypeMaster template and saves the draft to JOB_TRACKER.

    Args:
        cin: Candidate CIN identifier.
        candidate_name: Name of the candidate.
        missing_docs: List of missing document names.
        job_id: Optional JOB_TRACKER entry ID to save the draft to.

    Returns:
        The generated draft email content.
    """
    try:
        logger.info(f"Tool: Preparing draft for CIN {cin}")
        draft_tool = MCP_TOOLS.get("draft_prepare")
        if draft_tool:
            return await draft_tool(cin=cin, candidate_name=candidate_name, missing_docs=missing_docs, job_id=job_id)
        else:
            from mcp_server.draft_prepare.engine.helper_func import generate_draft
            return generate_draft(candidate_name, missing_docs, cin)
    except Exception as e:
        error_payload = f"Draft preparation failed for {cin}: {str(e)}"
        await _notify_hr_on_failure("Draft Prepare", error_payload)
        return f"Error: {error_payload}"


@tool
async def save_candidate_attachment(cin: str, file_name: str, base64_data: str, job_id: int = None) -> str:
    """
    Saves a candidate's attachment to disk and records it in the Document Tracker.

    Args:
        cin: Candidate CIN identifier.
        file_name: Name of the file to save.
        base64_data: Base64 encoded file content.
        job_id: Optional JOB_TRACKER entry ID to link.

    Returns:
        Status message with the saved file path.
    """
    try:
        logger.info(f"Tool: Saving attachment {file_name} for CIN {cin}")
        save_tool = MCP_TOOLS.get("save_attachment")
        if save_tool:
            return await save_tool(cin=cin, file_name=file_name, base64_data=base64_data, job_id=job_id)
        else:
            from mcp_server.save_attachment.tools.save_attachment import tool_save_attachment
            return await tool_save_attachment(cin, file_name, base64_data, job_id)
    except Exception as e:
        error_payload = f"Attachment save failed for {cin}: {str(e)}"
        await _notify_hr_on_failure("Save Attachment", error_payload)
        return f"Error: {error_payload}"


# Registry of Tools passed to the LangGraph Agent
AGENT_TOOLS = [
    extract_and_validate_document,
    analyze_gap_tracker,
    validate_candidate_identity,
    dispatch_followup_email,
    prepare_draft_email,
    save_candidate_attachment,
]
