import logging
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from mcp_server.constants.common_functions import get_db_uri
from etl_pipeline.models.schema import DocumentTracker, CandidateInfo

logger = logging.getLogger(__name__)

_session_factory = None


def _get_session() -> Session:
    global _session_factory
    if _session_factory is None:
        engine = create_engine(get_db_uri(), pool_pre_ping=True, pool_recycle=3600)
        _session_factory = sessionmaker(bind=engine)
    return _session_factory()


def get_candidate_by_cin(session: Session, cin: str):
    """Fetches a CandidateInfo record by CIN."""
    return session.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()


def insert_document_tracker_record(
    session: Session,
    candidate_id: int,
    document_type_id: int,
    job_id: int,
    file_path: str,
) -> DocumentTracker:
    """
    Inserts a record into DOCUMENT_TRACKER when an attachment is saved.
    Sets status to Pending (1) until OCR verification is done.
    """
    today = date.today()
    record = DocumentTracker(
        CANDIDATE_ID=candidate_id,
        DOCUMENT_TYPE_ID=document_type_id,
        DOCUMENT_STORE_ID=None,
        DOCUMENT_RECIVED_ON=today,
        COMMENTS=f"Attachment saved at: {file_path}",
        STATUS_ID=1,  # Pending
        JOB_ID=job_id,
        CREATED_ON=today,
        UPDATED_ON=today,
        IS_ACTIVE=1,
    )
    session.add(record)
    session.flush()
    logger.info(f"Inserted document tracker record for candidate {candidate_id}, type {document_type_id}")
    return record


def get_document_tracker_by_candidate(session: Session, candidate_id: int) -> list:
    """Fetches all document tracker records for a candidate."""
    return session.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()


def update_document_store_path(session: Session, tracker_id: int, file_path: str):
    """Updates the document store path after file is saved/renamed."""
    record = session.query(DocumentTracker).filter(
        DocumentTracker.DOCUMENT_TRACKER_ID == tracker_id
    ).first()
    if record:
        record.COMMENTS = f"Stored at: {file_path}"
        record.UPDATED_ON = date.today()
