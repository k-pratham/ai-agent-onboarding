import os
import re
import logging
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from mcp_server.constants.common_functions import get_vllm_base_url, get_config

logger = logging.getLogger(__name__)

# Load prompt from file
_PROMPT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "prompts",
    "ocr_prompt.txt",
)


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r") as f:
        return f.read()


def _get_llm():
    """Initializes the vLLM-hosted numarkdown-8b-thinking model."""
    cfg = get_config()
    model_name = cfg.get("vllm", "ocr_model", fallback="numarkdown-8b-thinking")
    base_url = get_vllm_base_url()
    return ChatOpenAI(
        model=model_name,
        temperature=0,
        openai_api_base=base_url,
        openai_api_key="vllm",
    )


# Map of all recognized document categories
VALID_CATEGORIES = {
    "AADHAAR", "PAN", "TENTH_MARKSHEET", "TWELFTH_MARKSHEET",
    "DEGREE_CERTIFICATE", "EXPERIENCE_LETTER", "RELIEVING_LETTER",
    "SALARY_SLIP", "RESUME", "OFFER_LETTER", "PASSPORT",
    "DRIVING_LICENSE", "BANK_STATEMENT", "UNKNOWN",
}

# Maps OCR categories to the segregation folder and document name prefix
CATEGORY_TO_FOLDER = {
    "AADHAAR": "personal_details",
    "PAN": "personal_details",
    "PASSPORT": "personal_details",
    "DRIVING_LICENSE": "personal_details",
    "TENTH_MARKSHEET": "education",
    "TWELFTH_MARKSHEET": "education",
    "DEGREE_CERTIFICATE": "education",
    "EXPERIENCE_LETTER": "employment",
    "RELIEVING_LETTER": "employment",
    "SALARY_SLIP": "employment",
    "OFFER_LETTER": "employment",
    "RESUME": "employment",
    "BANK_STATEMENT": "personal_details",
}

# Maps OCR categories to DB document type name for matching against DocumentTypeMaster
CATEGORY_TO_DOC_NAME = {
    "AADHAAR": "Aadhaar Card",
    "PAN": "PAN Card",
    "TENTH_MARKSHEET": "10th Marksheet",
    "TWELFTH_MARKSHEET": "12th Marksheet",
    "DEGREE_CERTIFICATE": "Degree Certificate",
    "EXPERIENCE_LETTER": "Experience Letter",
    "RELIEVING_LETTER": "Relieving Letter",
    "SALARY_SLIP": "Salary Slips",
}


def classify_document_type(ocr_text: str) -> dict:
    """
    Classifies the document using the vLLM-hosted numarkdown-8b-thinking model.
    Returns a dict with category, candidate_name, date_of_birth, and document_id.
    """
    prompt_template = _load_prompt()
    prompt = PromptTemplate.from_template(prompt_template)
    llm = _get_llm()
    chain = prompt | llm

    try:
        response = chain.invoke({"text": ocr_text})
        result_text = response.content if hasattr(response, "content") else str(response)
        result_text = result_text.strip()
        return _parse_classification_response(result_text)
    except Exception as e:
        logger.error(f"Classification inference failed: {str(e)}")
        return {
            "category": "UNKNOWN",
            "candidate_name": None,
            "date_of_birth": None,
            "document_id": None,
        }


def _parse_classification_response(response_text: str) -> dict:
    """Parses the structured LLM response into a dict."""
    result = {
        "category": "UNKNOWN",
        "candidate_name": None,
        "date_of_birth": None,
        "document_id": None,
    }

    for line in response_text.split("\n"):
        line = line.strip()
        if line.startswith("CATEGORY:"):
            cat = line.split(":", 1)[1].strip().upper()
            if cat in VALID_CATEGORIES:
                result["category"] = cat
        elif line.startswith("CANDIDATE_NAME:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NOT_FOUND":
                result["candidate_name"] = val
        elif line.startswith("DATE_OF_BIRTH:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NOT_FOUND":
                result["date_of_birth"] = val
        elif line.startswith("DOCUMENT_ID:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NOT_FOUND":
                result["document_id"] = val

    return result
