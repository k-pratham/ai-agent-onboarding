import os
import logging
from datetime import date, timedelta
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from mcp_server.constants.common_functions import get_vllm_base_url, get_config

logger = logging.getLogger(__name__)

_PROMPT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "prompts",
    "classify_reply_prompt.txt",
)

VALID_CLASSIFICATIONS = {
    "DOCUMENTS_ATTACHED",
    "WILL_SEND_LATER",
    "NEEDS_CLARIFICATION",
    "DECLINE",
    "OUT_OF_OFFICE",
    "UNRELATED",
}

# Default follow-up offsets (in days) for each classification type
DEFAULT_FOLLOWUP_DAYS = {
    "DOCUMENTS_ATTACHED": 0,       # No follow-up needed, process docs
    "WILL_SEND_LATER": 2,          # Default if no date given
    "NEEDS_CLARIFICATION": 1,      # Respond quickly
    "DECLINE": 0,                  # Escalate to HR
    "OUT_OF_OFFICE": 5,            # Wait for return
    "UNRELATED": 2,                # Try again
}


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r") as f:
        return f.read()


def _get_llm():
    """Initializes the vLLM-hosted gpt-oss-20b model."""
    cfg = get_config()
    model_name = cfg.get("vllm", "agent_model", fallback="gpt-oss-20b")
    base_url = get_vllm_base_url()
    return ChatOpenAI(
        model=model_name,
        temperature=0,
        openai_api_base=base_url,
        openai_api_key="vllm",
    )


def classify_candidate_reply(email_body: str) -> dict:
    """
    Uses LLM to classify a candidate's reply email into a follow-up category.
    Extracts explicit dates (ISO format) or relative time expressions.
    Rule-based logic then determines the next follow-up date.

    Returns:
        dict with classification, followup_date, and summary.
    """
    prompt_template = _load_prompt()
    prompt = PromptTemplate.from_template(prompt_template)
    llm = _get_llm()
    chain = prompt | llm

    today = date.today()

    try:
        response = chain.invoke({
            "email_body": email_body,
            "today_date": today.isoformat(),
        })
        result_text = response.content if hasattr(response, "content") else str(response)
        result_text = result_text.strip()
        return _parse_classification_response(result_text, today)
    except Exception as e:
        logger.error(f"Reply classification failed: {e}")
        return {
            "classification": "UNRELATED",
            "followup_date": today + timedelta(days=2),
            "summary": "Classification failed, defaulting to follow-up in 2 days.",
        }


def _parse_classification_response(response_text: str, today: date) -> dict:
    """Parses the structured LLM response into a dict."""
    classification = "UNRELATED"
    followup_date = None
    summary = ""

    for line in response_text.split("\n"):
        line = line.strip()
        if line.startswith("CLASSIFICATION:"):
            val = line.split(":", 1)[1].strip().upper()
            if val in VALID_CLASSIFICATIONS:
                classification = val
        elif line.startswith("FOLLOWUP_DATE:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NO_DATE":
                try:
                    followup_date = date.fromisoformat(val)
                except ValueError:
                    logger.warning(f"Could not parse date: {val}")
        elif line.startswith("SUMMARY:"):
            summary = line.split(":", 1)[1].strip()

    # Apply rule-based logic if no date was extracted
    if followup_date is None:
        offset = DEFAULT_FOLLOWUP_DAYS.get(classification, 2)
        followup_date = today + timedelta(days=offset) if offset > 0 else None

    return {
        "classification": classification,
        "followup_date": followup_date,
        "summary": summary,
    }
