import logging
from datetime import date, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from mcp_server.constants.common_functions import get_db_uri
from etl_pipeline.models.schema import JobTracker, CandidateInfo

logger = logging.getLogger(__name__)

_session_factory = None


def _get_session() -> Session:
    global _session_factory
    if _session_factory is None:
        engine = create_engine(get_db_uri(), pool_pre_ping=True, pool_recycle=3600)
        _session_factory = sessionmaker(bind=engine)
    return _session_factory()


def get_candidate_by_cin(session: Session, cin: str):
    """Fetches a CandidateInfo record by CIN."""
    return session.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()


def create_followup_job_with_date(session: Session, candidate_id: int, followup_date: date) -> JobTracker:
    """
    Creates a follow-up job entry with a specific followup date derived from
    the candidate's reply classification.
    """
    today = date.today()
    new_job = JobTracker(
        JOB_TYPE_ID=2,  # Follow Up
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=0,
        STATUS_ID=1,  # Pending
        ACTION_DATE=followup_date,
        UPDATED_ON=today,
    )
    session.add(new_job)
    session.flush()
    logger.info(f"Created follow-up job for candidate {candidate_id} with date {followup_date}")
    return new_job


def count_failed_followups(session: Session, candidate_id: int) -> int:
    """
    Counts how many follow-up mails have been sent to a candidate
    (status = Mail Sent (3) and job_type = Follow Up (2)).
    Used to determine if escalation is needed.
    """
    count = session.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID == candidate_id,
        JobTracker.JOB_TYPE_ID == 2,  # Follow Up
        JobTracker.STATUS_ID == 3,    # Mail Sent
    ).count()
    return count
