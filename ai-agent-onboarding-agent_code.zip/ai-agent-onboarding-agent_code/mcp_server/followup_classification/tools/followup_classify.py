import logging
from mcp_server.followup_classification.engine.helper_func import classify_candidate_reply
from mcp_server.followup_classification.engine.db_engine import (
    _get_session,
    get_candidate_by_cin,
    create_followup_job_with_date,
    count_failed_followups,
)

logger = logging.getLogger(__name__)

ESCALATION_THRESHOLD = 2


async def tool_followup_classify(cin: str, email_body: str) -> dict:
    """
    MCP Followup Classification Tool: Classifies a candidate's reply email
    and determines the appropriate next follow-up action.

    Uses LLM to classify the reply into categories:
    - DOCUMENTS_ATTACHED, WILL_SEND_LATER, NEEDS_CLARIFICATION,
      DECLINE, OUT_OF_OFFICE, UNRELATED

    Extracts dates (ISO format or relative) and applies rule-based logic
    to determine the next follow-up date.

    Creates a follow-up job entry in JOB_TRACKER if needed.
    Checks escalation threshold (2 failed follow-ups -> escalate to HR).

    Returns:
        Dict with classification result, follow-up date, and escalation flag.
    """
    result = classify_candidate_reply(email_body)
    classification = result["classification"]
    followup_date = result["followup_date"]
    summary = result["summary"]

    needs_escalation = False
    job_created = False

    session = _get_session()
    try:
        candidate = get_candidate_by_cin(session, cin)
        if not candidate:
            return {
                "error": f"Candidate CIN {cin} not found.",
                "classification": classification,
            }

        # Check if escalation is needed (2+ failed follow-ups)
        failed_count = count_failed_followups(session, candidate.CANDIDATE_ID)
        if failed_count >= ESCALATION_THRESHOLD:
            needs_escalation = True
            logger.warning(f"Escalation needed for CIN {cin}: {failed_count} failed follow-ups.")

        # Create follow-up job if a date is determined
        if followup_date and classification not in ("DOCUMENTS_ATTACHED", "DECLINE"):
            create_followup_job_with_date(session, candidate.CANDIDATE_ID, followup_date)
            job_created = True

        session.commit()
    except Exception as e:
        session.rollback()
        logger.error(f"Followup classification DB operations failed for CIN {cin}: {e}")
    finally:
        session.close()

    return {
        "cin": cin,
        "classification": classification,
        "followup_date": followup_date.isoformat() if followup_date else None,
        "summary": summary,
        "needs_escalation": needs_escalation,
        "failed_followup_count": failed_count if candidate else 0,
        "followup_job_created": job_created,
    }
