import os
import logging
import configparser
from .constants import EMAIL_ATTACHMENT_DIR

logger = logging.getLogger(__name__)

_config = None


def load_config(config_path: str = None) -> configparser.ConfigParser:
    """
    Loads the configuration from a .properties file using configparser.
    Defaults to config/dev.properties relative to the mcp_server package root.
    """
    global _config
    if config_path is None:
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "config",
            "dev.properties",
        )
    parser = configparser.ConfigParser()
    parser.read(config_path)
    _config = parser
    logger.info(f"Configuration loaded from {config_path}")
    return parser


def get_config() -> configparser.ConfigParser:
    """
    Returns the already-loaded config. If not loaded yet, loads from default path.
    """
    global _config
    if _config is None:
        return load_config()
    return _config


def get_attachment_path(cin: str) -> str:
    """
    Returns the target folder path to store attachments for a specific candidate.
    Creates the directory if it does not exist.
    """
    cfg = get_config()
    base_dir = cfg.get("paths", "email_attachment_dir", fallback=EMAIL_ATTACHMENT_DIR)
    path = os.path.join(base_dir, cin)
    try:
        os.makedirs(path, exist_ok=True)
        return path
    except Exception as e:
        logger.error(f"Could not create path {path}: {e}")
        raise


def get_db_uri() -> str:
    """Returns the database URI from config."""
    cfg = get_config()
    return cfg.get("database", "db_uri", fallback=os.getenv(
        "DB_URI", "oracle+oracledb://user:pass@localhost:1521/?service_name=orcl"
    ))


def get_vllm_base_url() -> str:
    """Returns the vLLM base URL from config."""
    cfg = get_config()
    return cfg.get("vllm", "vllm_base_url", fallback=os.getenv(
        "VLLM_BASE_URL", "http://localhost:8000/v1"
    ))


def get_smtp_config() -> dict:
    """Returns SMTP configuration as a dict."""
    cfg = get_config()
    return {
        "host": cfg.get("smtp", "smtp_host", fallback=os.getenv("SMTP_HOST", "smtp.sendgrid.net")),
        "port": int(cfg.get("smtp", "smtp_port", fallback=os.getenv("SMTP_PORT", "587"))),
        "user": cfg.get("smtp", "smtp_user", fallback=os.getenv("SMTP_USER", "apikey")),
        "password": cfg.get("smtp", "smtp_pass", fallback=os.getenv("SMTP_PASS", "")),
        "from_address": cfg.get("smtp", "smtp_from", fallback=os.getenv("SMTP_FROM", "hr-noreply@example.com")),
    }


def get_imap_config() -> dict:
    """Returns IMAP configuration as a dict."""
    cfg = get_config()
    return {
        "host": cfg.get("imap", "imap_host", fallback=os.getenv("IMAP_HOST", "imap.example.com")),
        "port": int(cfg.get("imap", "imap_port", fallback=os.getenv("IMAP_PORT", "993"))),
        "user": cfg.get("imap", "imap_user", fallback=os.getenv("IMAP_USER", "hr-inbox@example.com")),
        "password": cfg.get("imap", "imap_pass", fallback=os.getenv("IMAP_PASS", "")),
    }
