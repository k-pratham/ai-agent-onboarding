import logging
from mcp_server.draft_prepare.engine.helper_func import generate_and_save_draft, generate_draft

logger = logging.getLogger(__name__)


async def tool_draft_prepare(cin: str, candidate_name: str, missing_docs: list, job_id: int = None) -> str:
    """
    MCP Draft Prepare Tool: Generates follow-up email drafts and persists them to the database.

    1. Fetches mail template from MAIL_TYPE_MASTER.
    2. Generates draft email via LLM (gpt-oss-20b on vLLM).
    3. Saves draft into JOB_TRACKER.DRAFT_MAIL for HR review.
    4. Sets status to 'Mail Drafted' and HUMAN_ACTION_REQUIRED = 1.

    Args:
        cin: Candidate CIN identifier.
        candidate_name: Name of the candidate.
        missing_docs: List of missing document names.
        job_id: JOB_TRACKER entry ID to save the draft to.

    Returns:
        The generated draft email content.
    """
    if job_id is not None:
        # Full flow: generate and save to DB
        try:
            draft = generate_and_save_draft(cin, missing_docs, job_id)
            logger.info(f"Draft prepared and saved for CIN {cin}, job {job_id}")
            return draft
        except Exception as e:
            logger.error(f"Draft prepare failed for CIN {cin}: {e}")
            return f"Error generating draft: {str(e)}"
    else:
        # Generate draft only (no DB persistence)
        draft = generate_draft(candidate_name, missing_docs, cin)
        return draft
