import logging
from datetime import date, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from mcp_server.constants.common_functions import get_db_uri
from etl_pipeline.models.schema import JobTracker, CandidateInfo, MailTypeMaster

logger = logging.getLogger(__name__)

_session_factory = None


def _get_session() -> Session:
    global _session_factory
    if _session_factory is None:
        engine = create_engine(get_db_uri(), pool_pre_ping=True, pool_recycle=3600)
        _session_factory = sessionmaker(bind=engine)
    return _session_factory()


def get_candidate_by_cin(session: Session, cin: str):
    """Fetches a CandidateInfo record by CIN."""
    return session.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()


def get_mail_template(session: Session, mail_type: str) -> str:
    """
    Fetches the mail template/description from MAIL_TYPE_MASTER.
    Returns the MAIL_DESCRIPTION field which contains the template body.
    """
    record = session.query(MailTypeMaster).filter(
        MailTypeMaster.MAIL_TYPE == mail_type,
        MailTypeMaster.IS_ACTIVE == 1,
    ).first()
    if record:
        return record.MAIL_DESCRIPTION
    return None


def save_draft_to_job_tracker(session: Session, job_id: int, draft_content: str):
    """
    Saves the generated draft email into the DRAFT_MAIL field of JOB_TRACKER.
    Updates status to Mail Drafted (2).
    """
    job = session.query(JobTracker).filter(JobTracker.JOB_ID == job_id).first()
    if job:
        job.DRAFT_MAIL = draft_content
        job.STATUS_ID = 2  # Mail Drafted
        job.HUMAN_ACTION_REQUIRED = 1  # Needs HR review
        job.UPDATED_ON = date.today()
        logger.info(f"Saved draft to job tracker {job_id}")
    return job


def get_pending_mail_jobs(session: Session, job_type_id: int) -> list:
    """
    Fetches all pending jobs for a specific job type where ACTION_DATE <= today.
    Used by the mail-drafting DAG to find candidates who need emails.
    """
    today = date.today()
    return session.query(JobTracker, CandidateInfo).join(
        CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID
    ).filter(
        JobTracker.JOB_TYPE_ID == job_type_id,
        JobTracker.STATUS_ID == 1,  # Pending
        JobTracker.ACTION_DATE <= today,
    ).all()


def create_followup_job(session: Session, candidate_id: int, days_offset: int = 2) -> JobTracker:
    """
    Creates a follow-up job entry in JOB_TRACKER with ACTION_DATE = today + days_offset.
    """
    today = date.today()
    new_job = JobTracker(
        JOB_TYPE_ID=2,  # Follow Up
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=0,
        STATUS_ID=1,  # Pending
        ACTION_DATE=today + timedelta(days=days_offset),
        UPDATED_ON=today,
    )
    session.add(new_job)
    session.flush()
    return new_job
