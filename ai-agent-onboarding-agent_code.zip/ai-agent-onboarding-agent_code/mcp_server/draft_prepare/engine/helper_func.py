import os
import logging
from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from mcp_server.constants.common_functions import get_vllm_base_url, get_config
from mcp_server.draft_prepare.engine.db_engine import (
    _get_session,
    get_candidate_by_cin,
    get_mail_template,
    save_draft_to_job_tracker,
)

logger = logging.getLogger(__name__)

_PROMPT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "prompts",
    "draft_prompt.txt",
)

DEFAULT_MAIL_TEMPLATE = """Dear {candidate_name},

We hope this message finds you well. As part of your onboarding process, we require certain documents to proceed further.

Please submit the following documents at your earliest convenience:
{missing_docs}

Kindly reply to this email with the documents attached. Please include your CIN ({cin}) in the subject line.

Thank you for your cooperation.

Regards,
HR Onboarding Team"""


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r") as f:
        return f.read()


def _get_llm():
    """Initializes the vLLM-hosted gpt-oss-20b model for draft generation."""
    cfg = get_config()
    model_name = cfg.get("vllm", "agent_model", fallback="gpt-oss-20b")
    base_url = get_vllm_base_url()
    return ChatOpenAI(
        model=model_name,
        temperature=0.3,
        openai_api_base=base_url,
        openai_api_key="vllm",
    )


def generate_draft(candidate_name: str, missing_docs: list, cin: str = "", mail_template: str = None) -> str:
    """
    Generates a professional follow-up email draft using the vLLM-hosted model.
    Uses the mail template from MailTypeMaster if available.
    """
    if mail_template is None:
        mail_template = DEFAULT_MAIL_TEMPLATE

    prompt_template = _load_prompt()
    prompt = PromptTemplate.from_template(prompt_template)
    llm = _get_llm()
    chain = prompt | llm

    try:
        response = chain.invoke({
            "candidate_name": candidate_name,
            "missing_docs": "\n".join(f"- {doc}" for doc in missing_docs),
            "cin": cin,
            "mail_template": mail_template,
        })
        draft = response.content if hasattr(response, "content") else str(response)
        return draft.strip()
    except Exception as e:
        logger.error(f"Draft generation failed: {e}")
        # Fallback to template-based draft without LLM
        return DEFAULT_MAIL_TEMPLATE.format(
            candidate_name=candidate_name,
            missing_docs="\n".join(f"- {doc}" for doc in missing_docs),
            cin=cin,
        )


def generate_and_save_draft(cin: str, missing_docs: list, job_id: int) -> str:
    """
    End-to-end draft generation:
    1. Fetch candidate info and mail template from DB.
    2. Generate draft via LLM.
    3. Save draft to JOB_TRACKER.DRAFT_MAIL.
    """
    session = _get_session()
    try:
        candidate = get_candidate_by_cin(session, cin)
        if not candidate:
            return f"Error: Candidate CIN {cin} not found."

        candidate_name = candidate.CANDIDATE_NAME or cin

        # Fetch mail template from MailTypeMaster
        mail_template = get_mail_template(session, "followup_documents")
        if not mail_template:
            mail_template = get_mail_template(session, "initial_documents")

        # Generate draft
        draft = generate_draft(candidate_name, missing_docs, cin, mail_template)

        # Save draft to JOB_TRACKER
        save_draft_to_job_tracker(session, job_id, draft)
        session.commit()

        return draft
    except Exception as e:
        session.rollback()
        logger.error(f"Draft generation and save failed for CIN {cin}: {e}")
        raise
    finally:
        session.close()
