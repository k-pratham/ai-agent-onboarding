import logging
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from mcp_server.constants.common_functions import get_db_uri
from etl_pipeline.models.schema import JobTracker, CandidateInfo

logger = logging.getLogger(__name__)

_session_factory = None


def _get_session() -> Session:
    global _session_factory
    if _session_factory is None:
        engine = create_engine(get_db_uri(), pool_pre_ping=True, pool_recycle=3600)
        _session_factory = sessionmaker(bind=engine)
    return _session_factory()


def get_candidate_by_cin(session: Session, cin: str):
    """Fetches a CandidateInfo record by CIN."""
    return session.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()


def deactivate_followup_for_candidate(session: Session, candidate_id: int):
    """
    Once a reply email is received from a candidate, deactivate the pending follow-up
    job in JOB_TRACKER by updating the status to 'Mail Received' (4).
    """
    pending_followups = session.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID == candidate_id,
        JobTracker.JOB_TYPE_ID == 2,  # Follow Up
        JobTracker.STATUS_ID == 1,    # Pending
    ).all()

    count = 0
    for job in pending_followups:
        job.STATUS_ID = 4  # Mail Received
        job.UPDATED_ON = date.today()
        count += 1

    logger.info(f"Deactivated {count} follow-up jobs for candidate {candidate_id}")
    return count


def create_attachment_saved_job(session: Session, candidate_id: int) -> JobTracker:
    """
    Creates a new JOB_TRACKER entry with job_type 'attachments saved' (3).
    """
    today = date.today()
    new_job = JobTracker(
        JOB_TYPE_ID=3,  # Attachments Saved
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=0,
        STATUS_ID=1,  # Pending
        ACTION_DATE=today,
        UPDATED_ON=today,
    )
    session.add(new_job)
    session.flush()
    return new_job
