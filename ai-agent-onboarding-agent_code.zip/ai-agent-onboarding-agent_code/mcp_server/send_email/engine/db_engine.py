import logging
from datetime import date, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from mcp_server.constants.common_functions import get_db_uri
from etl_pipeline.models.schema import JobTracker, CandidateInfo, DocumentTracker, DocumentTypeMaster

logger = logging.getLogger(__name__)

_session_factory = None


def _get_session() -> Session:
    global _session_factory
    if _session_factory is None:
        engine = create_engine(get_db_uri(), pool_pre_ping=True, pool_recycle=3600)
        _session_factory = sessionmaker(bind=engine)
    return _session_factory()


def insert_document_tracker_entries(session: Session, candidate_id: int, job_id: int, candidate_type_id: int):
    """
    After initial mail is sent, insert required documents into DOCUMENT_TRACKER as pending.
    Documents are selected based on candidate type (Fresher/Experience/Dev Partner).
    """
    candidate_type_column_map = {
        1: "FRESHER",
        2: "EXPERIENCE",
        3: "DEV_PARTNER",
    }
    col_name = candidate_type_column_map.get(candidate_type_id, "EXPERIENCE")

    required_docs = session.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()

    today = date.today()
    for doc_type in required_docs:
        existing = session.query(DocumentTracker).filter(
            DocumentTracker.CANDIDATE_ID == candidate_id,
            DocumentTracker.DOCUMENT_TYPE_ID == doc_type.DOCUMENT_TYPE_ID,
        ).first()
        if not existing:
            tracker_entry = DocumentTracker(
                CANDIDATE_ID=candidate_id,
                DOCUMENT_TYPE_ID=doc_type.DOCUMENT_TYPE_ID,
                STATUS_ID=1,  # Pending
                JOB_ID=job_id,
                CREATED_ON=today,
                UPDATED_ON=today,
                IS_ACTIVE=1,
            )
            session.add(tracker_entry)

    logger.info(f"Inserted {len(required_docs)} document tracker entries for candidate {candidate_id}")


def create_followup_job(session: Session, candidate_id: int, days_offset: int = 2) -> JobTracker:
    """
    Creates a follow-up job entry in JOB_TRACKER with ACTION_DATE = today + days_offset.
    """
    today = date.today()
    new_job = JobTracker(
        JOB_TYPE_ID=2,  # Follow Up
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=0,
        STATUS_ID=1,  # Pending
        ACTION_DATE=today + timedelta(days=days_offset),
        UPDATED_ON=today,
    )
    session.add(new_job)
    return new_job


def update_job_status_after_send(session: Session, job_id: int, draft_content: str):
    """
    Updates the job entry after email is sent: status -> Mail Sent, human action resolved.
    """
    job = session.query(JobTracker).filter(JobTracker.JOB_ID == job_id).first()
    if job:
        job.STATUS_ID = 3  # Mail Sent
        job.HUMAN_ACTION_REQUIRED = 0
        job.HUMAN_ACTION = "Approved"
        job.DRAFT_MAIL = draft_content
        job.UPDATED_ON = date.today()
    return job
