import smtplib
from email.message import EmailMessage
import logging
from mcp_server.constants.common_functions import get_smtp_config

logger = logging.getLogger(__name__)


def dispatch_email(to_address: str, subject: str, draft_content: str):
    """
    Dispatches a pre-approved draft email via SMTP.
    Uses configuration from dev.properties via configparser.
    """
    smtp_config = get_smtp_config()

    try:
        msg = EmailMessage()
        msg.set_content(draft_content)
        msg["Subject"] = subject
        msg["From"] = smtp_config["from_address"]
        msg["To"] = to_address

        with smtplib.SMTP(smtp_config["host"], smtp_config["port"]) as server:
            server.starttls()
            if smtp_config["password"]:
                server.login(smtp_config["user"], smtp_config["password"])
            server.send_message(msg)
        logger.info(f"Email successfully dispatched to {to_address}")
    except Exception as e:
        logger.error(f"Failed to send email to {to_address}: {e}")
        raise
