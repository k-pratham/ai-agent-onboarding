import logging
from datetime import date
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from mcp_server.constants.common_functions import get_db_uri
from etl_pipeline.models.schema import (
    DocumentTracker, DocumentTypeMaster, CandidateInfo, CandidateTypeMaster,
)

logger = logging.getLogger(__name__)

_session_factory = None


def _get_session() -> Session:
    global _session_factory
    if _session_factory is None:
        engine = create_engine(get_db_uri(), pool_pre_ping=True, pool_recycle=3600)
        _session_factory = sessionmaker(bind=engine)
    return _session_factory()


def get_candidate_by_cin(session: Session, cin: str):
    """Fetches a CandidateInfo record by CIN."""
    return session.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()


def get_required_documents_for_candidate(session: Session, candidate_type_id: int) -> list:
    """
    Fetches the required documents based on candidate type (Fresher/Experience/DevPartner).
    Filters DOCUMENT_TYPE_MASTER based on the candidate type flags.
    """
    candidate_type_column_map = {
        1: "FRESHER",
        2: "EXPERIENCE",
        3: "DEV_PARTNER",
    }
    col_name = candidate_type_column_map.get(candidate_type_id, "EXPERIENCE")

    return session.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()


def get_tracked_documents_for_candidate(session: Session, candidate_id: int) -> list:
    """Fetches all document tracker entries for a candidate."""
    return session.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()


def update_document_status(session: Session, tracker_id: int, status_id: int, comments: str = None):
    """
    Updates the status of a document in DOCUMENT_TRACKER.
    Status IDs: 1=Pending, 5=Verified, 6=Rejected, 7=Completed.
    """
    record = session.query(DocumentTracker).filter(
        DocumentTracker.DOCUMENT_TRACKER_ID == tracker_id
    ).first()
    if record:
        record.STATUS_ID = status_id
        record.UPDATED_ON = date.today()
        if comments:
            record.COMMENTS = comments
        logger.info(f"Updated document tracker {tracker_id} to status {status_id}")


def mark_verified_documents(session: Session, candidate_id: int, verified_doc_type_ids: list):
    """
    Marks specific document types as Verified (5) in DOCUMENT_TRACKER for a candidate.
    """
    for doc_type_id in verified_doc_type_ids:
        records = session.query(DocumentTracker).filter(
            DocumentTracker.CANDIDATE_ID == candidate_id,
            DocumentTracker.DOCUMENT_TYPE_ID == doc_type_id,
            DocumentTracker.STATUS_ID == 1,  # Only update pending ones
            DocumentTracker.IS_ACTIVE == 1,
        ).all()
        for record in records:
            record.STATUS_ID = 5  # Verified
            record.UPDATED_ON = date.today()


def check_all_documents_complete(session: Session, candidate_id: int, candidate_type_id: int) -> bool:
    """
    Checks if all required documents for a candidate are verified or completed.
    Returns True if there are no pending documents.
    """
    required = get_required_documents_for_candidate(session, candidate_type_id)
    required_ids = {doc.DOCUMENT_TYPE_ID for doc in required}

    tracked = get_tracked_documents_for_candidate(session, candidate_id)
    verified_ids = {
        doc.DOCUMENT_TYPE_ID for doc in tracked
        if doc.STATUS_ID in (5, 7)  # Verified or Completed
    }

    return required_ids.issubset(verified_ids)
