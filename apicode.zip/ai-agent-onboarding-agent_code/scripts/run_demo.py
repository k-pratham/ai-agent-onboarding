"""
HR Agentic Onboarding System — Interactive Demo Runner

Walks a presenter through the full candidate onboarding lifecycle,
one step at a time, with pauses, summaries, and clear narration.

Modes:
    python -m scripts.run_demo                     # interactive walkthrough (default)
    python -m scripts.run_demo --auto              # run everything without pausing
    python -m scripts.run_demo --step etl          # run a single step
    python -m scripts.run_demo --step api          # start only the FastAPI server

Steps:
    seed     — Seed master lookup tables
    etl      — ETL Pipeline (Excel -> DB)
    draft    — Draft emails for pending jobs
    inbox    — Read inbox + trigger AI agent
    api      — Start FastAPI HR dashboard
    send     — Auto-approve and send all pending drafted mails
    simulate — Full 6-step lifecycle simulation for a candidate (--cin required)
"""

import os
import sys
import argparse
import asyncio
import logging
import textwrap
from datetime import datetime, date, timedelta

# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("demo")

from constants.common_functions import get_config, get_db_uri
from constants.database import _get_session
from constants.constants import (
    STATUS_PENDING_ID, STATUS_MAIL_DRAFTED_ID, STATUS_MAIL_SENT_ID,
    STATUS_MAIL_RECEIVED_ID, STATUS_VERIFIED_ID, STATUS_REJECTED_ID,
    STATUS_COMPLETED_ID,
    JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID, JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
    JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID, JOB_TYPE_ATTACHMENTS_SAVED_ID,
    JOB_TYPE_ONBOARDING_MAIL_ID, JOB_TYPE_IT_ADMIN_MAIL_ID,
)

DB_URI = get_db_uri()
EXCEL_PATH = os.getenv(
    "EXCEL_PATH",
    os.path.join(PROJECT_ROOT, "etl_pipeline", "excel_offer_tracker", "Offer_tracker.xlsx"),
)

AUTO_MODE = False  # set by --auto flag


# ---------------------------------------------------------------------------
# Presentation helpers
# ---------------------------------------------------------------------------
def _banner(title: str):
    width = 64
    print()
    print("=" * width)
    print(f"  {title}".center(width))
    print("=" * width)


def _narrate(text: str):
    """Print a narrative block that explains what is about to happen."""
    wrapped = textwrap.fill(text, width=72, initial_indent="  ", subsequent_indent="  ")
    print(f"\n{wrapped}\n")


def _pause(prompt: str = "Press ENTER to continue (or 'q' to quit)..."):
    if AUTO_MODE:
        return
    try:
        resp = input(f"  >> {prompt} ")
        if resp.strip().lower() in ("q", "quit", "exit"):
            print("\nDemo stopped by presenter.")
            sys.exit(0)
    except (EOFError, KeyboardInterrupt):
        print("\nDemo stopped.")
        sys.exit(0)


def _run_async(coro):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


def _print_table(rows: list[dict], columns: list[str], max_col_width: int = 30):
    """Prints a simple ASCII table."""
    if not rows:
        print("  (no data)")
        return
    # Compute column widths
    widths = {c: len(c) for c in columns}
    for row in rows:
        for c in columns:
            val = str(row.get(c, ""))
            if len(val) > max_col_width:
                val = val[:max_col_width - 3] + "..."
            widths[c] = max(widths[c], len(val))

    header = "  " + " | ".join(c.ljust(widths[c]) for c in columns)
    sep = "  " + "-+-".join("-" * widths[c] for c in columns)
    print(header)
    print(sep)
    for row in rows:
        vals = []
        for c in columns:
            v = str(row.get(c, ""))
            if len(v) > max_col_width:
                v = v[:max_col_width - 3] + "..."
            vals.append(v.ljust(widths[c]))
        print("  " + " | ".join(vals))
    print()


# ---------------------------------------------------------------------------
# DB summary helpers
# ---------------------------------------------------------------------------
def _show_candidate_summary():
    """Shows a summary of candidates in the DB."""
    from etl_pipeline.models.schema import CandidateInfo
    session = _get_session()
    try:
        candidates = session.query(CandidateInfo).order_by(CandidateInfo.CANDIDATE_ID.desc()).limit(10).all()
        rows = [
            {"ID": c.CANDIDATE_ID, "CIN": c.CIN, "Name": c.CANDIDATE_NAME or "-",
             "Email": c.PERSONAL_EMAIL_ID or "-", "DOJ": str(c.EXPECTED_DOJ_WRT_TO_NP or "-")}
            for c in candidates
        ]
        print(f"\n  Candidates in DB: {session.query(CandidateInfo).count()} total (showing latest 10)")
        _print_table(rows, ["ID", "CIN", "Name", "Email", "DOJ"])
    finally:
        session.close()


def _show_job_summary():
    """Shows a summary of jobs in the DB."""
    from etl_pipeline.models.schema import JobTracker, CandidateInfo, JobTypeMaster
    session = _get_session()
    try:
        jobs = (
            session.query(JobTracker, CandidateInfo, JobTypeMaster)
            .join(CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID)
            .join(JobTypeMaster, JobTracker.JOB_TYPE_ID == JobTypeMaster.JOB_TYPE_ID)
            .order_by(JobTracker.JOB_ID.desc())
            .limit(10)
            .all()
        )
        status_map = {1: "Pending", 2: "Drafted", 3: "Sent", 4: "Received",
                      5: "Verified", 6: "Rejected", 7: "Completed"}
        rows = [
            {
                "Job": j.JOB_ID,
                "Type": f"{jt.JOB_TYPE}/{jt.JOB_SUBTYPE}",
                "CIN": c.CIN,
                "Status": status_map.get(j.STATUS_ID, str(j.STATUS_ID)),
                "Action Date": str(j.ACTION_DATE or "-"),
                "HR Action": "Yes" if j.HUMAN_ACTION_REQUIRED else "No",
            }
            for j, c, jt in jobs
        ]
        total = session.query(JobTracker).count()
        print(f"\n  Jobs in DB: {total} total (showing latest 10)")
        _print_table(rows, ["Job", "Type", "CIN", "Status", "Action Date", "HR Action"])
    finally:
        session.close()


def _show_draft_preview(limit: int = 2):
    """Shows the latest drafted emails."""
    from etl_pipeline.models.schema import JobTracker, CandidateInfo
    session = _get_session()
    try:
        drafted = (
            session.query(JobTracker, CandidateInfo)
            .join(CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID)
            .filter(JobTracker.STATUS_ID == STATUS_MAIL_DRAFTED_ID)
            .order_by(JobTracker.JOB_ID.desc())
            .limit(limit)
            .all()
        )
        if not drafted:
            print("\n  No drafted emails to preview.")
            return
        for job, cand in drafted:
            print(f"\n  --- Draft for {cand.CANDIDATE_NAME or cand.CIN} (Job {job.JOB_ID}) ---")
            draft_text = (job.DRAFT_MAIL or "(empty)")[:500]
            for line in draft_text.split("\n"):
                print(f"  | {line}")
            if len(job.DRAFT_MAIL or "") > 500:
                print("  | ... (truncated)")
            print()
    finally:
        session.close()


def _show_document_tracker(cin: str = None):
    """Shows document tracker status for a candidate or all."""
    from etl_pipeline.models.schema import DocumentTracker, CandidateInfo, DocumentTypeMaster
    session = _get_session()
    try:
        query = (
            session.query(DocumentTracker, CandidateInfo, DocumentTypeMaster)
            .join(CandidateInfo, DocumentTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID)
            .join(DocumentTypeMaster, DocumentTracker.DOCUMENT_TYPE_ID == DocumentTypeMaster.DOCUMENT_TYPE_ID)
            .filter(DocumentTracker.IS_ACTIVE == 1)
        )
        if cin:
            query = query.filter(CandidateInfo.CIN == cin)
        records = query.order_by(DocumentTracker.CANDIDATE_ID).limit(20).all()

        status_map = {1: "Pending", 5: "Verified", 6: "Rejected", 7: "Completed"}
        rows = [
            {
                "CIN": c.CIN,
                "Document": dt.DOCUMENT_NAME,
                "Status": status_map.get(d.STATUS_ID, str(d.STATUS_ID)),
                "Comments": (d.COMMENTS or "-")[:40],
            }
            for d, c, dt in records
        ]
        label = f"for {cin}" if cin else "(all candidates, max 20)"
        print(f"\n  Document Tracker {label}:")
        _print_table(rows, ["CIN", "Document", "Status", "Comments"])
    finally:
        session.close()


# ===================================================================
# STEP 0 — Seed Master Data
# ===================================================================
def run_seed():
    _banner("STEP 0: Seed Master Data")
    _narrate(
        "Initializing the lookup tables that drive the system: "
        "StatusMaster (7 statuses), JobTypeMaster (7 job types), "
        "DocumentTypeMaster (8 document types for Fresher/Experience/DevPartner), "
        "CandidateTypeMaster, and MailTypeMaster (email templates)."
    )
    _pause()

    from scripts.seed_master_data import seed_data
    seed_data()
    logger.info("Seed complete.")


# ===================================================================
# STEP 1 — ETL Pipeline
# ===================================================================
def run_etl():
    _banner("STEP 1: ETL Pipeline  (Excel -> Database)")
    _narrate(
        "Reading the Offer Tracker Excel sheet. For each candidate: "
        "generate a unique CIN (YYYYMMDD_REFNO), compute a row hash "
        "for change detection, and load into CANDIDATE_INFO. "
        "A 'mail_send / documents_required' job is created for each "
        "new candidate with ACTION_DATE based on the 60-day-before-DOJ rule."
    )
    _pause()

    from etl_pipeline.extract.excel_reader import extract_excel_data
    from etl_pipeline.transform.transformer import transform_candidate_data
    from etl_pipeline.load.db_loader import load_data

    if not os.path.exists(EXCEL_PATH):
        logger.error(f"Excel file not found at: {EXCEL_PATH}")
        print(f"\n  Set EXCEL_PATH env var or place Offer_tracker.xlsx at:\n  {EXCEL_PATH}")
        return

    logger.info(f"Reading: {EXCEL_PATH}")
    raw_data = extract_excel_data(EXCEL_PATH)

    logger.info("Transforming (CIN, row hash, column mapping)...")
    transformed = transform_candidate_data(raw_data)
    logger.info(f"Transformed {len(transformed)} rows from {len(raw_data)} sheet(s).")

    logger.info("Loading into database...")
    session = _get_session()
    try:
        load_data(session, transformed)
    finally:
        session.close()

    logger.info("ETL complete.")
    _show_candidate_summary()
    _show_job_summary()
    _pause()


# ===================================================================
# STEP 2 — Mail Drafting
# ===================================================================
def run_mail_draft():
    _banner("STEP 2: Draft Emails for Pending Jobs")
    _narrate(
        "Scanning JOB_TRACKER for pending mail_send jobs with "
        "ACTION_DATE <= today. Three cases are handled:\n\n"
        "  Case 1 (documents_required): Template-based initial email — no LLM.\n"
        "  Case 2 (follow_up): LLM generates reminder when candidate hasn't replied.\n"
        "  Case 3 (pending_documents): LLM generates request for specific missing docs.\n\n"
        "Each draft is saved to JOB_TRACKER.DRAFT_MAIL and flagged for HR approval."
    )
    _pause()

    from etl_pipeline.models.schema import JobTracker, CandidateInfo
    from mcp_server.draft_prepare.engine.helper_func import generate_and_save_draft

    session = _get_session()
    today = date.today()

    mail_job_type_ids = [
        JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
        JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
        JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID,
    ]

    try:
        pending = session.query(JobTracker, CandidateInfo).join(
            CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID
        ).filter(
            JobTracker.JOB_TYPE_ID.in_(mail_job_type_ids),
            JobTracker.STATUS_ID == STATUS_PENDING_ID,
            JobTracker.ACTION_DATE <= today,
        ).all()

        logger.info(f"Found {len(pending)} pending mail job(s) with ACTION_DATE <= {today}")

        if not pending:
            print("\n  No pending jobs to process right now.")
            print("  (Jobs are created by the ETL step with future ACTION_DATEs.)")
            _pause()
            return

        drafted = 0
        for job, candidate in pending:
            cin = candidate.CIN
            try:
                draft = generate_and_save_draft(cin, job.JOB_ID)
                if draft.startswith("Error:"):
                    logger.warning(f"  {cin}: {draft}")
                    continue
                drafted += 1
                logger.info(f"  {cin}: Draft generated for Job {job.JOB_ID}")
            except Exception as e:
                logger.error(f"  {cin}: Failed - {e}")

        logger.info(f"Drafted {drafted} email(s).")
    except Exception as e:
        logger.error(f"Mail drafting failed: {e}")
        raise
    finally:
        session.close()

    _show_job_summary()
    _show_draft_preview()
    _pause()


# ===================================================================
# STEP 3 — Inbox Reader + AI Agent
# ===================================================================
def run_inbox_reader():
    _banner("STEP 3: Read Inbox + AI Agent Processing")
    _narrate(
        "Connecting to Exchange via EWS to fetch unread candidate replies. "
        "For each reply:\n"
        "  1. Extract CIN from subject (or resolve via sender email).\n"
        "  2. Deactivate pending follow-up jobs for that candidate.\n"
        "  3. Save attachments to the candidate's CIN folder.\n"
        "  4. Trigger the LangGraph AI agent which orchestrates:\n"
        "     OCR classification (numarkdown-8b) -> Identity validation ->\n"
        "     Document segregation -> Gap analysis -> Follow-up drafting."
    )
    _pause()

    from mcp_server.read_inbox.tools.read_inbox import tool_read_inbox
    from mcp_server.save_attachment.tools.save_attachment import tool_save_attachment

    inbox_result = _run_async(tool_read_inbox())

    if inbox_result.get("status") == "empty":
        logger.info("No unread emails found in inbox.")
        print("\n  To simulate this step, send a test email with a CIN in the subject")
        print("  and document attachments to the configured inbox.")
        _pause()
        return

    candidates = inbox_result.get("candidates", [])
    logger.info(f"Found {len(candidates)} distinct candidate(s) with replies.")

    for cdata in candidates:
        cin = cdata["cin"]
        has_attachments = cdata["has_attachments"]
        attachments = cdata.get("attachments", [])
        job_id = cdata.get("job_id")

        if not has_attachments:
            logger.info(f"  {cin}: Reply with no attachments - follow-up deactivated.")
            continue

        saved = []
        for att in attachments:
            res = _run_async(tool_save_attachment(cin, att["filename"], att["data"], job_id))
            saved.append(res)
            logger.info(f"  {cin}: Saved {att['filename']}")

        logger.info(f"  {cin}: Triggering AI agent for {len(saved)} attachment(s)...")
        try:
            _trigger_agent(cin, cdata["candidate_id"], saved)
            logger.info(f"  {cin}: Agent completed.")
        except Exception as e:
            logger.error(f"  {cin}: Agent failed - {e}")

    logger.info("Inbox processing complete.")
    _show_document_tracker()
    _pause()


def _trigger_agent(cin: str, candidate_id: int, saved_files: list):
    from ai_onboarding_brain.src.core.agent import get_compiled_orchestrator
    from ai_onboarding_brain.src.core.database import SessionLocal
    from langchain_core.messages import HumanMessage

    db = SessionLocal()
    try:
        orchestrator = get_compiled_orchestrator(db)
        config = {"configurable": {"thread_id": f"CANDIDATE_{cin}"}}
        prompt = (
            f"Candidate CIN {cin} has uploaded {len(saved_files)} document(s). "
            f"Process each: OCR classification, identity validation, gap analysis, "
            f"and draft a follow-up if documents are missing."
        )
        result = orchestrator.invoke(
            {"messages": [HumanMessage(content=prompt)]}, config=config,
        )
        logger.info(f"  {cin}: Agent finished ({len(result['messages'])} messages).")
    finally:
        db.close()


# ===================================================================
# STEP 4 — FastAPI HR Dashboard
# ===================================================================
def run_api():
    _banner("STEP 4: HR Dashboard API")
    _narrate(
        "Starting the FastAPI server for the HR Dashboard. Available endpoints:\n\n"
        "  GET  /health                              - Health check\n"
        "  GET  /api/v1/dashboard/pending-drafts      - Drafts awaiting HR approval\n"
        "  GET  /api/v1/dashboard/candidate-status/CIN - Document status for a candidate\n"
        "  POST /api/v1/action/approve-draft           - Approve & send a drafted email\n"
        "  POST /api/v1/action/check-escalation/ID     - Check escalation for a candidate\n"
        "  POST /api/v1/action/complete-onboarding/ID  - Trigger completion mails\n\n"
        "Swagger UI will be available at http://localhost:8080/docs"
    )
    _pause("Press ENTER to start the server (Ctrl+C to stop)...")

    import uvicorn
    logger.info("Starting on http://0.0.0.0:8080")
    uvicorn.run(
        "ai_onboarding_brain.src.main:app",
        host="0.0.0.0",
        port=8080,
        reload=False,
    )


# ===================================================================
# STEP 5 — Auto-Send All Drafted Mails
# ===================================================================
def run_send(dry_run: bool = False):
    _banner("STEP 5: Auto-Approve & Send All Pending Drafts")
    _narrate(
        "Querying JOB_TRACKER for all emails in 'Drafted' status "
        "(STATUS_ID=2, HUMAN_ACTION_REQUIRED=1). Each draft is approved "
        "and dispatched via EWS — exactly like an HR user clicking 'Send' "
        "in the dashboard. Post-send actions (document tracker insertion, "
        "follow-up job creation) are triggered automatically."
    )
    _pause()

    from etl_pipeline.models.schema import JobTracker, CandidateInfo

    session = _get_session()
    try:
        drafted_jobs = (
            session.query(JobTracker, CandidateInfo)
            .join(CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID)
            .filter(
                JobTracker.STATUS_ID == STATUS_MAIL_DRAFTED_ID,
                JobTracker.HUMAN_ACTION_REQUIRED == 1,
            )
            .order_by(JobTracker.JOB_ID)
            .all()
        )

        if not drafted_jobs:
            print("\n  No drafted emails pending approval.")
            print("  Run '--step draft' first to generate drafts.")
            _pause()
            return

        logger.info(f"Found {len(drafted_jobs)} drafted email(s) to send.")

        sent = 0
        failed = 0
        for job, candidate in drafted_jobs:
            cin = candidate.CIN
            email = candidate.PERSONAL_EMAIL_ID or ""
            subject = f"HR Onboarding - CIN {cin}"
            body = job.DRAFT_MAIL or ""

            # Derive a better subject from job type
            if job.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID:
                subject = f"Document Submission Required - CIN {cin}"
            elif job.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID:
                subject = f"Follow-up: Pending Document Submission - CIN {cin}"
            elif job.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID:
                subject = f"Pending Documents Reminder - CIN {cin}"

            print(f"  [{sent + failed + 1}/{len(drafted_jobs)}] Job {job.JOB_ID} | "
                  f"{cin} | {candidate.CANDIDATE_NAME or '-'} | -> {email}")

            if dry_run:
                print(f"    [DRY RUN] Would send: {subject}")
                sent += 1
                continue

            if not email:
                logger.warning(f"  {cin}: No email address — skipping.")
                failed += 1
                continue

            try:
                from mcp_server.send_email.tools.send_email import tool_send_email
                _run_async(tool_send_email(email, subject, body))

                # Update job tracker — same as mail_service.send_mail
                today = date.today()
                job.STATUS_ID = STATUS_MAIL_SENT_ID
                job.HUMAN_ACTION_REQUIRED = 0
                job.HUMAN_ACTION = "Auto-approved via demo runner"
                job.UPDATED_ON = today

                # Post-send: insert document tracker entries for initial mail
                if job.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID:
                    from ai_onboarding_brain.src.services.hr_service import _insert_required_documents
                    ctype = candidate.CANDIDATE_TYPE_ID or 2
                    _insert_required_documents(session, candidate.CANDIDATE_ID, ctype, job.JOB_ID)

                    # Create follow-up job
                    followup = JobTracker(
                        JOB_TYPE_ID=JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
                        CANDIDATE_ID=candidate.CANDIDATE_ID,
                        HUMAN_ACTION_REQUIRED=0,
                        STATUS_ID=STATUS_PENDING_ID,
                        ACTION_DATE=today + timedelta(days=2),
                        UPDATED_ON=today,
                    )
                    session.add(followup)

                elif job.JOB_TYPE_ID in (JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
                                         JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID):
                    # Create next follow-up
                    next_followup = JobTracker(
                        JOB_TYPE_ID=JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
                        CANDIDATE_ID=candidate.CANDIDATE_ID,
                        HUMAN_ACTION_REQUIRED=0,
                        STATUS_ID=STATUS_PENDING_ID,
                        ACTION_DATE=today + timedelta(days=2),
                        UPDATED_ON=today,
                    )
                    session.add(next_followup)

                session.commit()
                sent += 1
                logger.info(f"    Sent successfully.")
            except Exception as e:
                session.rollback()
                failed += 1
                logger.error(f"    Failed: {e}")

        print(f"\n  Results: {sent} sent, {failed} failed out of {len(drafted_jobs)} total.")
    finally:
        session.close()

    _show_job_summary()
    _pause()


# ===================================================================
# STEP 6 — Full Lifecycle Simulation
# ===================================================================
def run_simulate(cin: str = None, dry_run: bool = False):
    _banner("STEP 6: Full 6-Step Lifecycle Simulation")
    _narrate(
        "Simulates the complete onboarding journey for a single candidate, "
        "stepping through all 6 phases without needing the Angular frontend:\n\n"
        "  Step 1: Verify offer released (OFFER_RELEASE_DATE present)\n"
        "  Step 2: Generate & send document-required mail\n"
        "  Step 3: Generate & send follow-up mail\n"
        "  Step 4: Simulate document receipt + auto-approve all docs\n"
        "  Step 5: Generate & send onboarding welcome mail\n"
        "  Step 6: Generate & send IT provisioning mail\n\n"
        "Each step updates the database exactly as the real API would."
    )

    from etl_pipeline.models.schema import (
        CandidateInfo, JobTracker, DocumentTracker, DocumentTypeMaster,
    )
    from constants.constants import CANDIDATE_TYPE_COLUMN_MAP

    session = _get_session()
    try:
        # --- Pick a candidate ---
        if cin:
            candidate = session.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()
            if not candidate:
                logger.error(f"Candidate CIN '{cin}' not found in database.")
                return
        else:
            # Pick the first candidate that has an offer date and is not a dropout
            candidate = (
                session.query(CandidateInfo)
                .filter(
                    CandidateInfo.OFFER_RELEASE_DATE.isnot(None),
                    CandidateInfo.REASON_FOR_DROP_OUT.is_(None),
                )
                .order_by(CandidateInfo.CANDIDATE_ID)
                .first()
            )
            if not candidate:
                logger.error("No eligible candidate found. Run '--step seed etl' first.")
                return

        cin = candidate.CIN
        name = candidate.CANDIDATE_NAME or cin
        email = candidate.PERSONAL_EMAIL_ID or "demo@example.com"
        ctype = candidate.CANDIDATE_TYPE_ID or 2
        today = date.today()

        print(f"\n  Candidate : {name}")
        print(f"  CIN       : {cin}")
        print(f"  Email     : {email}")
        print(f"  Type      : {ctype} ({CANDIDATE_TYPE_COLUMN_MAP.get(ctype, 'EXPERIENCE')})")
        print(f"  DOJ       : {candidate.EXPECTED_DOJ_WRT_TO_NP or 'N/A'}")
        _pause()

        # =============================================================
        # STEP 1: Offer Released
        # =============================================================
        _banner("Simulate Step 1/6: Offer Released")
        if candidate.OFFER_RELEASE_DATE:
            print(f"  Offer already released on {candidate.OFFER_RELEASE_DATE}.")
            logger.info("Step 1 complete — offer release date exists.")
        else:
            candidate.OFFER_RELEASE_DATE = today
            candidate.UPDATED_ON = today
            session.commit()
            logger.info(f"Step 1 complete — set OFFER_RELEASE_DATE to {today}.")
        _pause()

        # =============================================================
        # STEP 2: Document Required Mail
        # =============================================================
        _banner("Simulate Step 2/6: Document Required Mail")
        _narrate(
            "Generating an initial document-request email and dispatching it. "
            "After send, DOCUMENT_TRACKER entries are created for all required "
            "documents, and a follow-up job is scheduled for 2 days later."
        )
        _pause()

        # Check if step 2 already done
        step2_job = session.query(JobTracker).filter(
            JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
            JobTracker.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
            JobTracker.STATUS_ID == STATUS_MAIL_SENT_ID,
        ).first()

        if step2_job:
            print(f"  Step 2 already completed (Job {step2_job.JOB_ID}).")
        else:
            # Generate draft
            from ai_onboarding_brain.src.services.mail_service import _generate_step2_draft, _get_pending_doc_names
            pending_docs = _get_pending_doc_names(session, candidate.CANDIDATE_ID, ctype)
            if not pending_docs:
                # No doc tracker yet, get required doc names from master
                col_name = CANDIDATE_TYPE_COLUMN_MAP.get(ctype, "EXPERIENCE")
                required = session.query(DocumentTypeMaster).filter(
                    DocumentTypeMaster.IS_ACTIVE == 1,
                    getattr(DocumentTypeMaster, col_name) == 1,
                ).all()
                pending_docs = [d.DOCUMENT_NAME for d in required]

            draft_body = _generate_step2_draft(candidate, pending_docs)
            subject = f"Document Submission Required - CIN {cin}"

            print(f"  Draft generated ({len(draft_body)} chars)")
            print(f"  To: {email}")
            print(f"  Subject: {subject}")
            _show_draft_snippet(draft_body)

            if not dry_run:
                try:
                    from mcp_server.send_email.tools.send_email import tool_send_email
                    _run_async(tool_send_email(email, subject, draft_body))
                    logger.info("  Email dispatched via EWS.")
                except Exception as e:
                    logger.warning(f"  Email dispatch failed (continuing): {e}")

            # Create/update job tracker
            existing_job = session.query(JobTracker).filter(
                JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
                JobTracker.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
            ).first()
            if existing_job:
                existing_job.STATUS_ID = STATUS_MAIL_SENT_ID
                existing_job.DRAFT_MAIL = draft_body
                existing_job.HUMAN_ACTION_REQUIRED = 0
                existing_job.HUMAN_ACTION = "Simulated send"
                existing_job.UPDATED_ON = today
            else:
                new_job = JobTracker(
                    JOB_TYPE_ID=JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
                    CANDIDATE_ID=candidate.CANDIDATE_ID,
                    STATUS_ID=STATUS_MAIL_SENT_ID,
                    DRAFT_MAIL=draft_body,
                    HUMAN_ACTION_REQUIRED=0,
                    HUMAN_ACTION="Simulated send",
                    ACTION_DATE=today,
                    UPDATED_ON=today,
                )
                session.add(new_job)
                session.flush()

            # Insert document tracker entries
            from ai_onboarding_brain.src.services.hr_service import _insert_required_documents
            job_id = existing_job.JOB_ID if existing_job else new_job.JOB_ID
            _insert_required_documents(session, candidate.CANDIDATE_ID, ctype, job_id)

            # Create follow-up job
            followup = JobTracker(
                JOB_TYPE_ID=JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
                CANDIDATE_ID=candidate.CANDIDATE_ID,
                STATUS_ID=STATUS_PENDING_ID,
                HUMAN_ACTION_REQUIRED=0,
                ACTION_DATE=today + timedelta(days=2),
                UPDATED_ON=today,
            )
            session.add(followup)
            session.commit()
            logger.info("  Step 2 complete — mail sent, doc tracker populated, follow-up scheduled.")

        _show_document_tracker(cin)
        _pause()

        # =============================================================
        # STEP 3: Follow-up Mail
        # =============================================================
        _banner("Simulate Step 3/6: Follow-up Mail Drop")
        _narrate(
            "Generating and sending a follow-up reminder for pending documents. "
            "In production this happens 2 days after step 2 if no reply is received."
        )
        _pause()

        step3_job = session.query(JobTracker).filter(
            JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
            JobTracker.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
            JobTracker.STATUS_ID == STATUS_MAIL_SENT_ID,
        ).first()

        if step3_job:
            print(f"  Step 3 already completed (Job {step3_job.JOB_ID}).")
        else:
            from ai_onboarding_brain.src.services.mail_service import _generate_step3_draft, _get_pending_doc_names
            pending_docs = _get_pending_doc_names(session, candidate.CANDIDATE_ID, ctype)
            draft_body = _generate_step3_draft(candidate, pending_docs)
            subject = f"Follow-up: Pending Document Submission - CIN {cin}"

            print(f"  Draft generated ({len(draft_body)} chars)")
            _show_draft_snippet(draft_body)

            if not dry_run:
                try:
                    from mcp_server.send_email.tools.send_email import tool_send_email
                    _run_async(tool_send_email(email, subject, draft_body))
                    logger.info("  Email dispatched.")
                except Exception as e:
                    logger.warning(f"  Email dispatch failed (continuing): {e}")

            # Update or create job
            pending_followup = session.query(JobTracker).filter(
                JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
                JobTracker.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
                JobTracker.STATUS_ID == STATUS_PENDING_ID,
            ).first()
            if pending_followup:
                pending_followup.STATUS_ID = STATUS_MAIL_SENT_ID
                pending_followup.DRAFT_MAIL = draft_body
                pending_followup.HUMAN_ACTION_REQUIRED = 0
                pending_followup.HUMAN_ACTION = "Simulated send"
                pending_followup.UPDATED_ON = today
            else:
                new_job = JobTracker(
                    JOB_TYPE_ID=JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
                    CANDIDATE_ID=candidate.CANDIDATE_ID,
                    STATUS_ID=STATUS_MAIL_SENT_ID,
                    DRAFT_MAIL=draft_body,
                    HUMAN_ACTION_REQUIRED=0,
                    HUMAN_ACTION="Simulated send",
                    ACTION_DATE=today,
                    UPDATED_ON=today,
                )
                session.add(new_job)

            session.commit()
            logger.info("  Step 3 complete — follow-up mail sent.")
        _pause()

        # =============================================================
        # STEP 4: Document Receipt + Auto-Approve
        # =============================================================
        _banner("Simulate Step 4/6: Document Receipt & Verification")
        _narrate(
            "Simulating that the candidate has replied with all required documents. "
            "Each DOCUMENT_TRACKER entry is marked as received and then verified "
            "(STATUS_ID=5). In production, the AI agent would OCR-classify each "
            "attachment and HR would approve via the dashboard."
        )
        _pause()

        doc_trackers = session.query(DocumentTracker).filter(
            DocumentTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
            DocumentTracker.IS_ACTIVE == 1,
        ).all()

        if not doc_trackers:
            logger.warning("  No document tracker entries found — step 2 may not have run.")
        else:
            all_verified = all(
                d.STATUS_ID in (STATUS_VERIFIED_ID, STATUS_COMPLETED_ID)
                for d in doc_trackers
            )
            if all_verified:
                print(f"  All {len(doc_trackers)} documents already verified.")
            else:
                approved = 0
                for tracker in doc_trackers:
                    if tracker.STATUS_ID in (STATUS_VERIFIED_ID, STATUS_COMPLETED_ID):
                        continue
                    doc_type = session.query(DocumentTypeMaster).filter(
                        DocumentTypeMaster.DOCUMENT_TYPE_ID == tracker.DOCUMENT_TYPE_ID
                    ).first()
                    doc_name = doc_type.DOCUMENT_NAME if doc_type else f"Type#{tracker.DOCUMENT_TYPE_ID}"

                    tracker.STATUS_ID = STATUS_VERIFIED_ID
                    tracker.DOCUMENT_RECIVED_ON = today
                    tracker.COMMENTS = "Auto-verified via simulation"
                    tracker.UPDATED_ON = today
                    approved += 1
                    print(f"    Verified: {doc_name}")

                session.commit()
                logger.info(f"  Step 4 complete — {approved} document(s) verified.")

        _show_document_tracker(cin)

        # Check if all docs verified triggers step 5 job
        from ai_onboarding_brain.src.services.document_service import _check_and_trigger_completion
        _check_and_trigger_completion(session, candidate.CANDIDATE_ID)
        session.commit()
        _pause()

        # =============================================================
        # STEP 5: Onboarding Welcome Mail
        # =============================================================
        _banner("Simulate Step 5/6: Onboarding Welcome Mail")
        _narrate(
            "All documents are verified. Generating a welcome/joining-confirmation "
            "email to the candidate with DOJ, designation, and location details."
        )
        _pause()

        step5_job = session.query(JobTracker).filter(
            JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
            JobTracker.JOB_TYPE_ID == JOB_TYPE_ONBOARDING_MAIL_ID,
            JobTracker.STATUS_ID == STATUS_MAIL_SENT_ID,
        ).first()

        if step5_job:
            print(f"  Step 5 already completed (Job {step5_job.JOB_ID}).")
        else:
            from ai_onboarding_brain.src.services.mail_service import _generate_step5_draft
            draft_body = _generate_step5_draft(candidate)
            subject = f"Welcome Aboard - Joining Confirmation - {name}"

            print(f"  To: {email}")
            print(f"  Subject: {subject}")
            _show_draft_snippet(draft_body)

            if not dry_run:
                try:
                    from mcp_server.send_email.tools.send_email import tool_send_email
                    _run_async(tool_send_email(email, subject, draft_body))
                    logger.info("  Email dispatched.")
                except Exception as e:
                    logger.warning(f"  Email dispatch failed (continuing): {e}")

            # Update or create job
            pending_step5 = session.query(JobTracker).filter(
                JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
                JobTracker.JOB_TYPE_ID == JOB_TYPE_ONBOARDING_MAIL_ID,
            ).first()
            if pending_step5:
                pending_step5.STATUS_ID = STATUS_MAIL_SENT_ID
                pending_step5.DRAFT_MAIL = draft_body
                pending_step5.HUMAN_ACTION_REQUIRED = 0
                pending_step5.HUMAN_ACTION = "Simulated send"
                pending_step5.UPDATED_ON = today
            else:
                new_job = JobTracker(
                    JOB_TYPE_ID=JOB_TYPE_ONBOARDING_MAIL_ID,
                    CANDIDATE_ID=candidate.CANDIDATE_ID,
                    STATUS_ID=STATUS_MAIL_SENT_ID,
                    DRAFT_MAIL=draft_body,
                    HUMAN_ACTION_REQUIRED=0,
                    HUMAN_ACTION="Simulated send",
                    ACTION_DATE=today,
                    UPDATED_ON=today,
                )
                session.add(new_job)

            # Create IT admin job for step 6
            existing_it = session.query(JobTracker).filter(
                JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
                JobTracker.JOB_TYPE_ID == JOB_TYPE_IT_ADMIN_MAIL_ID,
            ).first()
            if not existing_it:
                it_job = JobTracker(
                    JOB_TYPE_ID=JOB_TYPE_IT_ADMIN_MAIL_ID,
                    CANDIDATE_ID=candidate.CANDIDATE_ID,
                    STATUS_ID=STATUS_PENDING_ID,
                    HUMAN_ACTION_REQUIRED=1,
                    REMARK="IT provisioning request pending",
                    ACTION_DATE=today,
                    UPDATED_ON=today,
                )
                session.add(it_job)

            session.commit()
            logger.info("  Step 5 complete — welcome mail sent, IT admin job created.")
        _pause()

        # =============================================================
        # STEP 6: IT Provisioning Mail
        # =============================================================
        _banner("Simulate Step 6/6: IT Admin Provisioning Mail")
        _narrate(
            "Sending the IT provisioning request email to the IT admin with "
            "the candidate's details: name, CIN, designation, technology, "
            "location, and expected DOJ. This is the final step."
        )
        _pause()

        step6_job = session.query(JobTracker).filter(
            JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
            JobTracker.JOB_TYPE_ID == JOB_TYPE_IT_ADMIN_MAIL_ID,
            JobTracker.STATUS_ID == STATUS_MAIL_SENT_ID,
        ).first()

        if step6_job:
            print(f"  Step 6 already completed (Job {step6_job.JOB_ID}).")
        else:
            from ai_onboarding_brain.src.services.mail_service import _generate_step6_draft
            from ai_onboarding_brain.src.core.config import settings as app_settings

            draft_body = _generate_step6_draft(candidate)
            it_email = app_settings.IT_ADMIN_EMAIL
            subject = f"IT Provisioning Request - {name} (CIN {cin})"

            print(f"  To: {it_email}")
            print(f"  CC: {candidate.MANAGER_NAME or 'N/A'}")
            print(f"  Subject: {subject}")
            _show_draft_snippet(draft_body)

            if not dry_run:
                try:
                    from mcp_server.send_email.tools.send_email import tool_send_email
                    _run_async(tool_send_email(it_email, subject, draft_body))
                    logger.info("  Email dispatched.")
                except Exception as e:
                    logger.warning(f"  Email dispatch failed (continuing): {e}")

            pending_step6 = session.query(JobTracker).filter(
                JobTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
                JobTracker.JOB_TYPE_ID == JOB_TYPE_IT_ADMIN_MAIL_ID,
            ).first()
            if pending_step6:
                pending_step6.STATUS_ID = STATUS_MAIL_SENT_ID
                pending_step6.DRAFT_MAIL = draft_body
                pending_step6.HUMAN_ACTION_REQUIRED = 0
                pending_step6.HUMAN_ACTION = "Simulated send"
                pending_step6.UPDATED_ON = today
            else:
                new_job = JobTracker(
                    JOB_TYPE_ID=JOB_TYPE_IT_ADMIN_MAIL_ID,
                    CANDIDATE_ID=candidate.CANDIDATE_ID,
                    STATUS_ID=STATUS_MAIL_SENT_ID,
                    DRAFT_MAIL=draft_body,
                    HUMAN_ACTION_REQUIRED=0,
                    HUMAN_ACTION="Simulated send",
                    ACTION_DATE=today,
                    UPDATED_ON=today,
                )
                session.add(new_job)

            # Mark candidate as completed
            candidate.CURRENT_STATUS = "Completed"
            candidate.UPDATED_ON = today
            session.commit()
            logger.info("  Step 6 complete — IT provisioning mail sent.")

        # =============================================================
        # Summary
        # =============================================================
        _banner("Simulation Complete")
        print(f"  Candidate {name} (CIN: {cin}) has been fully onboarded!")
        print()
        _show_job_summary()
        _show_document_tracker(cin)

    except Exception as e:
        session.rollback()
        logger.error(f"Simulation failed: {e}")
        raise
    finally:
        session.close()


def _show_draft_snippet(body: str, max_lines: int = 8):
    """Print a truncated preview of a draft email."""
    lines = body.split("\n")
    print()
    for line in lines[:max_lines]:
        print(f"    | {line}")
    if len(lines) > max_lines:
        print(f"    | ... ({len(lines) - max_lines} more lines)")
    print()


# ===================================================================
# Full interactive walkthrough
# ===================================================================
STEPS = {
    "seed":     ("Seed Master Data",              run_seed),
    "etl":      ("ETL Pipeline",                  run_etl),
    "draft":    ("Draft Emails",                  run_mail_draft),
    "inbox":    ("Inbox Reader + AI Agent",       run_inbox_reader),
    "api":      ("HR Dashboard API",              run_api),
    "send":     ("Auto-Send All Drafts",          None),  # handled specially (needs dry_run)
    "simulate": ("Full Lifecycle Simulation",     None),  # handled specially (needs cin, dry_run)
}


def run_interactive():
    """Full guided walkthrough — the default demo mode."""
    _banner("HR Agentic Onboarding System")
    print(textwrap.dedent(f"""\
      Project root : {PROJECT_ROOT}
      Database     : {DB_URI}
      Excel source : {EXCEL_PATH}
      Date         : {date.today().isoformat()}

      This demo walks through the complete candidate onboarding lifecycle:

        Step 0  Seed master lookup tables
        Step 1  ETL: Excel Offer Tracker -> Database
        Step 2  AI-drafted onboarding emails (3 cases)
        Step 3  Inbox reader + AI agent (OCR, validation, gap analysis)
        Step 4  HR Dashboard API (approve drafts, view status)

      Each step pauses so you can explain what happened.
    """))
    _pause("Press ENTER to begin the demo...")

    run_seed()
    run_etl()
    run_mail_draft()
    run_inbox_reader()

    _banner("Pipeline Complete")
    _narrate(
        "The automated pipeline has finished. All candidates have been "
        "loaded, initial emails drafted, and any inbox replies processed "
        "by the AI agent. The HR Dashboard is ready for human-in-the-loop "
        "review and approval."
    )

    # Show final state
    _show_candidate_summary()
    _show_job_summary()
    _show_document_tracker()

    _pause("Press ENTER to start the HR Dashboard API, or 'q' to exit...")
    run_api()


# ===================================================================
# CLI
# ===================================================================
def main():
    parser = argparse.ArgumentParser(
        description="HR Agentic Onboarding — Interactive Demo Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
        Modes:
          (default)          Interactive walkthrough with pauses and summaries
          --auto             Run all steps without pausing
          --step STEP [...]  Run specific step(s) only

        Steps: seed, etl, draft, inbox, api, send, simulate

        Examples:
          python -m scripts.run_demo                              # interactive demo
          python -m scripts.run_demo --auto                        # batch mode
          python -m scripts.run_demo --step seed etl               # seed + ETL only
          python -m scripts.run_demo --step api                    # just the dashboard
          python -m scripts.run_demo --step send                   # auto-send all drafts
          python -m scripts.run_demo --step send --dry-run         # preview without sending
          python -m scripts.run_demo --step simulate --cin CIN123  # full lifecycle for CIN
          python -m scripts.run_demo --step simulate               # auto-pick first candidate
          python -m scripts.run_demo --step simulate --dry-run     # lifecycle without emails
        """),
    )
    parser.add_argument(
        "--step", nargs="+", choices=list(STEPS.keys()),
        help="Run specific step(s) instead of the full walkthrough.",
    )
    parser.add_argument(
        "--auto", action="store_true",
        help="Run without pausing between steps.",
    )
    parser.add_argument(
        "--cin", type=str, default=None,
        help="Candidate CIN for --step simulate. If omitted, picks the first eligible candidate.",
    )
    parser.add_argument(
        "--dry-run", action="store_true", dest="dry_run",
        help="Preview actions without actually sending emails (for send/simulate).",
    )
    args = parser.parse_args()

    global AUTO_MODE
    AUTO_MODE = args.auto

    if args.step:
        for step_name in args.step:
            if step_name == "send":
                run_send(dry_run=args.dry_run)
            elif step_name == "simulate":
                run_simulate(cin=args.cin, dry_run=args.dry_run)
            else:
                _, fn = STEPS[step_name]
                fn()
        print("\nDemo Runner finished.")
    else:
        run_interactive()


if __name__ == "__main__":
    main()
