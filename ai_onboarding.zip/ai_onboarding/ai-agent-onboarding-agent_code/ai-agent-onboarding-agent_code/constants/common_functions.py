import os
import logging
import configparser
from constants.constants import EMAIL_ATTACHMENT_DIR

logger = logging.getLogger(__name__)

_config = None


def _resolve_config_path() -> str:
    """Resolves the default config path relative to the project root."""
    # constants/ is one level below project root; config/ is at project root
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(project_root, "config", "dev.properties")


def load_config(config_path: str = None) -> configparser.ConfigParser:
    """
    Loads configuration from a .properties file using configparser.
    Defaults to config/dev.properties at the project root.
    """
    global _config
    if config_path is None:
        config_path = _resolve_config_path()
    parser = configparser.ConfigParser()
    parser.read(config_path)
    _config = parser
    logger.info(f"Configuration loaded from {config_path}")
    return parser


def get_config() -> configparser.ConfigParser:
    """Returns the already-loaded config, or loads from the default path."""
    global _config
    if _config is None:
        return load_config()
    return _config


def get_db_uri() -> str:
    """Returns the database URI from config."""
    cfg = get_config()
    return cfg.get("database", "db_uri", fallback=os.getenv(
        "DB_URI", "oracle+oracledb://user:pass@localhost:1521/?service_name=orcl"
    ))


def get_smtp_config() -> dict:
    """Returns SMTP configuration as a dict."""
    cfg = get_config()
    return {
        "host": cfg.get("smtp", "smtp_host", fallback=os.getenv("SMTP_HOST", "smtp.sendgrid.net")),
        "port": int(cfg.get("smtp", "smtp_port", fallback=os.getenv("SMTP_PORT", "587"))),
        "user": cfg.get("smtp", "smtp_user", fallback=os.getenv("SMTP_USER", "apikey")),
        "password": cfg.get("smtp", "smtp_pass", fallback=os.getenv("SMTP_PASS", "")),
        "from_address": cfg.get("smtp", "smtp_from", fallback=os.getenv("SMTP_FROM", "hr-noreply@example.com")),
    }


def get_imap_config() -> dict:
    """Returns IMAP configuration as a dict."""
    cfg = get_config()
    return {
        "host": cfg.get("imap", "imap_host", fallback=os.getenv("IMAP_HOST", "imap.example.com")),
        "port": int(cfg.get("imap", "imap_port", fallback=os.getenv("IMAP_PORT", "993"))),
        "user": cfg.get("imap", "imap_user", fallback=os.getenv("IMAP_USER", "hr-inbox@example.com")),
        "password": cfg.get("imap", "imap_pass", fallback=os.getenv("IMAP_PASS", "")),
    }


def get_llm_config(section: str = "LLMSection") -> dict:
    """
    Returns LLM configuration for the specified section.
    Use 'LLMSection' for gpt-oss-20b, 'numarkdownSection' for numarkdown-8b-thinking.
    """
    cfg = get_config()
    return {
        "base_url": cfg.get(section, "base_url", fallback="http://localhost:8000/v1"),
        "model_name": cfg.get(section, "model_name", fallback="gpt-oss-20b"),
        "temperature": float(cfg.get(section, "temperature", fallback="0")),
        "max_tokens": int(cfg.get(section, "max_tokens", fallback="4096")),
        "api_type": cfg.get(section, "api_type", fallback="aphrodite"),
    }


def get_numarkdown_config() -> dict:
    """Returns config for the numarkdown-8b-thinking model."""
    return get_llm_config("numarkdownSection")


def get_attachment_path(cin: str) -> str:
    """
    Returns the target folder path to store attachments for a specific candidate.
    Creates the directory if it does not exist.
    """
    cfg = get_config()
    base_dir = cfg.get("paths", "email_attachment_dir", fallback=EMAIL_ATTACHMENT_DIR)
    path = os.path.join(base_dir, cin)
    os.makedirs(path, exist_ok=True)
    return path
