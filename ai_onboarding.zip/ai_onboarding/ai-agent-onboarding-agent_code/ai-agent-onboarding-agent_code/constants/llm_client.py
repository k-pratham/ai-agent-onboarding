"""
AphroditeAPIClient — Direct HTTP client for the on-prem Aphrodite LLM server.

Replaces all LangChain OpenAI calls with httpx-based requests to the
OpenAI-compatible /v1/chat/completions endpoint exposed by Aphrodite.

Two module-level singletons are provided:
    gpt_oss_client      — for gpt-oss-20b (agent, drafts, classification)
    numarkdown_client   — for numarkdown-8b-thinking (OCR, doc classification)
"""

import logging
from typing import Optional

import httpx

from constants.common_functions import get_llm_config, get_numarkdown_config

logger = logging.getLogger(__name__)


class AphroditeAPIClient:
    """Synchronous + async HTTP client for the Aphrodite /v1/chat/completions endpoint."""

    def __init__(self, config_section: str = "LLMSection"):
        cfg = get_llm_config(config_section)
        self.base_url: str = cfg["base_url"].rstrip("/")
        self.model_name: str = cfg["model_name"]
        self.default_temperature: float = cfg["temperature"]
        self.default_max_tokens: int = cfg["max_tokens"]
        self._endpoint = f"{self.base_url}/chat/completions"

    # ── Request builder ─────────────────────────────────────────────────
    def construct_request(
        self,
        messages: list[dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        tools: Optional[list[dict]] = None,
        tool_choice: Optional[str] = None,
    ) -> tuple[dict, dict]:
        """
        Builds the headers and JSON body for an OpenAI-compatible chat completion.

        Args:
            messages:    List of {"role": ..., "content": ...} dicts.
            temperature: Override the default temperature from config.
            max_tokens:  Override the default max_tokens from config.
            tools:       Optional list of tool schemas (OpenAI function-calling format).
            tool_choice: Optional tool_choice directive ("auto", "none", or specific).

        Returns:
            (headers, body) tuple ready for httpx.post().
        """
        headers = {
            "Content-Type": "application/json",
        }
        body: dict = {
            "model": self.model_name,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.default_temperature,
            "max_tokens": max_tokens if max_tokens is not None else self.default_max_tokens,
        }
        if tools:
            body["tools"] = tools
            body["tool_choice"] = tool_choice or "auto"

        return headers, body

    # ── Synchronous call ────────────────────────────────────────────────
    def call_api(
        self,
        messages: list[dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        tools: Optional[list[dict]] = None,
        tool_choice: Optional[str] = None,
        timeout: float = 120.0,
    ) -> dict:
        """
        Sends a synchronous POST to /v1/chat/completions and returns the
        parsed response.

        When *tools* are NOT provided the return dict is:
            {"content": "<assistant text>"}

        When *tools* ARE provided the return dict is:
            {"content": "<assistant text or None>",
             "tool_calls": [{"id": ..., "function": {"name": ..., "arguments": ...}}, ...]}
        """
        headers, body = self.construct_request(
            messages,
            temperature=temperature,
            max_tokens=max_tokens,
            tools=tools,
            tool_choice=tool_choice,
        )
        try:
            resp = httpx.post(self._endpoint, headers=headers, json=body, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
            return self._extract_response(data)
        except httpx.HTTPStatusError as exc:
            logger.error("Aphrodite API HTTP error %s: %s", exc.response.status_code, exc.response.text)
            raise
        except Exception as exc:
            logger.error("Aphrodite API call failed: %s", exc)
            raise

    # ── Async call ──────────────────────────────────────────────────────
    async def acall_api(
        self,
        messages: list[dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        tools: Optional[list[dict]] = None,
        tool_choice: Optional[str] = None,
        timeout: float = 120.0,
    ) -> dict:
        """Async variant of :meth:`call_api`."""
        headers, body = self.construct_request(
            messages,
            temperature=temperature,
            max_tokens=max_tokens,
            tools=tools,
            tool_choice=tool_choice,
        )
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(self._endpoint, headers=headers, json=body, timeout=timeout)
                resp.raise_for_status()
                data = resp.json()
                return self._extract_response(data)
        except httpx.HTTPStatusError as exc:
            logger.error("Aphrodite API HTTP error %s: %s", exc.response.status_code, exc.response.text)
            raise
        except Exception as exc:
            logger.error("Aphrodite async API call failed: %s", exc)
            raise

    # ── Convenience: get just the text ──────────────────────────────────
    def get_text(
        self,
        messages: list[dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        timeout: float = 120.0,
    ) -> str:
        """Shortcut that returns only the assistant's text content."""
        result = self.call_api(
            messages, temperature=temperature, max_tokens=max_tokens, timeout=timeout,
        )
        return result.get("content") or ""

    async def aget_text(
        self,
        messages: list[dict],
        *,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        timeout: float = 120.0,
    ) -> str:
        """Async shortcut that returns only the assistant's text content."""
        result = await self.acall_api(
            messages, temperature=temperature, max_tokens=max_tokens, timeout=timeout,
        )
        return result.get("content") or ""

    # ── Internal ────────────────────────────────────────────────────────
    @staticmethod
    def _extract_response(data: dict) -> dict:
        """Extracts the assistant message from an OpenAI-format response."""
        choice = data["choices"][0]
        message = choice["message"]
        result: dict = {"content": message.get("content")}
        if message.get("tool_calls"):
            result["tool_calls"] = [
                {
                    "id": tc["id"],
                    "function": {
                        "name": tc["function"]["name"],
                        "arguments": tc["function"]["arguments"],
                    },
                }
                for tc in message["tool_calls"]
            ]
        return result

    def __repr__(self) -> str:
        return f"AphroditeAPIClient(model={self.model_name!r}, base_url={self.base_url!r})"


# ── Module-level singletons ────────────────────────────────────────────────
gpt_oss_client = AphroditeAPIClient("LLMSection")
numarkdown_client = AphroditeAPIClient("numarkdownSection")
