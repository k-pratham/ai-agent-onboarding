"""Tests for send_email — SMTP dispatch and DB updates."""

from datetime import date
from unittest.mock import patch, MagicMock

import pytest


class TestUpdateJobStatusAfterSend:
    def test_updates_status_to_mail_sent(self, mock_db_session):
        from mcp_server.send_email.engine.db_engine import update_job_status_after_send
        from constants.constants import STATUS_MAIL_SENT_ID

        job = MagicMock()
        mock_db_session.query.return_value.filter.return_value.first.return_value = job

        result = update_job_status_after_send(mock_db_session, job_id=1, draft_content="Email body")

        assert job.STATUS_ID == STATUS_MAIL_SENT_ID
        assert job.HUMAN_ACTION_REQUIRED == 0
        assert job.HUMAN_ACTION == "Approved"
        assert job.DRAFT_MAIL == "Email body"

    def test_returns_none_when_job_not_found(self, mock_db_session):
        from mcp_server.send_email.engine.db_engine import update_job_status_after_send

        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        result = update_job_status_after_send(mock_db_session, job_id=999, draft_content="body")
        assert result is None


class TestDispatchEmail:
    @patch("mcp_server.send_email.engine.mail_engine.smtplib.SMTP")
    def test_sends_email_with_correct_fields(self, mock_smtp_class):
        from mcp_server.send_email.engine.mail_engine import dispatch_email

        mock_server = MagicMock()
        mock_smtp_class.return_value.__enter__ = MagicMock(return_value=mock_server)
        mock_smtp_class.return_value.__exit__ = MagicMock(return_value=False)

        with patch("mcp_server.send_email.engine.mail_engine.get_smtp_config", return_value={
            "host": "localhost",
            "port": 587,
            "user": "test",
            "password": "pass",
            "from_address": "hr@example.com",
        }):
            dispatch_email("candidate@test.com", "Subject", "Body text")

        mock_smtp_class.assert_called_once_with("localhost", 587)
