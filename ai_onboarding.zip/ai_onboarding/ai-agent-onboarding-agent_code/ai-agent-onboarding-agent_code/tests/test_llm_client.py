"""Tests for constants/llm_client.py — AphroditeAPIClient."""

import json
from unittest.mock import patch, MagicMock

import pytest
import httpx

from constants.llm_client import AphroditeAPIClient


@pytest.fixture
def client(temp_config):
    """AphroditeAPIClient using test config."""
    return AphroditeAPIClient("LLMSection")


class TestConstructRequest:
    def test_basic_request_has_model_and_messages(self, client):
        messages = [{"role": "user", "content": "Hello"}]
        headers, body = client.construct_request(messages)

        assert headers["Content-Type"] == "application/json"
        assert body["model"] == "gpt-oss-20b"
        assert body["messages"] == messages
        assert body["temperature"] == 0.0
        assert body["max_tokens"] == 4096

    def test_temperature_override(self, client):
        _, body = client.construct_request(
            [{"role": "user", "content": "test"}],
            temperature=0.7,
        )
        assert body["temperature"] == 0.7

    def test_max_tokens_override(self, client):
        _, body = client.construct_request(
            [{"role": "user", "content": "test"}],
            max_tokens=2048,
        )
        assert body["max_tokens"] == 2048

    def test_tools_included_when_provided(self, client):
        tools = [{"type": "function", "function": {"name": "my_tool", "parameters": {}}}]
        _, body = client.construct_request(
            [{"role": "user", "content": "test"}],
            tools=tools,
        )
        assert body["tools"] == tools
        assert body["tool_choice"] == "auto"

    def test_no_tools_key_when_not_provided(self, client):
        _, body = client.construct_request(
            [{"role": "user", "content": "test"}],
        )
        assert "tools" not in body


class TestCallApi:
    def test_successful_text_response(self, client):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{
                "message": {"content": "Hello world", "role": "assistant"}
            }]
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.post", return_value=mock_response):
            result = client.call_api([{"role": "user", "content": "Hi"}])

        assert result["content"] == "Hello world"
        assert "tool_calls" not in result

    def test_tool_call_response(self, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": None,
                    "role": "assistant",
                    "tool_calls": [{
                        "id": "call_123",
                        "type": "function",
                        "function": {
                            "name": "get_weather",
                            "arguments": '{"city": "London"}',
                        },
                    }],
                }
            }]
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.post", return_value=mock_response):
            result = client.call_api(
                [{"role": "user", "content": "weather?"}],
                tools=[{"type": "function", "function": {"name": "get_weather"}}],
            )

        assert result["content"] is None
        assert len(result["tool_calls"]) == 1
        assert result["tool_calls"][0]["function"]["name"] == "get_weather"

    def test_http_error_is_raised(self, client):
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
            "500", request=MagicMock(), response=mock_response
        )

        with patch("httpx.post", return_value=mock_response):
            with pytest.raises(httpx.HTTPStatusError):
                client.call_api([{"role": "user", "content": "test"}])


class TestGetText:
    def test_returns_text_content(self, client):
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "Extracted text"}}]
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.post", return_value=mock_response):
            text = client.get_text([{"role": "user", "content": "test"}])

        assert text == "Extracted text"


class TestRepr:
    def test_repr_shows_model_and_url(self, client):
        r = repr(client)
        assert "gpt-oss-20b" in r
        assert "localhost:8000" in r
