"""Tests for constants/common_functions.py — config loading and helpers."""

import os
from unittest.mock import patch

import pytest


def test_load_config_reads_all_sections(temp_config):
    assert temp_config.has_section("database")
    assert temp_config.has_section("smtp")
    assert temp_config.has_section("imap")
    assert temp_config.has_section("LLMSection")
    assert temp_config.has_section("numarkdownSection")
    assert temp_config.has_section("paths")
    assert temp_config.has_section("scheduler")


def test_get_db_uri_returns_configured_value(temp_config):
    from constants.common_functions import get_db_uri
    assert get_db_uri() == "sqlite:///test.db"


def test_get_smtp_config_returns_dict(temp_config):
    from constants.common_functions import get_smtp_config
    smtp = get_smtp_config()
    assert smtp["host"] == "localhost"
    assert smtp["port"] == 587
    assert smtp["user"] == "testuser"
    assert smtp["from_address"] == "test@example.com"


def test_get_imap_config_returns_dict(temp_config):
    from constants.common_functions import get_imap_config
    imap = get_imap_config()
    assert imap["host"] == "localhost"
    assert imap["port"] == 993


def test_get_llm_config_default_section(temp_config):
    from constants.common_functions import get_llm_config
    cfg = get_llm_config()
    assert cfg["model_name"] == "gpt-oss-20b"
    assert cfg["base_url"] == "http://localhost:8000/v1"
    assert cfg["temperature"] == 0.0
    assert cfg["max_tokens"] == 4096


def test_get_numarkdown_config(temp_config):
    from constants.common_functions import get_numarkdown_config
    cfg = get_numarkdown_config()
    assert cfg["model_name"] == "numarkdown-8b-thinking"


def test_get_attachment_path_creates_directory(temp_config, tmp_path):
    from constants.common_functions import get_attachment_path
    path = get_attachment_path("TEST_CIN_001")
    assert os.path.isdir(path)
    assert "TEST_CIN_001" in path


def test_get_config_singleton(temp_config):
    from constants.common_functions import get_config
    c1 = get_config()
    c2 = get_config()
    assert c1 is c2
