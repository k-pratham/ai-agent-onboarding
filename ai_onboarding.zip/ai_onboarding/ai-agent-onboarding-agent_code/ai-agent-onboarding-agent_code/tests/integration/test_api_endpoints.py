"""Integration tests for FastAPI routes."""

from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def client():
    """FastAPI test client with mocked DB dependency."""
    with patch("ai_onboarding_brain.src.core.config.get_db_uri", return_value="sqlite:///test.db"):
        with patch("ai_onboarding_brain.src.core.config.get_smtp_config", return_value={
            "host": "localhost", "port": 587, "user": "test", "password": ""
        }):
            from ai_onboarding_brain.src.main import app
            from ai_onboarding_brain.src.core.database import get_db

            mock_db = MagicMock()

            def override_get_db():
                try:
                    yield mock_db
                finally:
                    pass

            app.dependency_overrides[get_db] = override_get_db
            yield TestClient(app), mock_db
            app.dependency_overrides.clear()


class TestHealthEndpoint:
    def test_health_returns_ok(self, client):
        test_client, _ = client
        response = test_client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert data["service"] == "onboarding_brain"


class TestPendingDraftsEndpoint:
    def test_returns_empty_list_when_no_drafts(self, client):
        test_client, mock_db = client
        mock_db.query.return_value.join.return_value.filter.return_value.all.return_value = []

        response = test_client.get("/api/v1/dashboard/pending-drafts")
        assert response.status_code == 200
        assert response.json() == []


class TestCandidateStatusEndpoint:
    def test_returns_404_for_unknown_cin(self, client):
        test_client, mock_db = client
        mock_db.query.return_value.filter.return_value.first.return_value = None

        response = test_client.get("/api/v1/dashboard/candidate-status/UNKNOWN_CIN")
        assert response.status_code == 404

    def test_returns_status_for_known_candidate(self, client):
        test_client, mock_db = client

        candidate = MagicMock()
        candidate.CANDIDATE_ID = 1
        candidate.CIN = "CIN_001"
        candidate.CANDIDATE_NAME = "Test"
        mock_db.query.return_value.filter.return_value.first.return_value = candidate
        mock_db.query.return_value.filter.return_value.all.return_value = []

        response = test_client.get("/api/v1/dashboard/candidate-status/CIN_001")
        assert response.status_code == 200
        data = response.json()
        assert data["cin"] == "CIN_001"
        assert data["candidate_name"] == "Test"
