import imaplib
import email
import base64
import re
import logging
from email.header import decode_header
from constants.common_functions import get_imap_config

logger = logging.getLogger(__name__)


def _decode_header_value(value):
    """Decodes email header value handling various encodings."""
    if value is None:
        return ""
    decoded_parts = decode_header(value)
    result = ""
    for part, charset in decoded_parts:
        if isinstance(part, bytes):
            result += part.decode(charset or "utf-8", errors="replace")
        else:
            result += part
    return result


def _extract_cin_from_subject(subject: str) -> str:
    """
    Extracts the CIN from the email subject line.
    CIN format is typically: YYYYMMDD_REFNO (e.g., 20240115_REF001)
    """
    if not subject:
        return None
    # Match CIN pattern: digits_alphanumeric
    match = re.search(r"(\d{8}_\w+)", subject)
    if match:
        return match.group(1)
    # Fallback: look for CIN keyword
    match = re.search(r"CIN[:\s]*(\S+)", subject, re.IGNORECASE)
    if match:
        return match.group(1)
    return None


def _parse_email_message(msg) -> dict:
    """
    Parses a single email message and extracts subject, CIN, body, and attachments.
    """
    subject = _decode_header_value(msg.get("Subject", ""))
    from_address = _decode_header_value(msg.get("From", ""))
    cin = _extract_cin_from_subject(subject)

    body = ""
    attachments = []

    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition", ""))

            if "attachment" in content_disposition:
                filename = part.get_filename()
                if filename:
                    filename = _decode_header_value(filename)
                    file_data = part.get_payload(decode=True)
                    if file_data:
                        attachments.append({
                            "filename": filename,
                            "data": base64.b64encode(file_data).decode("utf-8"),
                            "content_type": content_type,
                        })
            elif content_type == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    body += payload.decode("utf-8", errors="replace")
    else:
        content_type = msg.get_content_type()
        if content_type == "text/plain":
            payload = msg.get_payload(decode=True)
            if payload:
                body = payload.decode("utf-8", errors="replace")

    has_attachments = len(attachments) > 0

    return {
        "subject": subject,
        "from": from_address,
        "cin": cin,
        "body": body,
        "has_attachments": has_attachments,
        "attachments": attachments,
    }


def fetch_unread_candidate_replies() -> list:
    """
    Connects to the inbox, fetches unread emails, parses subjects for CIN,
    extracts body and attachments.
    Returns a list of structured email payload dictionaries grouped by CIN.
    """
    imap_config = get_imap_config()
    logger.info("Connecting to IMAP inbox to fetch candidate replies...")
    results = []

    try:
        if not imap_config["password"]:
            logger.warning("No IMAP password configured. Skipping fetch.")
            return results

        mail = imaplib.IMAP4_SSL(imap_config["host"], imap_config["port"])
        mail.login(imap_config["user"], imap_config["password"])
        mail.select("inbox")

        status, response = mail.search(None, "UNSEEN")
        if status != "OK":
            return results

        unread_msg_nums = response[0].split()
        for num in unread_msg_nums:
            status, msg_data = mail.fetch(num, "(RFC822)")
            if status != "OK":
                continue

            raw_email = msg_data[0][1]
            msg = email.message_from_bytes(raw_email)
            parsed = _parse_email_message(msg)
            parsed["msg_id"] = num.decode()
            results.append(parsed)

        mail.logout()
        logger.info(f"Fetched and parsed {len(results)} unread emails.")
    except Exception as e:
        logger.error(f"Error fetching emails: {e}")
    return results
