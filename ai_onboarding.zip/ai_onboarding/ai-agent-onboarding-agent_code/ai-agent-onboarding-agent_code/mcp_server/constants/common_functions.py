# DEPRECATED: This module is a backward-compatibility shim.
# Import from constants.common_functions instead.
from constants.common_functions import (  # noqa: F401
    load_config,
    get_config,
    get_db_uri,
    get_smtp_config,
    get_imap_config,
    get_llm_config,
    get_numarkdown_config,
    get_attachment_path,
)
