"""
HR Agentic Onboarding System — Interactive Demo Runner

Walks a presenter through the full candidate onboarding lifecycle,
one step at a time, with pauses, summaries, and clear narration.

Modes:
    python -m scripts.run_demo                     # interactive walkthrough (default)
    python -m scripts.run_demo --auto              # run everything without pausing
    python -m scripts.run_demo --step etl          # run a single step
    python -m scripts.run_demo --step api          # start only the FastAPI server

Steps:
    seed   — Seed master lookup tables
    etl    — ETL Pipeline (Excel -> DB)
    draft  — Draft emails for pending jobs
    inbox  — Read inbox + trigger AI agent
    api    — Start FastAPI HR dashboard
"""

import os
import sys
import argparse
import asyncio
import logging
import textwrap
from datetime import datetime, date, timedelta

# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("demo")

from constants.common_functions import get_config, get_db_uri
from constants.database import _get_session
from constants.constants import (
    STATUS_PENDING_ID, STATUS_MAIL_DRAFTED_ID, STATUS_MAIL_SENT_ID,
    STATUS_VERIFIED_ID, STATUS_COMPLETED_ID,
    JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID, JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
    JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID, JOB_TYPE_ATTACHMENTS_SAVED_ID,
)

DB_URI = get_db_uri()
EXCEL_PATH = os.getenv(
    "EXCEL_PATH",
    os.path.join(PROJECT_ROOT, "etl_pipeline", "excel_offer_tracker", "Offer_tracker.xlsx"),
)

AUTO_MODE = False  # set by --auto flag


# ---------------------------------------------------------------------------
# Presentation helpers
# ---------------------------------------------------------------------------
def _banner(title: str):
    width = 64
    print()
    print("=" * width)
    print(f"  {title}".center(width))
    print("=" * width)


def _narrate(text: str):
    """Print a narrative block that explains what is about to happen."""
    wrapped = textwrap.fill(text, width=72, initial_indent="  ", subsequent_indent="  ")
    print(f"\n{wrapped}\n")


def _pause(prompt: str = "Press ENTER to continue (or 'q' to quit)..."):
    if AUTO_MODE:
        return
    try:
        resp = input(f"  >> {prompt} ")
        if resp.strip().lower() in ("q", "quit", "exit"):
            print("\nDemo stopped by presenter.")
            sys.exit(0)
    except (EOFError, KeyboardInterrupt):
        print("\nDemo stopped.")
        sys.exit(0)


def _run_async(coro):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


def _print_table(rows: list[dict], columns: list[str], max_col_width: int = 30):
    """Prints a simple ASCII table."""
    if not rows:
        print("  (no data)")
        return
    # Compute column widths
    widths = {c: len(c) for c in columns}
    for row in rows:
        for c in columns:
            val = str(row.get(c, ""))
            if len(val) > max_col_width:
                val = val[:max_col_width - 3] + "..."
            widths[c] = max(widths[c], len(val))

    header = "  " + " | ".join(c.ljust(widths[c]) for c in columns)
    sep = "  " + "-+-".join("-" * widths[c] for c in columns)
    print(header)
    print(sep)
    for row in rows:
        vals = []
        for c in columns:
            v = str(row.get(c, ""))
            if len(v) > max_col_width:
                v = v[:max_col_width - 3] + "..."
            vals.append(v.ljust(widths[c]))
        print("  " + " | ".join(vals))
    print()


# ---------------------------------------------------------------------------
# DB summary helpers
# ---------------------------------------------------------------------------
def _show_candidate_summary():
    """Shows a summary of candidates in the DB."""
    from etl_pipeline.models.schema import CandidateInfo
    session = _get_session()
    try:
        candidates = session.query(CandidateInfo).order_by(CandidateInfo.CANDIDATE_ID.desc()).limit(10).all()
        rows = [
            {"ID": c.CANDIDATE_ID, "CIN": c.CIN, "Name": c.CANDIDATE_NAME or "-",
             "Email": c.PERSONAL_EMAIL_ID or "-", "DOJ": str(c.EXPECTED_DOJ_WRT_TO_NP or "-")}
            for c in candidates
        ]
        print(f"\n  Candidates in DB: {session.query(CandidateInfo).count()} total (showing latest 10)")
        _print_table(rows, ["ID", "CIN", "Name", "Email", "DOJ"])
    finally:
        session.close()


def _show_job_summary():
    """Shows a summary of jobs in the DB."""
    from etl_pipeline.models.schema import JobTracker, CandidateInfo, JobTypeMaster
    session = _get_session()
    try:
        jobs = (
            session.query(JobTracker, CandidateInfo, JobTypeMaster)
            .join(CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID)
            .join(JobTypeMaster, JobTracker.JOB_TYPE_ID == JobTypeMaster.JOB_TYPE_ID)
            .order_by(JobTracker.JOB_ID.desc())
            .limit(10)
            .all()
        )
        status_map = {1: "Pending", 2: "Drafted", 3: "Sent", 4: "Received",
                      5: "Verified", 6: "Rejected", 7: "Completed"}
        rows = [
            {
                "Job": j.JOB_ID,
                "Type": f"{jt.JOB_TYPE}/{jt.JOB_SUBTYPE}",
                "CIN": c.CIN,
                "Status": status_map.get(j.STATUS_ID, str(j.STATUS_ID)),
                "Action Date": str(j.ACTION_DATE or "-"),
                "HR Action": "Yes" if j.HUMAN_ACTION_REQUIRED else "No",
            }
            for j, c, jt in jobs
        ]
        total = session.query(JobTracker).count()
        print(f"\n  Jobs in DB: {total} total (showing latest 10)")
        _print_table(rows, ["Job", "Type", "CIN", "Status", "Action Date", "HR Action"])
    finally:
        session.close()


def _show_draft_preview(limit: int = 2):
    """Shows the latest drafted emails."""
    from etl_pipeline.models.schema import JobTracker, CandidateInfo
    session = _get_session()
    try:
        drafted = (
            session.query(JobTracker, CandidateInfo)
            .join(CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID)
            .filter(JobTracker.STATUS_ID == STATUS_MAIL_DRAFTED_ID)
            .order_by(JobTracker.JOB_ID.desc())
            .limit(limit)
            .all()
        )
        if not drafted:
            print("\n  No drafted emails to preview.")
            return
        for job, cand in drafted:
            print(f"\n  --- Draft for {cand.CANDIDATE_NAME or cand.CIN} (Job {job.JOB_ID}) ---")
            draft_text = (job.DRAFT_MAIL or "(empty)")[:500]
            for line in draft_text.split("\n"):
                print(f"  | {line}")
            if len(job.DRAFT_MAIL or "") > 500:
                print("  | ... (truncated)")
            print()
    finally:
        session.close()


def _show_document_tracker(cin: str = None):
    """Shows document tracker status for a candidate or all."""
    from etl_pipeline.models.schema import DocumentTracker, CandidateInfo, DocumentTypeMaster
    session = _get_session()
    try:
        query = (
            session.query(DocumentTracker, CandidateInfo, DocumentTypeMaster)
            .join(CandidateInfo, DocumentTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID)
            .join(DocumentTypeMaster, DocumentTracker.DOCUMENT_TYPE_ID == DocumentTypeMaster.DOCUMENT_TYPE_ID)
            .filter(DocumentTracker.IS_ACTIVE == 1)
        )
        if cin:
            query = query.filter(CandidateInfo.CIN == cin)
        records = query.order_by(DocumentTracker.CANDIDATE_ID).limit(20).all()

        status_map = {1: "Pending", 5: "Verified", 6: "Rejected", 7: "Completed"}
        rows = [
            {
                "CIN": c.CIN,
                "Document": dt.DOCUMENT_NAME,
                "Status": status_map.get(d.STATUS_ID, str(d.STATUS_ID)),
                "Comments": (d.COMMENTS or "-")[:40],
            }
            for d, c, dt in records
        ]
        label = f"for {cin}" if cin else "(all candidates, max 20)"
        print(f"\n  Document Tracker {label}:")
        _print_table(rows, ["CIN", "Document", "Status", "Comments"])
    finally:
        session.close()


# ===================================================================
# STEP 0 — Seed Master Data
# ===================================================================
def run_seed():
    _banner("STEP 0: Seed Master Data")
    _narrate(
        "Initializing the lookup tables that drive the system: "
        "StatusMaster (7 statuses), JobTypeMaster (7 job types), "
        "DocumentTypeMaster (8 document types for Fresher/Experience/DevPartner), "
        "CandidateTypeMaster, and MailTypeMaster (email templates)."
    )
    _pause()

    from scripts.seed_master_data import seed_data
    seed_data()
    logger.info("Seed complete.")


# ===================================================================
# STEP 1 — ETL Pipeline
# ===================================================================
def run_etl():
    _banner("STEP 1: ETL Pipeline  (Excel -> Database)")
    _narrate(
        "Reading the Offer Tracker Excel sheet. For each candidate: "
        "generate a unique CIN (YYYYMMDD_REFNO), compute a row hash "
        "for change detection, and load into CANDIDATE_INFO. "
        "A 'mail_send / documents_required' job is created for each "
        "new candidate with ACTION_DATE based on the 60-day-before-DOJ rule."
    )
    _pause()

    from etl_pipeline.extract.excel_reader import extract_excel_data
    from etl_pipeline.transform.transformer import transform_candidate_data
    from etl_pipeline.load.db_loader import load_data

    if not os.path.exists(EXCEL_PATH):
        logger.error(f"Excel file not found at: {EXCEL_PATH}")
        print(f"\n  Set EXCEL_PATH env var or place Offer_tracker.xlsx at:\n  {EXCEL_PATH}")
        return

    logger.info(f"Reading: {EXCEL_PATH}")
    raw_data = extract_excel_data(EXCEL_PATH)

    logger.info("Transforming (CIN, row hash, column mapping)...")
    transformed = transform_candidate_data(raw_data)
    logger.info(f"Transformed {len(transformed)} rows from {len(raw_data)} sheet(s).")

    logger.info("Loading into database...")
    session = _get_session()
    try:
        load_data(session, transformed)
    finally:
        session.close()

    logger.info("ETL complete.")
    _show_candidate_summary()
    _show_job_summary()
    _pause()


# ===================================================================
# STEP 2 — Mail Drafting
# ===================================================================
def run_mail_draft():
    _banner("STEP 2: Draft Emails for Pending Jobs")
    _narrate(
        "Scanning JOB_TRACKER for pending mail_send jobs with "
        "ACTION_DATE <= today. Three cases are handled:\n\n"
        "  Case 1 (documents_required): Template-based initial email — no LLM.\n"
        "  Case 2 (follow_up): LLM generates reminder when candidate hasn't replied.\n"
        "  Case 3 (pending_documents): LLM generates request for specific missing docs.\n\n"
        "Each draft is saved to JOB_TRACKER.DRAFT_MAIL and flagged for HR approval."
    )
    _pause()

    from etl_pipeline.models.schema import JobTracker, CandidateInfo
    from mcp_server.draft_prepare.engine.helper_func import generate_and_save_draft

    session = _get_session()
    today = date.today()

    mail_job_type_ids = [
        JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
        JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
        JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID,
    ]

    try:
        pending = session.query(JobTracker, CandidateInfo).join(
            CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID
        ).filter(
            JobTracker.JOB_TYPE_ID.in_(mail_job_type_ids),
            JobTracker.STATUS_ID == STATUS_PENDING_ID,
            JobTracker.ACTION_DATE <= today,
        ).all()

        logger.info(f"Found {len(pending)} pending mail job(s) with ACTION_DATE <= {today}")

        if not pending:
            print("\n  No pending jobs to process right now.")
            print("  (Jobs are created by the ETL step with future ACTION_DATEs.)")
            _pause()
            return

        drafted = 0
        for job, candidate in pending:
            cin = candidate.CIN
            try:
                draft = generate_and_save_draft(cin, job.JOB_ID)
                if draft.startswith("Error:"):
                    logger.warning(f"  {cin}: {draft}")
                    continue
                drafted += 1
                logger.info(f"  {cin}: Draft generated for Job {job.JOB_ID}")
            except Exception as e:
                logger.error(f"  {cin}: Failed - {e}")

        logger.info(f"Drafted {drafted} email(s).")
    except Exception as e:
        logger.error(f"Mail drafting failed: {e}")
        raise
    finally:
        session.close()

    _show_job_summary()
    _show_draft_preview()
    _pause()


# ===================================================================
# STEP 3 — Inbox Reader + AI Agent
# ===================================================================
def run_inbox_reader():
    _banner("STEP 3: Read Inbox + AI Agent Processing")
    _narrate(
        "Connecting to the IMAP inbox to fetch unread candidate replies. "
        "For each reply:\n"
        "  1. Extract CIN from subject (or resolve via sender email).\n"
        "  2. Deactivate pending follow-up jobs for that candidate.\n"
        "  3. Save attachments to the candidate's CIN folder.\n"
        "  4. Trigger the LangGraph AI agent which orchestrates:\n"
        "     OCR classification (numarkdown-8b) -> Identity validation ->\n"
        "     Document segregation -> Gap analysis -> Follow-up drafting."
    )
    _pause()

    from mcp_server.read_inbox.tools.read_inbox import tool_read_inbox
    from mcp_server.save_attachment.tools.save_attachment import tool_save_attachment

    inbox_result = _run_async(tool_read_inbox())

    if inbox_result.get("status") == "empty":
        logger.info("No unread emails found in inbox.")
        print("\n  To simulate this step, send a test email with a CIN in the subject")
        print("  and document attachments to the configured inbox.")
        _pause()
        return

    candidates = inbox_result.get("candidates", [])
    logger.info(f"Found {len(candidates)} distinct candidate(s) with replies.")

    for cdata in candidates:
        cin = cdata["cin"]
        has_attachments = cdata["has_attachments"]
        attachments = cdata.get("attachments", [])
        job_id = cdata.get("job_id")

        if not has_attachments:
            logger.info(f"  {cin}: Reply with no attachments - follow-up deactivated.")
            continue

        saved = []
        for att in attachments:
            res = _run_async(tool_save_attachment(cin, att["filename"], att["data"], job_id))
            saved.append(res)
            logger.info(f"  {cin}: Saved {att['filename']}")

        logger.info(f"  {cin}: Triggering AI agent for {len(saved)} attachment(s)...")
        try:
            _trigger_agent(cin, cdata["candidate_id"], saved)
            logger.info(f"  {cin}: Agent completed.")
        except Exception as e:
            logger.error(f"  {cin}: Agent failed - {e}")

    logger.info("Inbox processing complete.")
    _show_document_tracker()
    _pause()


def _trigger_agent(cin: str, candidate_id: int, saved_files: list):
    from ai_onboarding_brain.src.core.agent import get_compiled_orchestrator
    from ai_onboarding_brain.src.core.database import SessionLocal
    from langchain_core.messages import HumanMessage

    db = SessionLocal()
    try:
        orchestrator = get_compiled_orchestrator(db)
        config = {"configurable": {"thread_id": f"CANDIDATE_{cin}"}}
        prompt = (
            f"Candidate CIN {cin} has uploaded {len(saved_files)} document(s). "
            f"Process each: OCR classification, identity validation, gap analysis, "
            f"and draft a follow-up if documents are missing."
        )
        result = orchestrator.invoke(
            {"messages": [HumanMessage(content=prompt)]}, config=config,
        )
        logger.info(f"  {cin}: Agent finished ({len(result['messages'])} messages).")
    finally:
        db.close()


# ===================================================================
# STEP 4 — FastAPI HR Dashboard
# ===================================================================
def run_api():
    _banner("STEP 4: HR Dashboard API")
    _narrate(
        "Starting the FastAPI server for the HR Dashboard. Available endpoints:\n\n"
        "  GET  /health                              - Health check\n"
        "  GET  /api/v1/dashboard/pending-drafts      - Drafts awaiting HR approval\n"
        "  GET  /api/v1/dashboard/candidate-status/CIN - Document status for a candidate\n"
        "  POST /api/v1/action/approve-draft           - Approve & send a drafted email\n"
        "  POST /api/v1/action/check-escalation/ID     - Check escalation for a candidate\n"
        "  POST /api/v1/action/complete-onboarding/ID  - Trigger completion mails\n\n"
        "Swagger UI will be available at http://localhost:8080/docs"
    )
    _pause("Press ENTER to start the server (Ctrl+C to stop)...")

    import uvicorn
    logger.info("Starting on http://0.0.0.0:8080")
    uvicorn.run(
        "ai_onboarding_brain.src.main:app",
        host="0.0.0.0",
        port=8080,
        reload=False,
    )


# ===================================================================
# Full interactive walkthrough
# ===================================================================
STEPS = {
    "seed":  ("Seed Master Data",           run_seed),
    "etl":   ("ETL Pipeline",               run_etl),
    "draft": ("Draft Emails",               run_mail_draft),
    "inbox": ("Inbox Reader + AI Agent",    run_inbox_reader),
    "api":   ("HR Dashboard API",           run_api),
}


def run_interactive():
    """Full guided walkthrough — the default demo mode."""
    _banner("HR Agentic Onboarding System")
    print(textwrap.dedent(f"""\
      Project root : {PROJECT_ROOT}
      Database     : {DB_URI}
      Excel source : {EXCEL_PATH}
      Date         : {date.today().isoformat()}

      This demo walks through the complete candidate onboarding lifecycle:

        Step 0  Seed master lookup tables
        Step 1  ETL: Excel Offer Tracker -> Database
        Step 2  AI-drafted onboarding emails (3 cases)
        Step 3  Inbox reader + AI agent (OCR, validation, gap analysis)
        Step 4  HR Dashboard API (approve drafts, view status)

      Each step pauses so you can explain what happened.
    """))
    _pause("Press ENTER to begin the demo...")

    run_seed()
    run_etl()
    run_mail_draft()
    run_inbox_reader()

    _banner("Pipeline Complete")
    _narrate(
        "The automated pipeline has finished. All candidates have been "
        "loaded, initial emails drafted, and any inbox replies processed "
        "by the AI agent. The HR Dashboard is ready for human-in-the-loop "
        "review and approval."
    )

    # Show final state
    _show_candidate_summary()
    _show_job_summary()
    _show_document_tracker()

    _pause("Press ENTER to start the HR Dashboard API, or 'q' to exit...")
    run_api()


# ===================================================================
# CLI
# ===================================================================
def main():
    parser = argparse.ArgumentParser(
        description="HR Agentic Onboarding — Interactive Demo Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
        Modes:
          (default)          Interactive walkthrough with pauses and summaries
          --auto             Run all steps without pausing
          --step STEP [...]  Run specific step(s) only

        Steps: seed, etl, draft, inbox, api

        Examples:
          python -m scripts.run_demo                  # interactive demo
          python -m scripts.run_demo --auto            # batch mode
          python -m scripts.run_demo --step seed etl   # seed + ETL only
          python -m scripts.run_demo --step api        # just the dashboard
        """),
    )
    parser.add_argument(
        "--step", nargs="+", choices=list(STEPS.keys()),
        help="Run specific step(s) instead of the full walkthrough.",
    )
    parser.add_argument(
        "--auto", action="store_true",
        help="Run without pausing between steps.",
    )
    args = parser.parse_args()

    global AUTO_MODE
    AUTO_MODE = args.auto

    if args.step:
        for step_name in args.step:
            label, fn = STEPS[step_name]
            fn()
        print("\nDemo Runner finished.")
    else:
        run_interactive()


if __name__ == "__main__":
    main()
