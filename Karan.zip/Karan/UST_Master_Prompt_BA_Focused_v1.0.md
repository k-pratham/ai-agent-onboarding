You are a Senior Business Analyst. Draft a detailed User Story for 
[FEATURE NAME] on the [PAGE/SECTION] of a website.

Describe the feature functionality:
[DESCRIBE WHAT THE FEATURE DOES — 2-3 lines]

---

IMPORTANT INSTRUCTIONS:

1. You DO NOT have the visual design. Focus purely on 
   FUNCTIONAL BEHAVIOR, VALIDATIONS, and REQUIREMENTS.

2. DO NOT include:
   - Visual design details (colors, hex codes, heights, spacing)
   - HTML/CSS/JavaScript code samples
   - QA test data tables or boundary value tables
   - Device/browser testing matrix
   - Screen reader testing matrix
   - Automation scope table
   - Emojis in headings or anywhere in the document

3. DO include (capture EVERYTHING):
   - All functional behavior
   - All validations and error handling
   - All accessibility requirements
   - All responsive behavior rules
   - All CMS/content management rules
   - All fallback/graceful degradation scenarios
   - All performance constraints
   - All cross-browser compatibility requirements

---

Cover the following sections:

1. **User Story** 
   - Format: "As a [user], I want [goal], So that [benefit]"

2. **Description** 
   - Detailed functional behavior of the feature
   - What each sub-feature does
   - How it behaves in different states (default, active, error, fallback)

3. **Requirement Specification Table** with:
   - Title Character Limit: Max 60 characters
   - Title Line Limit: Max 2 lines (desktop), 1 line (mobile, truncate with ellipsis)
   - Subtitle Character Limit: Max 120 characters
   - Input Validations: No HTML tags, no special characters beyond , . ! ?; mandatory fields
   - Tags: Up to 5 tags, each ≤ 20 characters
   - Published Date: Auto-generated, format DD-MM-YYYY
   - Error Handling: Inline errors for missing/invalid fields; fallback content if assets unavailable
   - UI Behavior: Responsive resizing; truncation with ellipsis; real-time updates if applicable
   - Accessibility: Keyboard navigation (Tab, Arrow keys); ARIA labels; screen reader support; 
     focus indicators; color contrast compliance (WCAG 2.1 AA)
   - Performance: Transitions ≤1 second; lightweight scripts; no layout shifts
   - Compatibility: Chrome, Edge, Safari, Firefox (latest 2 versions)

4. **Pre-Conditions**
   - What must exist before this feature can work

5. **Post-Conditions**
   - Expected system state after successful implementation

6. **Acceptance Criteria** — Group them by category:
   - Functional (positive + negative scenarios for each sub-feature)
   - Accessibility & Keyboard
   - Responsive Behavior
   - Validation & Error Handling
   - Cross-Browser & Performance
   
   Use Given/When/Then format for each AC.

7. **Summary Table**
   - Count of features, pre-conditions, post-conditions, and ACs by category

---

FORMAT RULES:
- Use clear headings (no emojis anywhere in the document)
- Use tables wherever possible for readability
- Use bullet points for descriptions
- Keep it concise but comprehensive
- No code samples
- No visual/design specifications
- No emojis
- Focus = Behavior + Validation + Accessibility + Error Handling


---
---

VARIATIONS (Pick and append as needed):

BY COMPONENT TYPE:

1. Carousel/Slider:
   Additional behaviors to cover: Auto-play (5s delay, pause on 
   hover/focus), swipe gestures, dot/arrow indicators, slide 
   transitions, total slide limit, screen reader announces slide changes.

2. Navigation/Menu:
   Additional behaviors to cover: Mega menu open/close behavior, 
   hover vs click trigger, mobile hamburger menu, active page 
   indicator, keyboard navigation through items, close on Escape 
   key, max depth levels.

3. Hero Banner:
   Additional behaviors to cover: Background image/video behavior, 
   CTA button actions, search bar integration if applicable, 
   responsive image handling, text readability over background.

4. Form/Input Fields:
   Additional behaviors to cover: Field-level validations (required, 
   min/max, regex), inline error messages, success state, form 
   submission behavior, loading state, disabled state, autofill behavior.

5. Card Grid/Listing:
   Additional behaviors to cover: Grid layout per breakpoint, card 
   structure (image, title, description, CTA, date), hover effects, 
   "View All" behavior, empty state, pagination or load more.

6. Modal/Popup:
   Additional behaviors to cover: Trigger mechanism, overlay behavior, 
   close mechanisms (X, Escape, click outside), focus trap inside 
   modal, scroll lock, return focus on close.

7. Tabs Component:
   Additional behaviors to cover: Tab switching (click + Arrow keys), 
   active tab indicator, content loading (static vs dynamic), deep 
   linking via URL, responsive behavior (tabs to accordion on mobile).

8. Accordion/FAQ:
   Additional behaviors to cover: Expand/collapse behavior (single 
   vs multiple open), animation, expand/collapse icon, default state, 
   keyboard activation (Enter/Space), deep linking.

9. Footer:
   Additional behaviors to cover: Link groupings, social media icons, 
   copyright text (dynamic year), responsive stacking, back-to-top 
   button, app download badges, newsletter form.

10. Search:
    Additional behaviors to cover: Auto-suggest (trigger after 3 chars, 
    debounce 300ms), search results layout, no results state, recent 
    searches, clear button, voice search if applicable.

11. Ticker/Marquee:
    Additional behaviors to cover: Scroll direction and speed, pause 
    on hover/focus, content source, max items, link behavior, pause 
    button for accessibility, reduced-motion support.

12. Data Table:
    Additional behaviors to cover: Sortable columns, responsive 
    behavior (scroll vs stack), sticky header, pagination, empty 
    state, loading skeleton.


BY ADDITIONAL REQUIREMENT:

13. Priority:
    Also include: MoSCoW priority (Must/Should/Could/Won't Have).

14. Dependencies:
    Also include: Dependencies on other stories, components, APIs, or teams.

15. Analytics:
    Also include: What user interactions should be tracked 
    (clicks, impressions, time spent).

16. Localization:
    Also include: Multi-language support, RTL layout handling, 
    locale-based format changes.

17. API Integration:
    Also include: API behavior — loading state, empty state, 
    error state (4xx/5xx), retry logic.

18. Dark Mode:
    Also include: Dark mode/theme adaptation behavior.

19. SEO:
    Also include: SEO requirements — semantic structure, meta tags, 
    heading hierarchy, structured data.

20. Animation:
    Also include: Animation specs — type, duration, easing, 
    reduced-motion preference support.


WHEN YOU WANT DEV/QA DETAILS:

21. Add Dev Notes:
    Also include a "Technical Notes" section with: HTML semantic 
    structure, ARIA attributes, CSS behavior notes, JS requirements, 
    responsive breakpoints, fallback strategies. No full code — 
    just guidance notes.

22. Add QA Notes:
    Also include a "QA Testing Notes" section with: Test data 
    samples (valid + invalid), boundary value tests, screen reader 
    tools to test with, device/browser matrix, and automation scope 
    (which ACs are automatable).

23. Add Both:
    Also include "Technical Notes" and "QA Testing Notes" sections 
    as described above