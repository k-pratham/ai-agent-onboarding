## File: UST_Master_Prompt_Full_v1.0.md

```markdown
You are a Senior Business Analyst. Draft a comprehensive User Story for 
[FEATURE NAME] on the [PAGE/SECTION] of a website.

[Attach screenshot or provide description of the feature here]

---

IMPORTANT INSTRUCTIONS:

1. You HAVE the visual design/screenshot. Cover ALL perspectives:
   BA (functional), Developer (technical), and QA (testing).

2. DO NOT include:
   - Emojis in headings or anywhere in the document

3. DO include:
   - All functional behavior
   - All validations and error handling
   - All accessibility requirements
   - All responsive behavior rules
   - All CMS/content management rules
   - All fallback/graceful degradation scenarios
   - All performance constraints
   - All cross-browser compatibility requirements
   - Technical implementation notes (HTML, CSS, JS guidance)
   - QA testing notes (test data, device matrix, automation scope)

---

Cover the following sections:

A. BA (Business Analyst) Perspective:

1. **User Story**
   - Format: "As a [user], I want [goal], So that [benefit]"

2. **Description**
   - Detailed functional behavior of the feature
   - What each sub-feature does
   - How it behaves in different states (default, active, error, fallback)
   - Visual layout reference from screenshot

3. **Requirement Specification Table** with:
   - Title Character Limit: Max 60 characters
   - Title Line Limit: Max 2 lines (desktop), 1 line (mobile, truncate with ellipsis)
   - Subtitle Character Limit: Max 120 characters
   - Input Validations: No HTML tags, no special characters beyond , . ! ?; mandatory fields
   - Tags: Up to 5 tags, each ≤ 20 characters
   - Published Date: Auto-generated, format DD-MM-YYYY
   - Error Handling: Inline errors for missing/invalid fields; fallback content if assets unavailable
   - UI Behavior: Responsive resizing; truncation with ellipsis; real-time updates if applicable
   - Accessibility: Keyboard navigation (Tab, Arrow keys); ARIA labels; screen reader support;
     focus indicators; color contrast compliance (WCAG 2.1 AA)
   - Performance: Transitions ≤1 second; lightweight scripts; no layout shifts
   - Compatibility: Chrome, Edge, Safari, Firefox (latest 2 versions)

4. **Pre-Conditions**
   - What must exist before this feature can work

5. **Post-Conditions**
   - Expected system state after successful implementation

6. **Acceptance Criteria** — Group them by category:
   - Functional (positive + negative scenarios for each sub-feature)
   - Accessibility & Keyboard
   - Responsive Behavior
   - Validation & Error Handling
   - Cross-Browser & Performance

   Use Given/When/Then format for each AC.


B. Developer Perspective — Technical Notes:

1. **HTML Semantic Structure**
   - Key HTML elements, IDs, landmarks
   - Sample HTML skeleton markup

2. **CSS Behavior**
   - Responsive breakpoints: Desktop (>=1024px), Tablet (768-1023px), Mobile (<768px)
   - Hover/focus/active states
   - Truncation and overflow handling
   - Animations and transitions

3. **JavaScript Requirements**
   - Interactivity and dynamic behavior
   - Event handling
   - Script loading strategy (defer/async)
   - Script size constraints

4. **ARIA Attributes**
   - Specific ARIA roles, labels, live regions
   - Focus management details

5. **Fallback / Graceful Degradation**
   - Behavior when JS disabled
   - Behavior when assets fail to load
   - Older browser handling

6. **Performance Constraints**
   - Script size limits
   - Transition speed limits
   - Layout shift prevention
   - CPU/memory impact


C. QA Perspective — Testing Notes:

1. **Test Data Samples**
   - 3-5 valid inputs per editable field
   - 3-5 invalid inputs per editable field

2. **Boundary Value Tests**
   - Min, min+1, max-1, max, max+1 for all character limits
   - Edge cases for numeric constraints

3. **Screen Reader Testing Matrix**
   - Tools: NVDA (Windows), JAWS (Windows), VoiceOver (macOS/iOS), TalkBack (Android)
   - Browser pairings for each tool

4. **Device and Browser Testing Matrix**
   - At least 3 desktop resolutions
   - At least 2 tablet devices
   - At least 2 mobile devices
   - Across Chrome, Edge, Safari, Firefox (latest 2 versions)

5. **Automation Scope**
   - Mark each AC as "Automatable" or "Manual Only"
   - Suggest tools (Cypress, Selenium, Axe, Pa11y)


D. Summary:

1. **Summary Table**
   - Count of features, pre-conditions, post-conditions
   - Count of ACs by category
   - Count of test data samples
   - Count of device/browser combinations
   - Count of automatable vs manual ACs

---

FORMAT RULES:
- Use clear headings (no emojis anywhere in the document)
- Use tables wherever possible for readability
- Use bullet points for descriptions
- Keep it detailed and comprehensive
- No emojis
- Ensure every section is detailed enough that BA, Developer, and QA 
  teams can independently use this document for their respective work


---
---

VARIATIONS (Pick and append as needed):

BY COMPONENT TYPE:

1. Carousel/Slider:
   Additional behaviors to cover: Auto-play (5s delay, pause on 
   hover/focus), swipe gestures, dot/arrow indicators, slide 
   transitions, total slide limit, screen reader announces slide 
   changes.

2. Navigation/Menu:
   Additional behaviors to cover: Mega menu open/close behavior, 
   hover vs click trigger, mobile hamburger menu, active page 
   indicator, keyboard navigation through items, close on Escape 
   key, max depth levels.

3. Hero Banner:
   Additional behaviors to cover: Background image/video behavior, 
   CTA button actions, search bar integration if applicable, 
   responsive image handling, text readability over background.

4. Form/Input Fields:
   Additional behaviors to cover: Field-level validations (required, 
   min/max, regex), inline error messages, success state, form 
   submission behavior, loading state, disabled state, autofill 
   behavior.

5. Card Grid/Listing:
   Additional behaviors to cover: Grid layout per breakpoint, card 
   structure (image, title, description, CTA, date), hover effects, 
   "View All" behavior, empty state, pagination or load more.

6. Modal/Popup:
   Additional behaviors to cover: Trigger mechanism, overlay behavior, 
   close mechanisms (X, Escape, click outside), focus trap inside 
   modal, scroll lock, return focus on close.

7. Tabs Component:
   Additional behaviors to cover: Tab switching (click + Arrow keys), 
   active tab indicator, content loading (static vs dynamic), deep 
   linking via URL, responsive behavior (tabs to accordion on mobile).

8. Accordion/FAQ:
   Additional behaviors to cover: Expand/collapse behavior (single 
   vs multiple open), animation, expand/collapse icon, default state, 
   keyboard activation (Enter/Space), deep linking.

9. Footer:
   Additional behaviors to cover: Link groupings, social media icons, 
   copyright text (dynamic year), responsive stacking, back-to-top 
   button, app download badges, newsletter form.

10. Search:
    Additional behaviors to cover: Auto-suggest (trigger after 3 chars, 
    debounce 300ms), search results layout, no results state, recent 
    searches, clear button, voice search if applicable.

11. Ticker/Marquee:
    Additional behaviors to cover: Scroll direction and speed, pause 
    on hover/focus, content source, max items, link behavior, pause 
    button for accessibility, reduced-motion support.

12. Data Table:
    Additional behaviors to cover: Sortable columns, responsive 
    behavior (scroll vs stack), sticky header, pagination, empty 
    state, loading skeleton.


BY ADDITIONAL REQUIREMENT:

13. Priority:
    Also include: MoSCoW priority (Must/Should/Could/Won't Have).

14. Dependencies:
    Also include: Dependencies on other stories, components, APIs, 
    or teams.

15. Analytics:
    Also include: What user interactions should be tracked 
    (clicks, impressions, time spent).

16. Localization:
    Also include: Multi-language support, RTL layout handling, 
    locale-based format changes.

17. API Integration:
    Also include: API behavior — loading state, empty state, 
    error state (4xx/5xx), retry logic.

18. Dark Mode:
    Also include: Dark mode/theme adaptation behavior.

19. SEO:
    Also include: SEO requirements — semantic structure, meta tags, 
    heading hierarchy, structured data.

20. Animation:
    Also include: Animation specs — type, duration, easing, 
    reduced-motion preference support.
```

---

## Both Files Ready to Save

```
Templates Folder
|
|-- UST_Master_Prompt_Full_v1.0.md          -- With Dev + QA (use when you HAVE design)
|-- UST_Master_Prompt_BA_Focused_v1.0.md    -- BA only (use when you KNOW functionality only)
```

| File | When to Use | What It Covers |
|---|---|---|
| Full_v1.0.md | Have screenshot/design | BA + Dev + QA (everything) |
| BA_Focused_v1.0.md | Know functionality only | BA only (behavior + validation) |

---

Both files are now clean, no emojis, no examples, no explanations — just the prompt and variations. Ready to save and use.

Aur kuch chahiye?