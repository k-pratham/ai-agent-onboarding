import logging
from datetime import date
from sqlalchemy.orm import Session

from constants.database import _get_session, get_candidate_by_cin, create_followup_job  # noqa: F401
from constants.constants import STATUS_MAIL_DRAFTED_ID, STATUS_PENDING_ID
from etl_pipeline.models.schema import JobTracker, JobTypeMaster, CandidateInfo, MailTypeMaster, DocumentTracker, DocumentTypeMaster

logger = logging.getLogger(__name__)


def get_mail_template(session: Session, mail_type: str) -> str:
    """
    Fetches the mail template/description from MAIL_TYPE_MASTER.
    Returns the MAIL_DESCRIPTION field which contains the template body.
    """
    record = session.query(MailTypeMaster).filter(
        MailTypeMaster.MAIL_TYPE == mail_type,
        MailTypeMaster.IS_ACTIVE == 1,
    ).first()
    if record:
        return record.MAIL_DESCRIPTION
    return None


def save_draft_to_job_tracker(session: Session, job_id: int, draft_content: str):
    """
    Saves the generated draft email into the DRAFT_MAIL field of JOB_TRACKER.
    Updates status to Mail Drafted.
    """
    job = session.query(JobTracker).filter(JobTracker.JOB_ID == job_id).first()
    if job:
        job.DRAFT_MAIL = draft_content
        job.STATUS_ID = STATUS_MAIL_DRAFTED_ID
        job.HUMAN_ACTION_REQUIRED = 1
        job.UPDATED_ON = date.today()
        logger.info(f"Saved draft to job tracker {job_id}")
    return job


def get_pending_mail_jobs(session: Session, job_type_id: int) -> list:
    """
    Fetches all pending jobs for a specific job type where ACTION_DATE <= today.
    """
    today = date.today()
    return session.query(JobTracker, CandidateInfo).join(
        CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID
    ).filter(
        JobTracker.JOB_TYPE_ID == job_type_id,
        JobTracker.STATUS_ID == STATUS_PENDING_ID,
        JobTracker.ACTION_DATE <= today,
    ).all()


def get_job_type_info(session: Session, job_type_id: int):
    """Fetches JOB_TYPE and JOB_SUBTYPE from JOB_TYPE_MASTER."""
    return session.query(JobTypeMaster).filter(
        JobTypeMaster.JOB_TYPE_ID == job_type_id
    ).first()


def get_pending_docs_for_candidate(session: Session, candidate_id: int, candidate_type_id: int) -> list:
    """
    Fetches pending document names for a candidate.
    Compares required docs (by candidate type) against tracked docs.
    Returns list of document names that are still pending.
    """
    from constants.constants import CANDIDATE_TYPE_COLUMN_MAP, STATUS_VERIFIED_ID, STATUS_COMPLETED_ID

    col_name = CANDIDATE_TYPE_COLUMN_MAP.get(candidate_type_id, "EXPERIENCE")
    required = session.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()

    tracked = session.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()
    verified_ids = {d.DOCUMENT_TYPE_ID for d in tracked if d.STATUS_ID in (STATUS_VERIFIED_ID, STATUS_COMPLETED_ID)}

    return [doc.DOCUMENT_NAME for doc in required if doc.DOCUMENT_TYPE_ID not in verified_ids]
