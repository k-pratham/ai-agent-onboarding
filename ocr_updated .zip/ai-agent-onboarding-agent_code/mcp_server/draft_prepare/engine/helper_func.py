"""
Draft preparation engine — handles 3 distinct cases:

Case 1 (initial mail, JOB_SUBTYPE='documents_required'):
    Template-based, NO LLM call. Replaces [Candidate Name], [Document List],
    [CIN] placeholders in the MAIL_TYPE_MASTER template.

Case 2 (follow-up when no reply, JOB_SUBTYPE='follow_up'):
    LLM call to gpt-oss-20b. Generates reminder email about pending documents.

Case 3 (pending docs after gap analysis, JOB_SUBTYPE='pending_documents'):
    LLM call to gpt-oss-20b. Requests specific missing docs after partial submission.
"""

import os
import logging

from constants.llm_client import gpt_oss_client
from constants.database import _get_session, get_candidate_by_cin
from mcp_server.draft_prepare.engine.db_engine import (
    get_mail_template,
    save_draft_to_job_tracker,
    get_pending_docs_for_candidate,
    get_job_type_info,
)

logger = logging.getLogger(__name__)

_PROMPT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "prompts",
    "draft_prompt.txt",
)

DEFAULT_MAIL_TEMPLATE = """Dear [Candidate Name],

We hope this message finds you well. As part of your onboarding process, we require certain documents to proceed further.

Please submit the following documents at your earliest convenience:
[Document List]

Kindly reply to this email with the documents attached. Please include your CIN ([CIN]) in the subject line.

Thank you for your cooperation.

Regards,
HR Onboarding Team"""


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r") as f:
        return f.read()


# ── Case 1: Initial "Documents Required" Email ─────────────────────────
def generate_initial_draft(
    candidate_name: str,
    document_list: list[str],
    cin: str,
    mail_template: str = None,
) -> str:
    """
    Pure template replacement — no LLM call.
    Replaces [Candidate Name], [Document List], and [CIN] in the template.
    """
    template = mail_template or DEFAULT_MAIL_TEMPLATE
    doc_list_str = "\n".join(f"- {doc}" for doc in document_list)

    draft = (
        template
        .replace("[Candidate Name]", candidate_name)
        .replace("[Document List]", doc_list_str)
        .replace("[CIN]", cin)
    )
    return draft.strip()


# ── Case 2: Follow-up When Candidate Hasn't Replied ────────────────────
def generate_followup_draft(
    candidate_name: str,
    pending_docs: list[str],
    cin: str,
) -> str:
    """
    LLM-based follow-up draft via gpt-oss-20b.
    Used when candidate hasn't replied after ACTION_DATE.
    """
    prompt_template = _load_prompt()
    user_content = (
        prompt_template
        .replace("{candidate_name}", candidate_name)
        .replace("{missing_docs}", "\n".join(f"- {doc}" for doc in pending_docs))
        .replace("{cin}", cin)
        .replace("{mail_template}", "Generate a professional follow-up reminder email.")
    )
    messages = [{"role": "user", "content": user_content}]

    try:
        draft = gpt_oss_client.get_text(messages, temperature=0.3)
        return draft.strip()
    except Exception as e:
        logger.error(f"Follow-up draft generation failed: {e}")
        return _fallback_draft(candidate_name, pending_docs, cin)


# ── Case 3: Pending Docs After Gap Analysis ────────────────────────────
def generate_pending_docs_draft(
    candidate_name: str,
    missing_docs: list[str],
    cin: str,
) -> str:
    """
    LLM-based draft requesting specific missing docs after candidate's
    partial submission has been processed (OCR + gap analysis done).
    """
    prompt_template = _load_prompt()
    user_content = (
        prompt_template
        .replace("{candidate_name}", candidate_name)
        .replace("{missing_docs}", "\n".join(f"- {doc}" for doc in missing_docs))
        .replace("{cin}", cin)
        .replace(
            "{mail_template}",
            "Generate an email thanking the candidate for their earlier submission "
            "and requesting the specific documents that are still missing.",
        )
    )
    messages = [{"role": "user", "content": user_content}]

    try:
        draft = gpt_oss_client.get_text(messages, temperature=0.3)
        return draft.strip()
    except Exception as e:
        logger.error(f"Pending-docs draft generation failed: {e}")
        return _fallback_draft(candidate_name, missing_docs, cin)


# ── Orchestrator ────────────────────────────────────────────────────────
def generate_and_save_draft(cin: str, job_id: int) -> str:
    """
    End-to-end draft generation that dispatches to the correct case
    based on JOB_TYPE_MASTER (JOB_TYPE / JOB_SUBTYPE):

    1. Reads JOB_TYPE_MASTER to determine the case.
    2. Fetches candidate + required/pending docs.
    3. Generates draft via the appropriate function.
    4. Saves draft to JOB_TRACKER.DRAFT_MAIL.
    """
    from etl_pipeline.models.schema import JobTracker

    session = _get_session()
    try:
        # Fetch job entry to get JOB_TYPE_ID
        job = session.query(JobTracker).filter(JobTracker.JOB_ID == job_id).first()
        if not job:
            return f"Error: Job ID {job_id} not found."

        job_type_info = get_job_type_info(session, job.JOB_TYPE_ID)
        if not job_type_info:
            return f"Error: Job type {job.JOB_TYPE_ID} not found in JOB_TYPE_MASTER."

        candidate = get_candidate_by_cin(session, cin)
        if not candidate:
            return f"Error: Candidate CIN {cin} not found."

        candidate_name = candidate.CANDIDATE_NAME or cin
        candidate_type_id = candidate.CANDIDATE_TYPE_ID or 2
        subtype = (job_type_info.JOB_SUBTYPE or "").strip().lower()

        if subtype == "documents_required":
            # Case 1: Initial mail — template-based, no LLM
            mail_template = get_mail_template(session, "initial_documents")
            pending_docs = get_pending_docs_for_candidate(session, candidate.CANDIDATE_ID, candidate_type_id)
            draft = generate_initial_draft(candidate_name, pending_docs, cin, mail_template)

        elif subtype == "follow_up":
            # Case 2: Candidate hasn't replied — LLM call
            pending_docs = get_pending_docs_for_candidate(session, candidate.CANDIDATE_ID, candidate_type_id)
            draft = generate_followup_draft(candidate_name, pending_docs, cin)

        elif subtype == "pending_documents":
            # Case 3: After gap analysis, some docs still missing — LLM call
            pending_docs = get_pending_docs_for_candidate(session, candidate.CANDIDATE_ID, candidate_type_id)
            draft = generate_pending_docs_draft(candidate_name, pending_docs, cin)

        else:
            return f"Error: Unsupported JOB_SUBTYPE '{job_type_info.JOB_SUBTYPE}' for draft generation."

        # Save draft to JOB_TRACKER
        save_draft_to_job_tracker(session, job_id, draft)
        session.commit()

        return draft
    except Exception as e:
        session.rollback()
        logger.error(f"Draft generation and save failed for CIN {cin}: {e}")
        raise
    finally:
        session.close()


# ── Fallback ────────────────────────────────────────────────────────────
def _fallback_draft(candidate_name: str, docs: list[str], cin: str) -> str:
    """Template-based fallback when LLM call fails."""
    doc_list = "\n".join(f"  - {d}" for d in docs)
    return (
        f"Dear {candidate_name},\n\n"
        f"As part of your onboarding (CIN: {cin}), please submit:\n{doc_list}\n\n"
        f"Reply with attachments. Include your CIN in the subject.\n\n"
        f"Regards,\nHR Onboarding Team"
    )
