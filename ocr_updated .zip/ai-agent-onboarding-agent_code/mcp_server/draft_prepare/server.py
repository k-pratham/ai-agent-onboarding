import logging
from fastmcp import FastMCP
from mcp_server.draft_prepare.tools.draft_prepare import tool_draft_prepare

logger = logging.getLogger(__name__)

draft_prepare_server = FastMCP(
    name="Draft Prepare Tool",
    description="Generates follow-up email drafts via LLM and saves them to the Job Tracker."
)


@draft_prepare_server.tool()
async def draft_prepare(cin: str, candidate_name: str, missing_docs: list, job_id: int = None) -> str:
    """Generates a follow-up email draft for a candidate requesting missing documents."""
    logger.info(f"MCP draft_prepare: generating draft for CIN {cin}")
    return await tool_draft_prepare(cin, candidate_name, missing_docs, job_id)
