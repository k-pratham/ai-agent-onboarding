import logging
from mcp_server.draft_prepare.engine.helper_func import (
    generate_and_save_draft,
    generate_initial_draft,
    generate_followup_draft,
    generate_pending_docs_draft,
)

logger = logging.getLogger(__name__)


async def tool_draft_prepare(cin: str, job_id: int = None, candidate_name: str = None, missing_docs: list = None) -> str:
    """
    MCP Draft Prepare Tool: Generates email drafts and persists them to the database.

    When job_id is provided, dispatches to the correct case (initial / follow_up /
    pending_documents) based on JOB_TYPE_MASTER, fetches docs from DB, and saves
    the draft to JOB_TRACKER.DRAFT_MAIL.

    When job_id is NOT provided, generates a standalone follow-up draft using
    the supplied candidate_name and missing_docs (no DB persistence).

    Args:
        cin: Candidate CIN identifier.
        job_id: JOB_TRACKER entry ID (determines which case to run).
        candidate_name: Name of the candidate (only used when job_id is None).
        missing_docs: List of missing document names (only used when job_id is None).

    Returns:
        The generated draft email content.
    """
    if job_id is not None:
        try:
            draft = generate_and_save_draft(cin, job_id)
            logger.info(f"Draft prepared and saved for CIN {cin}, job {job_id}")
            return draft
        except Exception as e:
            logger.error(f"Draft prepare failed for CIN {cin}: {e}")
            return f"Error generating draft: {str(e)}"
    else:
        # Standalone draft generation (no DB persistence)
        name = candidate_name or cin
        docs = missing_docs or []
        return generate_followup_draft(name, docs, cin)
