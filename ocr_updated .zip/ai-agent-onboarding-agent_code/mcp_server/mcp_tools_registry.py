"""
MCP Tools Registry: Provides a unified interface for the AI agent to access
all MCP tools. The agent imports tools from this registry.
"""
from mcp_server.send_email.tools.send_email import tool_send_email
from mcp_server.read_inbox.tools.read_inbox import tool_read_inbox
from mcp_server.save_attachment.tools.save_attachment import tool_save_attachment
from mcp_server.ocr_classification.tools.ocr_classify import tool_ocr_and_segregate
from mcp_server.gap_analysis.tools.gap_analysis import tool_gap_analysis
from mcp_server.draft_prepare.tools.draft_prepare import tool_draft_prepare
from mcp_server.followup_classification.tools.followup_classify import tool_followup_classify

# Registry dict: tool_name -> callable
MCP_TOOLS = {
    "send_email": tool_send_email,
    "read_inbox": tool_read_inbox,
    "save_attachment": tool_save_attachment,
    "ocr_and_segregate": tool_ocr_and_segregate,
    "gap_analysis": tool_gap_analysis,
    "draft_prepare": tool_draft_prepare,
    "followup_classify": tool_followup_classify,
}


def get_tool(name: str):
    """Returns a tool callable by name from the registry."""
    return MCP_TOOLS.get(name)


def list_tools() -> list:
    """Returns the list of available tool names."""
    return list(MCP_TOOLS.keys())
