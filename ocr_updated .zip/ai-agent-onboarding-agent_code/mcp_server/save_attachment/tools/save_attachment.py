import base64
import logging
from mcp_server.save_attachment.engine.helper_func import store_attachment
from mcp_server.save_attachment.engine.db_engine import (
    _get_session,
    get_candidate_by_cin,
    insert_document_tracker_record,
)

logger = logging.getLogger(__name__)


async def tool_save_attachment(cin: str, file_name: str, base64_data: str, job_id: int = None) -> str:
    """
    MCP Tool: Saves an incoming candidate attachment to disk and records it
    in the DOCUMENT_TRACKER table with status 'Pending'.

    Args:
        cin: Candidate CIN identifier.
        file_name: Name of the attachment file.
        base64_data: Base64 encoded file content.
        job_id: Optional job tracker ID to link with the document.

    Returns:
        Status message with the saved file path.
    """
    try:
        file_bytes = base64.b64decode(base64_data)
        filepath = store_attachment(cin, file_name, file_bytes)

        # Insert record into DOCUMENT_TRACKER
        session = _get_session()
        try:
            candidate = get_candidate_by_cin(session, cin)
            if candidate:
                insert_document_tracker_record(
                    session=session,
                    candidate_id=candidate.CANDIDATE_ID,
                    document_type_id=None,  # Will be resolved after OCR classification
                    job_id=job_id,
                    file_path=filepath,
                )
                session.commit()
            else:
                logger.warning(f"Candidate CIN {cin} not found. File saved but no DB record created.")
        except Exception as db_err:
            session.rollback()
            logger.error(f"DB error while saving document tracker: {db_err}")
        finally:
            session.close()

        return f"Attachment {file_name} for CIN {cin} saved at {filepath}. Pending OCR validation."
    except Exception as e:
        return f"Attachment save failed: {str(e)}"
