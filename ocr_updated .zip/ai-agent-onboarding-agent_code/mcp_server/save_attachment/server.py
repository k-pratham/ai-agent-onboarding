import logging
from fastmcp import FastMCP
from mcp_server.save_attachment.tools.save_attachment import tool_save_attachment

logger = logging.getLogger(__name__)

save_attachment_server = FastMCP(
    name="Save Attachment Tool",
    description="Saves candidate email attachments to CIN-specific folders and records in Document Tracker."
)


@save_attachment_server.tool()
async def save_attachment(cin: str, file_name: str, base64_data: str, job_id: int = None) -> str:
    """Saves a candidate attachment to disk and records it in the Document Tracker."""
    logger.info(f"MCP save_attachment: saving {file_name} for CIN {cin}")
    return await tool_save_attachment(cin, file_name, base64_data, job_id)
