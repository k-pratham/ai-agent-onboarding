import logging
from fastmcp import FastMCP
from mcp_server.followup_classification.tools.followup_classify import tool_followup_classify

logger = logging.getLogger(__name__)

followup_classification_server = FastMCP(
    name="Followup Classification Tool",
    description="Classifies candidate reply emails and determines appropriate follow-up actions."
)


@followup_classification_server.tool()
async def followup_classify(cin: str, email_body: str) -> dict:
    """Classifies a candidate's reply email and determines the next follow-up action."""
    logger.info(f"MCP followup_classify: classifying reply for CIN {cin}")
    return await tool_followup_classify(cin, email_body)
