import logging
from mcp_server.followup_classification.engine.helper_func import classify_candidate_reply
from mcp_server.followup_classification.engine.followup_logic import calculate_followup_date
from mcp_server.followup_classification.engine.db_engine import (
    create_followup_job_with_date,
    count_failed_followups,
    get_hr_comments_for_candidate,
)
from constants.database import _get_session, get_candidate_by_cin

logger = logging.getLogger(__name__)

ESCALATION_THRESHOLD = 2


async def tool_followup_classify(cin: str, email_body: str) -> dict:
    """
    MCP Followup Classification Tool: Classifies a candidate's reply email
    and determines the appropriate next follow-up action.

    Uses LLM to classify the reply (+ HR comments from DB) into one of
    10 categories:
        SAME_DAY_EOD, NEXT_DAY_EOD, SHORT_TERM, MEDIUM_TERM, SPECIFIC_DATE,
        AFTER_A_WEEK, SOON_ASAP, REFUSAL, UNCLEAR, UNDETERMINISTIC

    Applies rule-based date logic (followup_logic.py) to determine the
    next follow-up date. Creates a follow-up job if needed.

    Special cases:
        REFUSAL      — No follow-up; flag for HR escalation.
        UNDETERMINISTIC — Candidate claims docs are attached; OCR + gap
                          analysis should already have processed them.
                          No automated follow-up; agent proceeds to gap_analysis.

    Returns:
        Dict with classification result, follow-up date, and escalation flag.
    """
    session = _get_session()
    try:
        candidate = get_candidate_by_cin(session, cin)
        if not candidate:
            return {
                "error": f"Candidate CIN {cin} not found.",
                "classification": "UNCLEAR",
            }

        # Fetch HR comments from Document Tracker
        hr_comments = get_hr_comments_for_candidate(session, candidate.CANDIDATE_ID)

        # Classify using dual input
        result = classify_candidate_reply(email_body, hr_comments)
        classification = result["classification"]
        extracted_date = result["extracted_date"]
        summary = result["summary"]

        # Calculate follow-up date via rule-based logic
        followup_date = calculate_followup_date(classification, extracted_date)

        # Check escalation threshold
        failed_count = count_failed_followups(session, candidate.CANDIDATE_ID)
        needs_escalation = failed_count >= ESCALATION_THRESHOLD

        if needs_escalation:
            logger.warning(f"Escalation needed for CIN {cin}: {failed_count} failed follow-ups.")

        # Create follow-up job if date is determined and classification warrants it
        job_created = False
        if followup_date and classification not in ("REFUSAL", "UNDETERMINISTIC"):
            create_followup_job_with_date(session, candidate.CANDIDATE_ID, followup_date)
            job_created = True

        session.commit()

        return {
            "cin": cin,
            "classification": classification,
            "followup_date": followup_date.isoformat() if followup_date else None,
            "summary": summary,
            "needs_escalation": needs_escalation,
            "failed_followup_count": failed_count,
            "followup_job_created": job_created,
        }
    except Exception as e:
        session.rollback()
        logger.error(f"Followup classification failed for CIN {cin}: {e}")
        return {"error": str(e), "classification": "UNCLEAR"}
    finally:
        session.close()
