"""
Followup classification engine — 10-class LLM classifier with dual input.

Accepts both email_body and hr_comments, classifies into one of 10 categories,
and delegates date calculation to followup_logic.py.
"""

import os
import logging
from datetime import date

from constants.llm_client import gpt_oss_client

logger = logging.getLogger(__name__)

_PROMPT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "prompts",
    "classify_reply_prompt.txt",
)

VALID_CLASSIFICATIONS = {
    "SAME_DAY_EOD",
    "NEXT_DAY_EOD",
    "SHORT_TERM",
    "MEDIUM_TERM",
    "SPECIFIC_DATE",
    "AFTER_A_WEEK",
    "SOON_ASAP",
    "REFUSAL",
    "UNCLEAR",
    "UNDETERMINISTIC",
}


def _load_prompt() -> str:
    with open(_PROMPT_PATH, "r") as f:
        return f.read()


def classify_candidate_reply(email_body: str, hr_comments: str = "") -> dict:
    """
    Uses LLM to classify a candidate's reply (and optional HR comments)
    into one of 10 follow-up categories.

    Args:
        email_body:  The candidate's reply email text.
        hr_comments: Concatenated HR comments from Document Tracker (may be empty).

    Returns:
        dict with keys: classification, extracted_date (date | None), summary.
    """
    prompt_template = _load_prompt()
    today = date.today()

    user_content = (
        prompt_template
        .replace("{email_body}", email_body or "(no email body)")
        .replace("{hr_comments}", hr_comments or "(no HR comments)")
        .replace("{today_date}", today.isoformat())
    )
    messages = [{"role": "user", "content": user_content}]

    try:
        result_text = gpt_oss_client.get_text(messages)
        return _parse_classification_response(result_text)
    except Exception as e:
        logger.error(f"Reply classification failed: {e}")
        return {
            "classification": "UNCLEAR",
            "extracted_date": None,
            "summary": "Classification failed, defaulting to UNCLEAR.",
        }


def _parse_classification_response(response_text: str) -> dict:
    """Parses the structured LLM response into a dict."""
    classification = "UNCLEAR"
    extracted_date = None
    summary = ""

    for line in response_text.split("\n"):
        line = line.strip()
        if line.startswith("CLASSIFICATION:"):
            val = line.split(":", 1)[1].strip().upper()
            if val in VALID_CLASSIFICATIONS:
                classification = val
        elif line.startswith("EXTRACTED_DATE:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NO_DATE":
                try:
                    extracted_date = date.fromisoformat(val)
                except ValueError:
                    logger.warning(f"Could not parse extracted date: {val}")
        elif line.startswith("SUMMARY:"):
            summary = line.split(":", 1)[1].strip()

    return {
        "classification": classification,
        "extracted_date": extracted_date,
        "summary": summary,
    }
