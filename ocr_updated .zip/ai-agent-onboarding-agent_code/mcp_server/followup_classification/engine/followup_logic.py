"""
Follow-up date calculation logic — pure functions, no I/O.

Maps each of the 10 classification categories to a concrete follow-up date
(or None when no follow-up is needed).
"""

from datetime import date, timedelta
from typing import Optional


def calculate_followup_date(
    classification: str,
    extracted_date: Optional[date] = None,
) -> Optional[date]:
    """
    Returns the next follow-up date based on the LLM classification.

    Args:
        classification:  One of the 10 valid classification categories.
        extracted_date:  A specific date extracted by the LLM (only used
                         when classification is SPECIFIC_DATE).

    Returns:
        A ``date`` for when the follow-up should happen, or ``None`` if
        no follow-up is required (escalation / already-processed).
    """
    today = date.today()

    match classification:
        case "SAME_DAY_EOD":
            return today
        case "NEXT_DAY_EOD":
            return today + timedelta(days=1)
        case "SHORT_TERM":
            return today + timedelta(days=3)
        case "MEDIUM_TERM":
            return today + timedelta(days=6)
        case "SPECIFIC_DATE":
            return extracted_date if extracted_date else today + timedelta(days=3)
        case "AFTER_A_WEEK":
            return today + timedelta(days=8)
        case "SOON_ASAP":
            return today + timedelta(days=2)
        case "REFUSAL":
            # Escalate to HR — no automated follow-up
            return None
        case "UNCLEAR":
            return today + timedelta(days=1)
        case "UNDETERMINISTIC":
            # Candidate claims docs are attached; OCR + gap analysis will
            # determine completeness. No automated follow-up at this stage.
            return None
        case _:
            # Unknown classification — default short follow-up
            return today + timedelta(days=2)
