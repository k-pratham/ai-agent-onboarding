import logging
from datetime import date
from sqlalchemy.orm import Session

from constants.database import _get_session, get_candidate_by_cin  # noqa: F401
from constants.constants import STATUS_PENDING_ID, JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID, STATUS_MAIL_SENT_ID, JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID
from etl_pipeline.models.schema import JobTracker, CandidateInfo, DocumentTracker

logger = logging.getLogger(__name__)


def create_followup_job_with_date(session: Session, candidate_id: int, followup_date: date) -> JobTracker:
    """
    Creates a follow-up job entry with a specific followup date derived from
    the candidate's reply classification.
    """
    today = date.today()
    new_job = JobTracker(
        JOB_TYPE_ID=JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID,
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=0,
        STATUS_ID=STATUS_PENDING_ID,
        ACTION_DATE=followup_date,
        UPDATED_ON=today,
    )
    session.add(new_job)
    session.flush()
    logger.info(f"Created follow-up job for candidate {candidate_id} with date {followup_date}")
    return new_job


def count_failed_followups(session: Session, candidate_id: int) -> int:
    """
    Counts how many follow-up mails have been sent to a candidate
    (status = Mail Sent (3) and job_type = Follow Up (2)).
    Used to determine if escalation is needed.
    """
    count = session.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID == candidate_id,
        JobTracker.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
        JobTracker.STATUS_ID == STATUS_MAIL_SENT_ID,
    ).count()
    return count


def get_hr_comments_for_candidate(session: Session, candidate_id: int) -> str:
    """
    Fetches HR comments from DOCUMENT_TRACKER for a candidate.
    Returns concatenated comments from all active document tracker entries.
    """
    records = session.query(DocumentTracker.COMMENTS).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
        DocumentTracker.COMMENTS.isnot(None),
    ).all()
    comments = [r.COMMENTS for r in records if r.COMMENTS and r.COMMENTS.strip()]
    return " | ".join(comments) if comments else ""
