import logging
from fastmcp import FastMCP
from mcp_server.gap_analysis.tools.gap_analysis import tool_gap_analysis

logger = logging.getLogger(__name__)

gap_analysis_server = FastMCP(
    name="Gap Analysis Tool",
    description="Analyzes document gaps by comparing required vs received documents for a candidate."
)


@gap_analysis_server.tool()
async def gap_analysis(cin: str, validated_doc_type_ids: list = None) -> dict:
    """Performs gap analysis for a candidate, comparing required documents against submitted ones."""
    logger.info(f"MCP gap_analysis: analyzing CIN {cin}")
    return await tool_gap_analysis(cin, validated_doc_type_ids)
