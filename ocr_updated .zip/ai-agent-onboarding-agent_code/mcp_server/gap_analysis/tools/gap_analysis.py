import logging
from mcp_server.gap_analysis.engine.helper_func import perform_gap_analysis

logger = logging.getLogger(__name__)


async def tool_gap_analysis(cin: str, validated_doc_type_ids: list = None) -> dict:
    """
    MCP Gap Analysis Tool: Compares required documents (based on candidate type)
    against tracked documents in DOCUMENT_TRACKER.

    - Marks validated documents as 'Verified' in the database.
    - Reports missing, pending, completed, and rejected documents.
    - Returns overall status indicating if all documents are received.

    Args:
        cin: Candidate CIN identifier.
        validated_doc_type_ids: List of document type IDs that have been validated by OCR.

    Returns:
        Dict with gap analysis results.
    """
    result = perform_gap_analysis(cin, validated_doc_type_ids)

    if "error" in result:
        logger.error(f"Gap analysis error for CIN {cin}: {result['error']}")
        return result

    logger.info(
        f"Gap analysis for CIN {cin}: "
        f"Missing={len(result['missing'])}, "
        f"Completed={len(result['completed'])}, "
        f"Pending={len(result['pending'])}, "
        f"Status={result['overall_status']}"
    )
    return result
