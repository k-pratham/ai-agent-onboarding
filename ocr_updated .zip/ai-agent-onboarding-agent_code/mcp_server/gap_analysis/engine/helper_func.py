import logging
from mcp_server.gap_analysis.engine.db_engine import (
    _get_session,
    get_candidate_by_cin,
    get_required_documents_for_candidate,
    get_tracked_documents_for_candidate,
    mark_verified_documents,
    check_all_documents_complete,
)

logger = logging.getLogger(__name__)


def perform_gap_analysis(cin: str, validated_doc_type_ids: list = None) -> dict:
    """
    Performs gap analysis by comparing required documents (based on candidate type)
    against tracked documents in DOCUMENT_TRACKER.

    Updates verified documents in the database.

    Returns a dict with missing, completed, pending, and overall status.
    """
    session = _get_session()
    try:
        candidate = get_candidate_by_cin(session, cin)
        if not candidate:
            return {"error": f"Candidate CIN {cin} not found.", "cin": cin}

        candidate_type_id = candidate.CANDIDATE_TYPE_ID or 2  # Default to Experience

        # Get required documents based on candidate type
        required_docs = get_required_documents_for_candidate(session, candidate_type_id)

        # Get tracked documents for this candidate
        tracked_docs = get_tracked_documents_for_candidate(session, candidate.CANDIDATE_ID)

        # Mark validated documents as verified in DB
        if validated_doc_type_ids:
            mark_verified_documents(session, candidate.CANDIDATE_ID, validated_doc_type_ids)

        # Build gap analysis result
        required_map = {doc.DOCUMENT_TYPE_ID: doc.DOCUMENT_NAME for doc in required_docs}
        tracked_map = {}
        for doc in tracked_docs:
            tracked_map[doc.DOCUMENT_TYPE_ID] = doc.STATUS_ID

        missing = []
        completed = []
        pending = []
        rejected = []

        for doc_type_id, doc_name in required_map.items():
            status = tracked_map.get(doc_type_id)
            if status is None:
                missing.append(doc_name)
            elif status in (5, 7):  # Verified or Completed
                completed.append(doc_name)
            elif status == 6:  # Rejected
                rejected.append(doc_name)
            else:
                pending.append(doc_name)

        all_complete = check_all_documents_complete(session, candidate.CANDIDATE_ID, candidate_type_id)
        overall_status = "completed" if all_complete else "pending_documents"

        session.commit()

        return {
            "cin": cin,
            "candidate_name": candidate.CANDIDATE_NAME,
            "candidate_type_id": candidate_type_id,
            "missing": missing,
            "completed": completed,
            "pending": pending,
            "rejected": rejected,
            "overall_status": overall_status,
        }
    except Exception as e:
        session.rollback()
        logger.error(f"Gap analysis failed for CIN {cin}: {e}")
        return {"error": str(e), "cin": cin}
    finally:
        session.close()
