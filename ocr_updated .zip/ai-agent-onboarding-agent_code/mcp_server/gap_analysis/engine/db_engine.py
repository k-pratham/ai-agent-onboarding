import logging
from datetime import date
from sqlalchemy.orm import Session

from constants.database import _get_session, get_candidate_by_cin  # noqa: F401
from constants.constants import CANDIDATE_TYPE_COLUMN_MAP, STATUS_VERIFIED_ID, STATUS_COMPLETED_ID, STATUS_PENDING_ID
from etl_pipeline.models.schema import (
    DocumentTracker, DocumentTypeMaster, CandidateInfo, CandidateTypeMaster,
)

logger = logging.getLogger(__name__)


def get_required_documents_for_candidate(session: Session, candidate_type_id: int) -> list:
    """
    Fetches the required documents based on candidate type (Fresher/Experience/DevPartner).
    Filters DOCUMENT_TYPE_MASTER based on the candidate type flags.
    """
    col_name = CANDIDATE_TYPE_COLUMN_MAP.get(candidate_type_id, "EXPERIENCE")

    return session.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()


def get_tracked_documents_for_candidate(session: Session, candidate_id: int) -> list:
    """Fetches all document tracker entries for a candidate."""
    return session.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()


def update_document_status(session: Session, tracker_id: int, status_id: int, comments: str = None):
    """
    Updates the status of a document in DOCUMENT_TRACKER.
    Status IDs: 1=Pending, 5=Verified, 6=Rejected, 7=Completed.
    """
    record = session.query(DocumentTracker).filter(
        DocumentTracker.DOCUMENT_TRACKER_ID == tracker_id
    ).first()
    if record:
        record.STATUS_ID = status_id
        record.UPDATED_ON = date.today()
        if comments:
            record.COMMENTS = comments
        logger.info(f"Updated document tracker {tracker_id} to status {status_id}")


def mark_verified_documents(session: Session, candidate_id: int, verified_doc_type_ids: list):
    """
    Marks specific document types as Verified in DOCUMENT_TRACKER for a candidate.
    """
    for doc_type_id in verified_doc_type_ids:
        records = session.query(DocumentTracker).filter(
            DocumentTracker.CANDIDATE_ID == candidate_id,
            DocumentTracker.DOCUMENT_TYPE_ID == doc_type_id,
            DocumentTracker.STATUS_ID == STATUS_PENDING_ID,
            DocumentTracker.IS_ACTIVE == 1,
        ).all()
        for record in records:
            record.STATUS_ID = STATUS_VERIFIED_ID
            record.UPDATED_ON = date.today()


def check_all_documents_complete(session: Session, candidate_id: int, candidate_type_id: int) -> bool:
    """
    Checks if all required documents for a candidate are verified or completed.
    Returns True if there are no pending documents.
    """
    required = get_required_documents_for_candidate(session, candidate_type_id)
    required_ids = {doc.DOCUMENT_TYPE_ID for doc in required}

    tracked = get_tracked_documents_for_candidate(session, candidate_id)
    verified_ids = {
        doc.DOCUMENT_TYPE_ID for doc in tracked
        if doc.STATUS_ID in (STATUS_VERIFIED_ID, STATUS_COMPLETED_ID)
    }

    return required_ids.issubset(verified_ids)
