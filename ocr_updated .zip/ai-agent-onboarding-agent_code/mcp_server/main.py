import logging
from fastmcp import FastMCP
from constants.common_functions import get_mcp_config

from mcp_server.send_email.server import send_email_server
from mcp_server.read_inbox.server import read_inbox_server
from mcp_server.save_attachment.server import save_attachment_server
from mcp_server.ocr_classification.server import ocr_classification_server
from mcp_server.gap_analysis.server import gap_analysis_server
from mcp_server.draft_prepare.server import draft_prepare_server
from mcp_server.followup_classification.server import followup_classification_server

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create the main MCP application server
mcp_app = FastMCP(
    name="Agentic HR Onboarding Tool Server",
    description="Provides tools for the HR onboarding agentic workflow: "
                "email dispatch, inbox reading, attachment management, "
                "OCR document classification, gap analysis, draft preparation, "
                "and follow-up classification."
)

# Mount all tool sub-servers onto the main MCP application
mcp_app.mount("send_email", send_email_server)
mcp_app.mount("read_inbox", read_inbox_server)
mcp_app.mount("save_attachment", save_attachment_server)
mcp_app.mount("ocr_classification", ocr_classification_server)
mcp_app.mount("gap_analysis", gap_analysis_server)
mcp_app.mount("draft_prepare", draft_prepare_server)
mcp_app.mount("followup_classification", followup_classification_server)


if __name__ == "__main__":
    mcp_cfg = get_mcp_config()
    host = mcp_cfg["host"]
    port = mcp_cfg["port"]
    logger.info(f"Starting FastMCP HR Onboarding Tool Server on {host}:{port}...")
    mcp_app.run(transport="streamable-http", host=host, port=port)
