import logging
from mcp_server.read_inbox.engine.helper_func import fetch_unread_candidate_replies
from mcp_server.read_inbox.engine.db_engine import (
    deactivate_followup_for_candidate,
    create_attachment_saved_job,
    get_candidate_by_email,
)
from constants.database import _get_session, get_candidate_by_cin

logger = logging.getLogger(__name__)


async def tool_read_inbox() -> dict:
    """
    MCP Tool: Reads the email inbox for candidate replies.
    - Extracts CIN from subject lines to identify distinct candidates.
    - Falls back to resolving CIN via sender's PERSONAL_EMAIL_ID when
      CIN is not present in the subject.
    - Classifies emails as 'has_attachments' or 'no_attachments'.
    - Deactivates pending follow-up jobs for candidates who replied.
    - Creates 'attachments saved' job entries for candidates with attachments.

    Returns structured data grouped by CIN for downstream processing.
    """
    emails = fetch_unread_candidate_replies()

    if not emails:
        return {"status": "empty", "message": "No unread emails found in inbox.", "candidates": []}

    session = _get_session()
    try:
        # Group emails by CIN (a candidate can send more than 1 email, 10MB limit)
        cin_groups = {}
        for mail in emails:
            cin = mail.get("cin")

            # Fallback: resolve CIN by sender email if not in subject
            if not cin:
                sender_email = mail.get("from", "")
                candidate = get_candidate_by_email(session, sender_email)
                if candidate:
                    cin = candidate.CIN
                    mail["cin"] = cin
                    logger.info(f"Resolved CIN {cin} from sender email {sender_email}")
                else:
                    logger.warning(
                        f"Could not extract CIN from subject: {mail.get('subject')!r} "
                        f"and sender {sender_email!r} not found in DB. Skipping."
                    )
                    continue

            if cin not in cin_groups:
                cin_groups[cin] = {
                    "cin": cin,
                    "emails": [],
                    "has_attachments": False,
                    "all_attachments": [],
                }
            cin_groups[cin]["emails"].append(mail)
            if mail.get("has_attachments"):
                cin_groups[cin]["has_attachments"] = True
                cin_groups[cin]["all_attachments"].extend(mail.get("attachments", []))

        # Process each distinct candidate
        candidate_results = []
        for cin, group in cin_groups.items():
            candidate = get_candidate_by_cin(session, cin)
            if not candidate:
                logger.warning(f"Candidate with CIN {cin} not found in database. Skipping.")
                continue

            # Deactivate pending follow-up jobs for this candidate
            deactivate_followup_for_candidate(session, candidate.CANDIDATE_ID)

            job = None
            if group["has_attachments"]:
                # Create 'attachments saved' job entry
                job = create_attachment_saved_job(session, candidate.CANDIDATE_ID)

            candidate_results.append({
                "cin": cin,
                "candidate_id": candidate.CANDIDATE_ID,
                "candidate_name": candidate.CANDIDATE_NAME,
                "has_attachments": group["has_attachments"],
                "attachment_count": len(group["all_attachments"]),
                "attachments": group["all_attachments"],
                "job_id": job.JOB_ID if job else None,
                "email_count": len(group["emails"]),
            })

        session.commit()
    except Exception as e:
        session.rollback()
        logger.error(f"Error processing inbox results: {e}")
        raise
    finally:
        session.close()

    return {
        "status": "processed",
        "message": f"Processed {len(cin_groups)} distinct candidates from {len(emails)} emails.",
        "candidates": candidate_results,
    }
