import base64
import re
import logging
from exchangelib import Credentials, Account, Configuration, DELEGATE
from constants.common_functions import get_ews_config

logger = logging.getLogger(__name__)


def _decode_header_value(value):
    """Decodes email header value. With EWS, values are already decoded strings."""
    if value is None:
        return ""
    return str(value)


def _extract_cin_from_subject(subject: str) -> str:
    """
    Extracts the CIN from the email subject line.
    CIN format is typically: YYYYMMDD_REFNO (e.g., 20240115_REF001)
    """
    if not subject:
        return None
    # Match CIN pattern: digits_alphanumeric
    match = re.search(r"(\d{8}_\w+)", subject)
    if match:
        return match.group(1)
    # Fallback: look for CIN keyword
    match = re.search(r"CIN[:\s]*(\S+)", subject, re.IGNORECASE)
    if match:
        return match.group(1)
    return None


def _get_ews_account() -> Account:
    """Creates and returns an authenticated EWS Account object."""
    ews_config = get_ews_config()

    if not ews_config["password"]:
        raise ValueError("No EWS password configured.")

    credentials = Credentials(
        username=ews_config["username"],
        password=ews_config["password"],
    )
    config = Configuration(
        server=ews_config["server"],
        credentials=credentials,
    )
    return Account(
        primary_smtp_address=ews_config["username"],
        config=config,
        autodiscover=False,
        access_type=DELEGATE,
    )


def _parse_ews_message(item) -> dict:
    """
    Parses a single EWS email item and extracts subject, CIN, body, and attachments.
    """
    subject = item.subject or ""
    from_address = ""
    if item.sender:
        from_address = item.sender.email_address or ""

    cin = _extract_cin_from_subject(subject)
    body = item.text_body or ""

    attachments = []
    if item.has_attachments and item.attachments:
        for attachment in item.attachments:
            if hasattr(attachment, "content") and attachment.content:
                attachments.append({
                    "filename": attachment.name or "unknown",
                    "data": base64.b64encode(attachment.content).decode("utf-8"),
                    "content_type": getattr(attachment, "content_type", "application/octet-stream"),
                })

    return {
        "subject": subject,
        "from": from_address,
        "cin": cin,
        "body": body,
        "has_attachments": len(attachments) > 0,
        "attachments": attachments,
    }


def fetch_unread_candidate_replies() -> list:
    """
    Connects to Exchange via EWS, fetches unread emails, parses subjects for CIN,
    extracts body and attachments.
    Returns a list of structured email payload dictionaries grouped by CIN.
    """
    ews_config = get_ews_config()
    logger.info("Connecting to Exchange via EWS to fetch candidate replies...")
    results = []

    try:
        if not ews_config["password"]:
            logger.warning("No EWS password configured. Skipping fetch.")
            return results

        account = _get_ews_account()

        unread = account.inbox.filter(is_read=False).order_by("-datetime_received")

        for item in unread:
            parsed = _parse_ews_message(item)
            parsed["msg_id"] = item.message_id or str(item.id)
            results.append(parsed)

            # Mark as read
            item.is_read = True
            item.save(update_fields=["is_read"])

        logger.info(f"Fetched and parsed {len(results)} unread emails via EWS.")
    except ValueError as e:
        logger.warning(str(e))
    except Exception as e:
        logger.error(f"Error fetching emails via EWS: {e}")
    return results
