import logging
from datetime import date
from sqlalchemy.orm import Session

from constants.database import _get_session, get_candidate_by_cin  # noqa: F401
from constants.constants import STATUS_MAIL_RECEIVED_ID, STATUS_PENDING_ID, JOB_TYPE_ATTACHMENTS_SAVED_ID
from etl_pipeline.models.schema import JobTracker, CandidateInfo

logger = logging.getLogger(__name__)


def get_candidate_by_email(session: Session, email_address: str):
    """
    Resolves a candidate by their PERSONAL_EMAIL_ID.
    Used as a fallback when CIN is not found in the email subject line.
    """
    if not email_address:
        return None
    # Extract just the email address if it's in "Name <email>" format
    import re
    match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", email_address)
    if not match:
        return None
    clean_email = match.group(0).lower()

    candidate = session.query(CandidateInfo).filter(
        CandidateInfo.PERSONAL_EMAIL_ID == clean_email
    ).first()
    return candidate


def deactivate_followup_for_candidate(session: Session, candidate_id: int):
    """
    Once a reply email is received from a candidate, deactivate the pending follow-up
    job in JOB_TRACKER by updating the status to 'Mail Received' (4).
    """
    from constants.constants import JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID
    pending_followups = session.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID == candidate_id,
        JobTracker.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
        JobTracker.STATUS_ID == STATUS_PENDING_ID,
    ).all()

    count = 0
    for job in pending_followups:
        job.STATUS_ID = STATUS_MAIL_RECEIVED_ID
        job.UPDATED_ON = date.today()
        count += 1

    logger.info(f"Deactivated {count} follow-up jobs for candidate {candidate_id}")
    return count


def create_attachment_saved_job(session: Session, candidate_id: int) -> JobTracker:
    """
    Creates a new JOB_TRACKER entry with job_type 'attachments saved' (3).
    """
    today = date.today()
    new_job = JobTracker(
        JOB_TYPE_ID=JOB_TYPE_ATTACHMENTS_SAVED_ID,
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=0,
        STATUS_ID=STATUS_PENDING_ID,
        ACTION_DATE=today,
        UPDATED_ON=today,
    )
    session.add(new_job)
    session.flush()
    return new_job
