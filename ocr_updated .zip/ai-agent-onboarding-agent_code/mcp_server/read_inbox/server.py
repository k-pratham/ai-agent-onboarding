import logging
from fastmcp import FastMCP
from mcp_server.read_inbox.tools.read_inbox import tool_read_inbox

logger = logging.getLogger(__name__)

read_inbox_server = FastMCP(
    name="Read Inbox Tool",
    description="Reads the email inbox for candidate replies, extracts CIN and attachments."
)


@read_inbox_server.tool()
async def read_inbox() -> dict:
    """Reads latest replies from candidates, extracts CIN from subjects, and classifies emails."""
    logger.info("MCP read_inbox: checking inbox")
    return await tool_read_inbox()
