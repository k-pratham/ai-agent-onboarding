import logging
from fastmcp import FastMCP
from mcp_server.ocr_classification.tools.ocr_classify import tool_ocr_and_segregate

logger = logging.getLogger(__name__)

ocr_classification_server = FastMCP(
    name="OCR Classification Tool",
    description="Performs OCR text extraction, document classification, and file segregation."
)


@ocr_classification_server.tool()
async def ocr_and_segregate(cin: str, file_path: str, tracker_id: int = None) -> dict:
    """Validates and classifies a document using OCR and LLM, then segregates into category folders."""
    logger.info(f"MCP ocr_and_segregate: classifying {file_path} for CIN {cin}")
    return await tool_ocr_and_segregate(cin, file_path, tracker_id)
