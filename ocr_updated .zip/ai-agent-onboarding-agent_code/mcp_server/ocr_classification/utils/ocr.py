"""
Document-to-image conversion utilities for vision-based classification.

Since numarkdown-8B-Thinking is a vision LLM, we convert documents directly
to base64-encoded images and pass them to the model — no text extraction needed.
"""

import os
import base64
import logging

logger = logging.getLogger(__name__)

# Supported image extensions that can be sent directly
_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}


def file_to_base64_images(file_path: str) -> list[dict]:
    """
    Converts a file (PDF or image) to a list of base64-encoded image dicts.

    For images: returns a single-item list with the image as base64.
    For PDFs: renders each page as a PNG image and returns all pages.

    Returns:
        List of dicts: [{"base64": "<data>", "media_type": "image/png"}, ...]
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = os.path.splitext(file_path)[1].lower()

    if ext in _IMAGE_EXTS:
        return [_encode_image_file(file_path, ext)]
    elif ext == ".pdf":
        return _render_pdf_pages(file_path)
    else:
        # Try treating as image
        return [_encode_image_file(file_path, ext)]


def _encode_image_file(file_path: str, ext: str) -> dict:
    """Read an image file and return its base64 encoding."""
    media_type = _ext_to_media_type(ext)
    with open(file_path, "rb") as f:
        data = base64.b64encode(f.read()).decode("utf-8")
    logger.info(f"Encoded image {file_path} as {media_type} ({len(data)} chars base64)")
    return {"base64": data, "media_type": media_type}


def _render_pdf_pages(file_path: str, dpi: int = 200) -> list[dict]:
    """Render each PDF page as a PNG image using PyMuPDF."""
    import fitz  # PyMuPDF

    images = []
    doc = fitz.open(file_path)
    try:
        for page_num in range(len(doc)):
            page = doc.load_page(page_num)
            # Render page to a pixmap at the given DPI
            zoom = dpi / 72.0
            mat = fitz.Matrix(zoom, zoom)
            pix = page.get_pixmap(matrix=mat)
            png_bytes = pix.tobytes("png")
            b64 = base64.b64encode(png_bytes).decode("utf-8")
            images.append({"base64": b64, "media_type": "image/png"})
            logger.info(f"Rendered PDF page {page_num + 1}/{len(doc)} from {file_path}")
    finally:
        doc.close()

    if not images:
        raise ValueError(f"PDF has no pages: {file_path}")

    return images


def _ext_to_media_type(ext: str) -> str:
    """Map file extension to MIME type."""
    mapping = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".bmp": "image/bmp",
        ".webp": "image/webp",
        ".tiff": "image/tiff",
    }
    return mapping.get(ext, "image/png")
