import os
import shutil
import logging
from mcp_server.ocr_classification.engine.helper_func import (
    classify_document_from_images,
    CATEGORY_TO_FOLDER,
    CATEGORY_TO_DOC_NAME,
)
from mcp_server.ocr_classification.utils.ocr import file_to_base64_images
from mcp_server.ocr_classification.engine.db_engine import (
    _get_session,
    get_document_type_by_name,
    update_document_tracker_after_ocr,
    get_candidate_by_cin,
)

logger = logging.getLogger(__name__)

# Rename prefix mapping per process_flow.md:
# education -> edu_, employment -> exp_, personal_details -> emp_
FOLDER_TO_PREFIX = {
    "education": "edu",
    "employment": "exp",
    "personal_details": "emp",
    "unmatched": "unmatched",
}


async def tool_ocr_and_segregate(cin: str, file_path: str, tracker_id: int = None) -> dict:
    """
    MCP Tool: Converts documents to images, performs vision-based LLM classification,
    file segregation into category folders, and DB status updates.

    Steps:
    1. Convert the document (PDF or image) to base64-encoded images.
    2. Classify document type via numarkdown-8b-thinking vision model.
    3. Segregate into the correct subfolder (education, employment, personal_details, unmatched).
    4. Rename file with the convention: {prefix}_{doc_type}_{cin}_{original_name}.
    5. Update DOCUMENT_TRACKER with classification result and status.

    Returns a dict with classification result, new file path, and status.
    """
    # Step 1: Convert document to base64 images
    images = file_to_base64_images(file_path)

    # Step 2: Classify document via vision LLM
    classification = classify_document_from_images(images)
    category = classification["category"]
    candidate_name_on_doc = classification.get("candidate_name")
    dob_on_doc = classification.get("date_of_birth")

    # Step 3: Determine target folder
    base_dir = os.path.dirname(file_path)
    file_name = os.path.basename(file_path)
    target_sub = CATEGORY_TO_FOLDER.get(category, "unmatched")
    target_dir = os.path.join(base_dir, target_sub)
    os.makedirs(target_dir, exist_ok=True)

    # Step 4: Rename file with convention
    prefix = FOLDER_TO_PREFIX.get(target_sub, "unmatched")
    new_file_name = f"{prefix}_{category}_{cin}_{file_name}"
    new_path = os.path.join(target_dir, new_file_name)
    shutil.move(file_path, new_path)

    # Determine verification status
    is_verified = target_sub != "unmatched" and category != "UNKNOWN"
    status_id = 5 if is_verified else 1  # 5=Verified, 1=Pending

    # Step 5: Update DOCUMENT_TRACKER in DB
    doc_type_id = None
    if tracker_id is not None:
        session = _get_session()
        try:
            # Resolve document type ID from master table
            doc_name = CATEGORY_TO_DOC_NAME.get(category)
            if doc_name:
                doc_type_record = get_document_type_by_name(session, doc_name)
                if doc_type_record:
                    doc_type_id = doc_type_record.DOCUMENT_TYPE_ID

            update_document_tracker_after_ocr(
                session=session,
                tracker_id=tracker_id,
                status_id=status_id,
                document_type_id=doc_type_id,
                file_path=new_path,
            )
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"DB update failed after OCR: {e}")
        finally:
            session.close()

    status_label = "verified" if is_verified else "pending"
    return {
        "cin": cin,
        "original_file": file_name,
        "classified_as": category,
        "folder": target_sub,
        "new_path": new_path,
        "status": status_label,
        "candidate_name_on_doc": candidate_name_on_doc,
        "dob_on_doc": dob_on_doc,
        "document_type_id": doc_type_id,
    }
