import logging
from datetime import date
from sqlalchemy.orm import Session

from constants.database import _get_session, get_candidate_by_cin  # noqa: F401
from etl_pipeline.models.schema import DocumentTracker, DocumentTypeMaster, CandidateInfo

logger = logging.getLogger(__name__)


def get_document_type_by_name(session: Session, doc_name: str):
    """
    Looks up the DOCUMENT_TYPE_MASTER by document name.
    Uses case-insensitive partial matching.
    """
    return session.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.DOCUMENT_NAME.ilike(f"%{doc_name}%"),
        DocumentTypeMaster.IS_ACTIVE == 1,
    ).first()


def update_document_tracker_after_ocr(
    session: Session,
    tracker_id: int,
    status_id: int,
    document_type_id: int = None,
    file_path: str = None,
):
    """
    Updates a DOCUMENT_TRACKER entry after OCR classification.
    Sets status to Verified (5) or keeps Pending (1) based on validation.
    Updates DOCUMENT_TYPE_ID if classification resolved the type.
    """
    record = session.query(DocumentTracker).filter(
        DocumentTracker.DOCUMENT_TRACKER_ID == tracker_id
    ).first()
    if record:
        record.STATUS_ID = status_id
        if document_type_id:
            record.DOCUMENT_TYPE_ID = document_type_id
        if file_path:
            record.COMMENTS = f"Verified and stored at: {file_path}"
        record.UPDATED_ON = date.today()
        logger.info(f"Updated document tracker {tracker_id} with status {status_id}")


def get_pending_documents_for_candidate(session: Session, candidate_id: int) -> list:
    """Fetches all pending document tracker entries for a candidate."""
    return session.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.STATUS_ID == 1,  # Pending
        DocumentTracker.IS_ACTIVE == 1,
    ).all()
