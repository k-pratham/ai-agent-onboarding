import os
import logging

from constants.llm_client import numarkdown_client
from constants.common_functions import get_numarkdown_config

logger = logging.getLogger(__name__)

# Fallback prompt path (used if config prompt_file does not exist)
_FALLBACK_PROMPT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "prompts",
    "ocr_prompt.txt",
)


def _load_prompt() -> str:
    cfg = get_numarkdown_config()
    prompt_path = cfg.get("prompt_file", _FALLBACK_PROMPT_PATH)
    if not os.path.exists(prompt_path):
        logger.warning(f"Prompt file not found at {prompt_path}, using fallback.")
        prompt_path = _FALLBACK_PROMPT_PATH
    with open(prompt_path, "r") as f:
        return f.read()


# Map of all recognized document categories
VALID_CATEGORIES = {
    "AADHAAR", "PAN", "TENTH_MARKSHEET", "TWELFTH_MARKSHEET",
    "DEGREE_CERTIFICATE", "EXPERIENCE_LETTER", "RELIEVING_LETTER",
    "SALARY_SLIP", "RESUME", "OFFER_LETTER", "PASSPORT",
    "DRIVING_LICENSE", "BANK_STATEMENT", "UNKNOWN",
}

# Maps OCR categories to the segregation folder and document name prefix
CATEGORY_TO_FOLDER = {
    "AADHAAR": "personal_details",
    "PAN": "personal_details",
    "PASSPORT": "personal_details",
    "DRIVING_LICENSE": "personal_details",
    "TENTH_MARKSHEET": "education",
    "TWELFTH_MARKSHEET": "education",
    "DEGREE_CERTIFICATE": "education",
    "EXPERIENCE_LETTER": "employment",
    "RELIEVING_LETTER": "employment",
    "SALARY_SLIP": "employment",
    "OFFER_LETTER": "employment",
    "RESUME": "employment",
    "BANK_STATEMENT": "personal_details",
}

# Maps OCR categories to DB document type name for matching against DocumentTypeMaster
CATEGORY_TO_DOC_NAME = {
    "AADHAAR": "Aadhaar Card",
    "PAN": "PAN Card",
    "TENTH_MARKSHEET": "10th Marksheet",
    "TWELFTH_MARKSHEET": "12th Marksheet",
    "DEGREE_CERTIFICATE": "Degree Certificate",
    "EXPERIENCE_LETTER": "Experience Letter",
    "RELIEVING_LETTER": "Relieving Letter",
    "SALARY_SLIP": "Salary Slips",
}


def classify_document_from_images(images: list[dict]) -> dict:
    """
    Classifies the document using the numarkdown-8b-thinking vision model via Aphrodite.
    Accepts a list of base64-encoded image dicts (from file_to_base64_images).
    Returns a dict with category, candidate_name, date_of_birth, and document_id.
    """
    prompt_text = _load_prompt()

    # Build multimodal content: text prompt + all document page images
    content = [{"type": "text", "text": prompt_text}]
    for img in images:
        data_uri = f"data:{img['media_type']};base64,{img['base64']}"
        content.append({
            "type": "image_url",
            "image_url": {"url": data_uri},
        })

    messages = [{"role": "user", "content": content}]

    try:
        result_text = numarkdown_client.get_text(messages)
        return _parse_classification_response(result_text)
    except Exception as e:
        logger.error(f"Classification inference failed: {str(e)}")
        return {
            "category": "UNKNOWN",
            "candidate_name": None,
            "date_of_birth": None,
            "document_id": None,
        }


def _parse_classification_response(response_text: str) -> dict:
    """Parses the structured LLM response into a dict."""
    result = {
        "category": "UNKNOWN",
        "candidate_name": None,
        "date_of_birth": None,
        "document_id": None,
    }

    for line in response_text.split("\n"):
        line = line.strip()
        if line.startswith("CATEGORY:"):
            cat = line.split(":", 1)[1].strip().upper()
            if cat in VALID_CATEGORIES:
                result["category"] = cat
        elif line.startswith("CANDIDATE_NAME:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NOT_FOUND":
                result["candidate_name"] = val
        elif line.startswith("DATE_OF_BIRTH:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NOT_FOUND":
                result["date_of_birth"] = val
        elif line.startswith("DOCUMENT_ID:"):
            val = line.split(":", 1)[1].strip()
            if val and val.upper() != "NOT_FOUND":
                result["document_id"] = val

    return result
