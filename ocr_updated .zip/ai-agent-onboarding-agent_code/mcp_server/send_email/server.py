import logging
from fastmcp import FastMCP
from mcp_server.send_email.tools.send_email import tool_send_email

logger = logging.getLogger(__name__)

send_email_server = FastMCP(
    name="Send Email Tool",
    description="Sends emails to candidates via SMTP."
)


@send_email_server.tool()
async def send_email(candidate_email: str, subject: str, draft_content: str) -> str:
    """Sends an email to a candidate given the HR-approved draft content."""
    logger.info(f"MCP send_email: sending to {candidate_email}")
    return await tool_send_email(candidate_email, subject, draft_content)
