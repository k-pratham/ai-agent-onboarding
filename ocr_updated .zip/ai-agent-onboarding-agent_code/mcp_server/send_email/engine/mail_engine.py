import logging
from exchangelib import Credentials, Account, Configuration, Message, Mailbox, DELEGATE
from constants.common_functions import get_ews_config

logger = logging.getLogger(__name__)


def _get_ews_account() -> Account:
    """Creates and returns an authenticated EWS Account object."""
    ews_config = get_ews_config()

    credentials = Credentials(
        username=ews_config["username"],
        password=ews_config["password"],
    )
    config = Configuration(
        server=ews_config["server"],
        credentials=credentials,
    )
    return Account(
        primary_smtp_address=ews_config["username"],
        config=config,
        autodiscover=False,
        access_type=DELEGATE,
    )


def dispatch_email(to_address: str, subject: str, draft_content: str):
    """
    Dispatches a pre-approved draft email via Exchange Web Services (EWS).
    Uses configuration from dev.properties via configparser.
    """
    try:
        account = _get_ews_account()

        message = Message(
            account=account,
            subject=subject,
            body=draft_content,
            to_recipients=[Mailbox(email_address=to_address)],
        )
        message.send()
        logger.info(f"Email successfully dispatched to {to_address} via EWS")
    except Exception as e:
        logger.error(f"Failed to send email to {to_address} via EWS: {e}")
        raise
