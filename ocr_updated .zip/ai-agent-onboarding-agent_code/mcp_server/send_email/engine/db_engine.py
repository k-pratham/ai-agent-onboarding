import logging
from datetime import date
from sqlalchemy.orm import Session

from constants.database import _get_session, create_followup_job  # noqa: F401
from constants.constants import (
    CANDIDATE_TYPE_COLUMN_MAP, STATUS_PENDING_ID, STATUS_MAIL_SENT_ID,
)
from etl_pipeline.models.schema import JobTracker, CandidateInfo, DocumentTracker, DocumentTypeMaster

logger = logging.getLogger(__name__)


def insert_document_tracker_entries(session: Session, candidate_id: int, job_id: int, candidate_type_id: int):
    """
    After initial mail is sent, insert required documents into DOCUMENT_TRACKER as pending.
    Documents are selected based on candidate type (Fresher/Experience/Dev Partner).
    """
    col_name = CANDIDATE_TYPE_COLUMN_MAP.get(candidate_type_id, "EXPERIENCE")

    required_docs = session.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()

    today = date.today()
    for doc_type in required_docs:
        existing = session.query(DocumentTracker).filter(
            DocumentTracker.CANDIDATE_ID == candidate_id,
            DocumentTracker.DOCUMENT_TYPE_ID == doc_type.DOCUMENT_TYPE_ID,
        ).first()
        if not existing:
            tracker_entry = DocumentTracker(
                CANDIDATE_ID=candidate_id,
                DOCUMENT_TYPE_ID=doc_type.DOCUMENT_TYPE_ID,
                STATUS_ID=STATUS_PENDING_ID,
                JOB_ID=job_id,
                CREATED_ON=today,
                UPDATED_ON=today,
                IS_ACTIVE=1,
            )
            session.add(tracker_entry)

    logger.info(f"Inserted {len(required_docs)} document tracker entries for candidate {candidate_id}")


def update_job_status_after_send(session: Session, job_id: int, draft_content: str):
    """
    Updates the job entry after email is sent: status -> Mail Sent, human action resolved.
    """
    job = session.query(JobTracker).filter(JobTracker.JOB_ID == job_id).first()
    if job:
        job.STATUS_ID = STATUS_MAIL_SENT_ID
        job.HUMAN_ACTION_REQUIRED = 0
        job.HUMAN_ACTION = "Approved"
        job.DRAFT_MAIL = draft_content
        job.UPDATED_ON = date.today()
    return job
