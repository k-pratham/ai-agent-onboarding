import logging
from mcp_server.send_email.engine.mail_engine import dispatch_email

logger = logging.getLogger(__name__)


async def tool_send_email(candidate_email: str, subject: str, draft_content: str) -> str:
    """
    MCP Tool: Sends an email to a candidate given the HR-approved draft content.
    Returns status confirming the operation.
    """
    try:
        dispatch_email(candidate_email, subject, draft_content)
        return f"Successfully sent email to {candidate_email} with subject '{subject}'"
    except Exception as e:
        return f"Error sending email: {str(e)}"
