"""
Mail service — handles draft retrieval/generation and mail dispatch for all 4 stepper steps
that involve email (steps 2, 3, 5, 6).
"""

import datetime
import logging
from typing import Optional

from sqlalchemy.orm import Session
from sqlalchemy.sql import func

from etl_pipeline.models.schema import (
    CandidateInfo, JobTracker, DocumentTracker, DocumentTypeMaster,
)
from ai_onboarding_brain.src.core.config import settings, get_logger
from ai_onboarding_brain.src.core.exceptions import CandidateNotFoundError, ToolExecutionError
from ai_onboarding_brain.src.schemas.mail import MailDraftResponse, SendMailRequest, SendMailResponse
from ai_onboarding_brain.src.services.hr_service import _insert_required_documents
from constants.constants import CANDIDATE_TYPE_COLUMN_MAP

logger = get_logger(__name__)

# Step → JOB_TYPE_ID mapping
_STEP_TO_JOB_TYPE = {
    2: settings.JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,   # 1
    3: settings.JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,        # 2
    5: settings.JOB_TYPE_ONBOARDING_MAIL_ID,             # 8
    6: settings.JOB_TYPE_IT_ADMIN_MAIL_ID,               # 9
}


def _get_pending_doc_names(db: Session, candidate_id: int, candidate_type_id: int) -> list[str]:
    """Fetch names of pending/missing documents for a candidate."""
    col_name = CANDIDATE_TYPE_COLUMN_MAP.get(candidate_type_id, "EXPERIENCE")
    required = db.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()

    tracked = db.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()
    verified_ids = {
        d.DOCUMENT_TYPE_ID for d in tracked
        if d.STATUS_ID in (settings.STATUS_VERIFIED_ID, settings.STATUS_COMPLETED_ID)
    }

    return [doc.DOCUMENT_NAME for doc in required if doc.DOCUMENT_TYPE_ID not in verified_ids]


def _generate_step2_draft(candidate: CandidateInfo, pending_docs: list[str]) -> str:
    """Generate initial document request email (template-based, no LLM)."""
    try:
        from mcp_server.draft_prepare.engine.helper_func import generate_initial_draft
        from mcp_server.draft_prepare.engine.db_engine import get_mail_template
        from constants.database import _get_session

        session = _get_session()
        try:
            mail_template = get_mail_template(session, "initial_documents")
        finally:
            session.close()

        return generate_initial_draft(
            candidate.CANDIDATE_NAME or candidate.CIN,
            pending_docs,
            candidate.CIN,
            mail_template,
        )
    except Exception as e:
        logger.warning(f"Draft generation for step 2 failed, using fallback: {e}")
        return _fallback_draft(candidate, pending_docs)


def _generate_step3_draft(candidate: CandidateInfo, pending_docs: list[str]) -> str:
    """Generate follow-up email (LLM-based with fallback)."""
    try:
        from mcp_server.draft_prepare.engine.helper_func import generate_followup_draft
        return generate_followup_draft(
            candidate.CANDIDATE_NAME or candidate.CIN,
            pending_docs,
            candidate.CIN,
        )
    except Exception as e:
        logger.warning(f"Draft generation for step 3 failed, using fallback: {e}")
        return _fallback_draft(candidate, pending_docs)


def _generate_step5_draft(candidate: CandidateInfo) -> str:
    """Generate onboarding welcome / joining confirmation email (template-based)."""
    name = candidate.CANDIDATE_NAME or candidate.CIN
    doj = candidate.EXPECTED_DOJ_WRT_TO_NP
    designation = candidate.DESIGNATION_TO_BE_PRINTED_ON_THE_OFFER_LETTER or "your designated role"
    location = candidate.REPORTING_LOCATION or candidate.WORK_BASE_LOCATION or "the office"

    return (
        f"Dear {name},\n\n"
        f"Congratulations! We are pleased to confirm that all your onboarding documents "
        f"have been received and verified successfully.\n\n"
        f"Your expected date of joining is {doj}. You will be joining as "
        f"{designation} at {location}.\n\n"
        f"We will share further details regarding your joining formalities, "
        f"including reporting time, dress code, and first-day schedule, shortly.\n\n"
        f"Welcome aboard!\n\n"
        f"Regards,\nHR Onboarding Team"
    )


def _generate_step6_draft(candidate: CandidateInfo) -> str:
    """Generate IT provisioning request email (template-based)."""
    name = candidate.CANDIDATE_NAME or candidate.CIN
    cin = candidate.CIN
    doj = candidate.EXPECTED_DOJ_WRT_TO_NP
    designation = candidate.DESIGNATION_TO_BE_PRINTED_ON_THE_OFFER_LETTER or "N/A"
    technology = candidate.TECHNOLOGY or "N/A"
    location = candidate.REPORTING_LOCATION or candidate.WORK_BASE_LOCATION or "N/A"
    bu = candidate.BU or "N/A"
    manager = candidate.MANAGER_NAME or "N/A"

    return (
        f"Dear IT Admin,\n\n"
        f"Please provision the following for a new joiner:\n\n"
        f"Name: {name}\n"
        f"CIN: {cin}\n"
        f"Designation: {designation}\n"
        f"Technology: {technology}\n"
        f"Business Unit: {bu}\n"
        f"Reporting Manager: {manager}\n"
        f"Location: {location}\n"
        f"Expected Date of Joining: {doj}\n\n"
        f"Required provisioning:\n"
        f"- Laptop / Workstation\n"
        f"- Email account and distribution lists\n"
        f"- VPN and network access\n"
        f"- Badge / access card\n"
        f"- Required software licenses\n\n"
        f"Please ensure the setup is complete before the joining date.\n\n"
        f"Regards,\nHR Onboarding Team"
    )


def _fallback_draft(candidate: CandidateInfo, pending_docs: list[str]) -> str:
    """Template-based fallback when LLM/MCP calls fail."""
    name = candidate.CANDIDATE_NAME or candidate.CIN
    doc_list = "\n".join(f"  - {d}" for d in pending_docs)
    return (
        f"Dear {name},\n\n"
        f"As part of your onboarding (CIN: {candidate.CIN}), please submit:\n{doc_list}\n\n"
        f"Reply with attachments. Include your CIN in the subject.\n\n"
        f"Regards,\nHR Onboarding Team"
    )


def get_mail_draft(
    db: Session, candidate_id: int, step: int, regenerate: bool = False,
) -> MailDraftResponse:
    """
    Get or generate a mail draft for a specific stepper step.
    Returns pre-filled to, cc, subject, and body fields for the compose form.
    """
    if step not in _STEP_TO_JOB_TYPE:
        raise ValueError(f"Invalid step {step}. Must be one of: 2, 3, 5, 6")

    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise CandidateNotFoundError(f"Candidate {candidate_id} not found")

    cin = candidate.CIN or ""
    ctype = candidate.CANDIDATE_TYPE_ID or 2
    job_type_id = _STEP_TO_JOB_TYPE[step]

    # Look for an existing job with a draft
    existing_job = db.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID == candidate_id,
        JobTracker.JOB_TYPE_ID == job_type_id,
    ).order_by(JobTracker.JOB_ID.desc()).first()

    job_id = existing_job.JOB_ID if existing_job else None
    existing_draft = (existing_job.DRAFT_MAIL or "") if existing_job else ""

    # Determine if we need to generate a new draft
    need_generate = regenerate or not existing_draft

    if need_generate:
        if step == 2:
            pending_docs = _get_pending_doc_names(db, candidate_id, ctype)
            body = _generate_step2_draft(candidate, pending_docs)
        elif step == 3:
            pending_docs = _get_pending_doc_names(db, candidate_id, ctype)
            body = _generate_step3_draft(candidate, pending_docs)
        elif step == 5:
            body = _generate_step5_draft(candidate)
        elif step == 6:
            body = _generate_step6_draft(candidate)
        else:
            body = ""
    else:
        body = existing_draft

    # Pre-fill to, cc, subject based on step
    to, cc, subject = _get_prefilled_fields(step, candidate, cin)

    return MailDraftResponse(
        candidate_id=candidate_id,
        cin=cin,
        step=step,
        job_id=job_id,
        to=to,
        cc=cc,
        subject=subject,
        body=body,
        is_editable=True,
    )


def _get_prefilled_fields(step: int, candidate: CandidateInfo, cin: str):
    """Return (to, cc, subject) pre-filled for a given step."""
    candidate_email = candidate.PERSONAL_EMAIL_ID or ""
    recruiter = candidate.RECRUITER_NAME or ""
    manager = candidate.MANAGER_NAME or ""
    buddy = candidate.BUDDY or ""
    name = candidate.CANDIDATE_NAME or cin

    if step == 2:
        return (
            candidate_email,
            recruiter,
            f"Document Submission Required - CIN {cin}",
        )
    elif step == 3:
        return (
            candidate_email,
            recruiter,
            f"Follow-up: Pending Document Submission - CIN {cin}",
        )
    elif step == 5:
        cc_list = ", ".join(filter(None, [manager, buddy]))
        return (
            candidate_email,
            cc_list or None,
            f"Welcome Aboard - Joining Confirmation - {name}",
        )
    elif step == 6:
        return (
            settings.IT_ADMIN_EMAIL,
            manager or None,
            f"IT Provisioning Request - {name} (CIN {cin})",
        )
    return (candidate_email, None, f"HR Onboarding - CIN {cin}")


async def send_mail(
    db: Session, candidate_id: int, request: SendMailRequest,
) -> SendMailResponse:
    """
    Send a mail from the compose form. Updates or creates a JOB_TRACKER row,
    dispatches the email, and handles post-send actions (doc tracker insert, follow-up job).
    """
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise CandidateNotFoundError(f"Candidate {candidate_id} not found")

    step = request.step
    if step not in _STEP_TO_JOB_TYPE:
        raise ValueError(f"Invalid step {step}. Must be one of: 2, 3, 5, 6")

    job_type_id = _STEP_TO_JOB_TYPE[step]
    today = datetime.date.today()

    # 1. Send the email
    try:
        from mcp_server.send_email.tools.send_email import tool_send_email
        status_msg = await tool_send_email(request.to, request.subject, request.body)
    except Exception as e:
        logger.error(f"Email dispatch failed: {e}")
        raise ToolExecutionError(f"Email dispatch failure: {str(e)}")

    # 2. Update or create JOB_TRACKER row
    if request.job_id:
        job = db.query(JobTracker).filter(JobTracker.JOB_ID == request.job_id).first()
        if not job:
            raise CandidateNotFoundError(f"Job {request.job_id} not found")
        job.DRAFT_MAIL = request.body
        job.STATUS_ID = settings.STATUS_MAIL_SENT_ID
        job.HUMAN_ACTION_REQUIRED = 0
        job.HUMAN_ACTION = "Approved and Sent"
        job.UPDATED_ON = today
        job_id = job.JOB_ID
    else:
        new_job = JobTracker(
            JOB_TYPE_ID=job_type_id,
            CANDIDATE_ID=candidate_id,
            HUMAN_ACTION_REQUIRED=0,
            STATUS_ID=settings.STATUS_MAIL_SENT_ID,
            DRAFT_MAIL=request.body,
            HUMAN_ACTION="Approved and Sent",
            ACTION_DATE=today,
            UPDATED_ON=today,
        )
        db.add(new_job)
        db.flush()
        job_id = new_job.JOB_ID

    # 3. Post-send actions per step
    if step == 2:
        # Insert required documents into DOCUMENT_TRACKER
        ctype = candidate.CANDIDATE_TYPE_ID or 2
        _insert_required_documents(db, candidate.CANDIDATE_ID, ctype, job_id)

        # Create follow-up job (ACTION_DATE = today + 2 days)
        followup_job = JobTracker(
            JOB_TYPE_ID=settings.JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
            CANDIDATE_ID=candidate_id,
            HUMAN_ACTION_REQUIRED=0,
            STATUS_ID=settings.STATUS_PENDING_ID,
            ACTION_DATE=today + datetime.timedelta(days=2),
            UPDATED_ON=today,
        )
        db.add(followup_job)

    elif step == 3:
        # Create next follow-up job (ACTION_DATE = today + 2 days)
        next_followup = JobTracker(
            JOB_TYPE_ID=settings.JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
            CANDIDATE_ID=candidate_id,
            HUMAN_ACTION_REQUIRED=0,
            STATUS_ID=settings.STATUS_PENDING_ID,
            ACTION_DATE=today + datetime.timedelta(days=2),
            UPDATED_ON=today,
        )
        db.add(next_followup)

    elif step == 5:
        # After onboarding mail sent, create IT admin mail job (step 6)
        existing_it = db.query(JobTracker).filter(
            JobTracker.CANDIDATE_ID == candidate_id,
            JobTracker.JOB_TYPE_ID == settings.JOB_TYPE_IT_ADMIN_MAIL_ID,
        ).first()
        if not existing_it:
            it_job = JobTracker(
                JOB_TYPE_ID=settings.JOB_TYPE_IT_ADMIN_MAIL_ID,
                CANDIDATE_ID=candidate_id,
                HUMAN_ACTION_REQUIRED=1,
                STATUS_ID=settings.STATUS_PENDING_ID,
                REMARK="IT provisioning request pending",
                ACTION_DATE=today,
                UPDATED_ON=today,
            )
            db.add(it_job)

    db.commit()

    return SendMailResponse(
        success=True,
        message=status_msg or "Email sent successfully",
        job_id=job_id,
    )
