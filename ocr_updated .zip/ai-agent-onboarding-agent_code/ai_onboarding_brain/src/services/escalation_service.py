import os
import datetime
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from etl_pipeline.models.schema import JobTracker, CandidateInfo, DocumentTracker, DocumentTypeMaster
from ai_onboarding_brain.src.core.config import settings, get_logger
from ai_onboarding_brain.src.core.exceptions import CandidateNotFoundError, DatabaseTransactionError

logger = get_logger(__name__)

ESCALATION_PROMPT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
    "mcp_server", "send_email", "prompts", "escalation_prompt.txt",
)

ESCALATION_THRESHOLD = 2


def _get_missing_docs(db: Session, candidate_id: int, candidate_type_id: int) -> list:
    """Fetches missing document names for a candidate."""
    type_col_map = {1: "FRESHER", 2: "EXPERIENCE", 3: "DEV_PARTNER"}
    col_name = type_col_map.get(candidate_type_id, "EXPERIENCE")

    required = db.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()

    tracked = db.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()
    verified_ids = {d.DOCUMENT_TYPE_ID for d in tracked if d.STATUS_ID in (5, 7)}

    return [doc.DOCUMENT_NAME for doc in required if doc.DOCUMENT_TYPE_ID not in verified_ids]


def check_and_send_escalation(db: Session, candidate_id: int) -> dict:
    """
    Checks if a candidate has exceeded the escalation threshold (2 failed follow-ups).
    If so, generates and queues an escalation email to HR.
    """
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise CandidateNotFoundError(f"Candidate {candidate_id} not found.")

    # Count follow-up mails that were sent (status = Mail Sent, type = Follow Up)
    followup_count = db.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID == candidate_id,
        JobTracker.JOB_TYPE_ID == settings.JOB_TYPE_FOLLOW_UP_ID,
        JobTracker.STATUS_ID == settings.STATUS_MAIL_SENT_ID,
    ).count()

    if followup_count < ESCALATION_THRESHOLD:
        return {"escalation_needed": False, "followup_count": followup_count}

    candidate_type_id = candidate.CANDIDATE_TYPE_ID or 2
    missing_docs = _get_missing_docs(db, candidate.CANDIDATE_ID, candidate_type_id)

    # Generate escalation email
    escalation_body = (
        f"ESCALATION NOTICE\n\n"
        f"Candidate: {candidate.CANDIDATE_NAME} (CIN: {candidate.CIN})\n"
        f"Email: {candidate.PERSONAL_EMAIL_ID}\n"
        f"Failed Follow-up Attempts: {followup_count}\n\n"
        f"Missing Documents:\n"
        + "\n".join(f"  - {doc}" for doc in missing_docs)
        + "\n\nPlease review and take appropriate action."
    )

    # Create a job entry for the escalation
    today = datetime.date.today()
    escalation_job = JobTracker(
        JOB_TYPE_ID=settings.JOB_TYPE_FOLLOW_UP_ID,
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=1,
        STATUS_ID=settings.STATUS_MAIL_DRAFTED_ID,
        DRAFT_MAIL=escalation_body,
        REMARK="Escalation: Candidate unresponsive after multiple follow-ups",
        ACTION_DATE=today,
        UPDATED_ON=today,
    )
    db.add(escalation_job)

    logger.warning(f"Escalation created for CIN {candidate.CIN} after {followup_count} failed follow-ups")

    return {
        "escalation_needed": True,
        "followup_count": followup_count,
        "cin": candidate.CIN,
        "missing_docs": missing_docs,
    }


def send_summary_and_joining_mail(db: Session, candidate_id: int) -> dict:
    """
    Once all documents are verified and complete, creates:
    1. A summary email to HR with the candidate's onboarding status.
    2. A joining confirmation email to the candidate.
    """
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise CandidateNotFoundError(f"Candidate {candidate_id} not found.")

    today = datetime.date.today()

    # Summary mail to HR
    summary_body = (
        f"ONBOARDING SUMMARY\n\n"
        f"Candidate: {candidate.CANDIDATE_NAME} (CIN: {candidate.CIN})\n"
        f"Email: {candidate.PERSONAL_EMAIL_ID}\n"
        f"Expected DOJ: {candidate.EXPECTED_DOJ_WRT_TO_NP}\n"
        f"Status: All documents verified and complete.\n\n"
        f"The candidate is ready for joining. Please proceed with the joining formalities."
    )

    summary_job = JobTracker(
        JOB_TYPE_ID=settings.JOB_TYPE_MAIL_SENT_ID,
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=1,
        STATUS_ID=settings.STATUS_MAIL_DRAFTED_ID,
        DRAFT_MAIL=summary_body,
        REMARK="Summary mail to HR - All documents complete",
        ACTION_DATE=today,
        UPDATED_ON=today,
    )
    db.add(summary_job)

    # Joining mail to candidate
    joining_body = (
        f"Dear {candidate.CANDIDATE_NAME},\n\n"
        f"Congratulations! We are pleased to confirm that all your onboarding documents "
        f"have been received and verified successfully.\n\n"
        f"Your expected date of joining is {candidate.EXPECTED_DOJ_WRT_TO_NP}. "
        f"We will share further details regarding your joining formalities shortly.\n\n"
        f"Welcome aboard!\n\n"
        f"Regards,\nHR Onboarding Team"
    )

    joining_job = JobTracker(
        JOB_TYPE_ID=settings.JOB_TYPE_MAIL_SENT_ID,
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=1,
        STATUS_ID=settings.STATUS_MAIL_DRAFTED_ID,
        DRAFT_MAIL=joining_body,
        REMARK="Joining confirmation mail to candidate",
        ACTION_DATE=today,
        UPDATED_ON=today,
    )
    db.add(joining_job)

    # Update all document trackers to 'Completed'
    docs = db.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.STATUS_ID == 5,  # Verified
        DocumentTracker.IS_ACTIVE == 1,
    ).all()
    for doc in docs:
        doc.STATUS_ID = 7  # Completed
        doc.UPDATED_ON = today

    logger.info(f"Summary and joining mails created for CIN {candidate.CIN}")

    return {
        "cin": candidate.CIN,
        "summary_drafted": True,
        "joining_drafted": True,
        "documents_completed": len(docs),
    }
