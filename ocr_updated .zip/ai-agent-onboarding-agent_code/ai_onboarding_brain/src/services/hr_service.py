import datetime
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from etl_pipeline.models.schema import JobTracker, CandidateInfo, DocumentTypeMaster, DocumentTracker
from ai_onboarding_brain.src.core.config import settings, get_logger
from ai_onboarding_brain.src.core.exceptions import CandidateNotFoundError, DatabaseTransactionError, ToolExecutionError
from mcp_server.send_email.tools.send_email import tool_send_email

logger = get_logger(__name__)


def _insert_required_documents(db: Session, candidate_id: int, candidate_type_id: int, job_id: int):
    """
    After initial mail is sent, insert required documents into DOCUMENT_TRACKER as pending.
    Documents are selected based on candidate type (Fresher/Experience/Dev Partner).
    """
    type_col_map = {1: "FRESHER", 2: "EXPERIENCE", 3: "DEV_PARTNER"}
    col_name = type_col_map.get(candidate_type_id, "EXPERIENCE")

    required_docs = db.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).all()

    today = datetime.date.today()
    for doc_type in required_docs:
        existing = db.query(DocumentTracker).filter(
            DocumentTracker.CANDIDATE_ID == candidate_id,
            DocumentTracker.DOCUMENT_TYPE_ID == doc_type.DOCUMENT_TYPE_ID,
        ).first()
        if not existing:
            tracker_entry = DocumentTracker(
                CANDIDATE_ID=candidate_id,
                DOCUMENT_TYPE_ID=doc_type.DOCUMENT_TYPE_ID,
                STATUS_ID=settings.STATUS_PENDING_ID,
                JOB_ID=job_id,
                CREATED_ON=today,
                UPDATED_ON=today,
                IS_ACTIVE=1,
            )
            db.add(tracker_entry)


async def process_draft_approval(db: Session, job_id: int, candidate_email: str, subject: str, draft_content: str) -> dict:
    """
    Called when HR approves a generated draft from the UI.
    Dispatches the email via MCP tools, updates Job Tracker, creates follow-up,
    and inserts document tracker entries for initial mails.
    """
    logger.info(f"HR approved draft dispatch for Job ID {job_id}")

    # 1. Send the email
    try:
        status_msg = await tool_send_email(candidate_email, subject, draft_content)
    except Exception as e:
        logger.error(f"SMTP dispatch failed: {e}")
        raise ToolExecutionError(f"Email dispatch failure: {str(e)}")

    try:
        # 2. Update the current job entry
        job_entry = db.query(JobTracker).filter(JobTracker.JOB_ID == job_id).first()
        if not job_entry:
            raise CandidateNotFoundError(f"JobTracker entry {job_id} not found.")

        from sqlalchemy.sql import func
        job_entry.HUMAN_ACTION_REQUIRED = 0
        job_entry.STATUS_ID = settings.STATUS_MAIL_SENT_ID
        job_entry.HUMAN_ACTION = "Approved"
        job_entry.UPDATED_ON = func.current_date()
        job_entry.DRAFT_MAIL = draft_content

        # 3. If this is the initial mail (JOB_TYPE_ID=1), insert document tracker entries
        if job_entry.JOB_TYPE_ID == settings.JOB_TYPE_MAIL_SENT_ID:
            candidate = db.query(CandidateInfo).filter(
                CandidateInfo.CANDIDATE_ID == job_entry.CANDIDATE_ID
            ).first()
            if candidate:
                candidate_type_id = candidate.CANDIDATE_TYPE_ID or 2
                _insert_required_documents(db, candidate.CANDIDATE_ID, candidate_type_id, job_id)

        # 4. Create follow-up job entry (ACTION_DATE = today + 2 days)
        next_action_date = datetime.date.today() + datetime.timedelta(days=2)
        new_followup_job = JobTracker(
            JOB_TYPE_ID=settings.JOB_TYPE_FOLLOW_UP_ID,
            CANDIDATE_ID=job_entry.CANDIDATE_ID,
            HUMAN_ACTION_REQUIRED=0,
            STATUS_ID=settings.STATUS_PENDING_ID,
            ACTION_DATE=next_action_date,
            UPDATED_ON=func.current_date(),
        )
        db.add(new_followup_job)

        db.commit()
    except CandidateNotFoundError:
        raise
    except SQLAlchemyError as e:
        db.rollback()
        logger.error(f"DB transaction failed during approval: {e}")
        raise DatabaseTransactionError("Failed to persist actions to database.")
    except Exception as e:
        db.rollback()
        logger.error(f"Unexpected failure during draft approval: {e}")
        raise

    return {"status": "success", "message": status_msg}
