import datetime
from typing import Optional

from sqlalchemy.orm import Session

from etl_pipeline.models.schema import (
    CandidateInfo, DocumentTracker, DocumentTypeMaster, JobTracker,
)
from ai_onboarding_brain.src.core.config import settings, get_logger
from ai_onboarding_brain.src.core.exceptions import CandidateNotFoundError
from ai_onboarding_brain.src.schemas.document import (
    CandidateDocumentListResponse, DocumentRow,
    BulkDocumentActionRequest, BulkDocumentActionResponse, DocumentActionResult,
)
from constants.constants import CANDIDATE_TYPE_COLUMN_MAP

logger = get_logger(__name__)

STATUS_LABELS = {
    1: "Pending", 2: "Mail Drafted", 3: "Mail Sent",
    4: "Mail Received", 5: "Verified", 6: "Rejected", 7: "Completed",
}


def _get_candidate_type_label(candidate_type_id: int) -> str:
    return {1: "Fresher", 2: "Experience", 3: "Dev Partner"}.get(
        candidate_type_id, "Experience"
    )


def get_candidate_documents(db: Session, candidate_id: int) -> CandidateDocumentListResponse:
    """Fetch all active documents for a candidate with their statuses."""
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise CandidateNotFoundError(f"Candidate {candidate_id} not found")

    rows = (
        db.query(DocumentTracker, DocumentTypeMaster)
        .join(
            DocumentTypeMaster,
            DocumentTracker.DOCUMENT_TYPE_ID == DocumentTypeMaster.DOCUMENT_TYPE_ID,
        )
        .filter(
            DocumentTracker.CANDIDATE_ID == candidate_id,
            DocumentTracker.IS_ACTIVE == 1,
        )
        .all()
    )

    documents = []
    for tracker, doc_type in rows:
        submitted = (
            tracker.DOCUMENT_RECIVED_ON is not None
            or tracker.STATUS_ID >= settings.STATUS_MAIL_RECEIVED_ID
        )
        documents.append(DocumentRow(
            document_tracker_id=tracker.DOCUMENT_TRACKER_ID,
            document_type_id=tracker.DOCUMENT_TYPE_ID,
            document_name=doc_type.DOCUMENT_NAME,
            status=STATUS_LABELS.get(tracker.STATUS_ID, "Unknown"),
            status_id=tracker.STATUS_ID,
            submitted=submitted,
            received_on=str(tracker.DOCUMENT_RECIVED_ON) if tracker.DOCUMENT_RECIVED_ON else None,
            comments=tracker.COMMENTS,
            is_active=bool(tracker.IS_ACTIVE),
        ))

    ctype = candidate.CANDIDATE_TYPE_ID or 2
    return CandidateDocumentListResponse(
        candidate_id=candidate.CANDIDATE_ID,
        cin=candidate.CIN or "",
        candidate_name=candidate.CANDIDATE_NAME or candidate.CIN or "",
        candidate_type=_get_candidate_type_label(ctype),
        documents=documents,
    )


def approve_document(db: Session, document_tracker_id: int, comments: Optional[str] = None) -> dict:
    """Approve a single document (set STATUS_ID=5 VERIFIED)."""
    tracker = db.query(DocumentTracker).filter(
        DocumentTracker.DOCUMENT_TRACKER_ID == document_tracker_id
    ).first()
    if not tracker:
        raise CandidateNotFoundError(f"Document tracker {document_tracker_id} not found")

    tracker.STATUS_ID = settings.STATUS_VERIFIED_ID
    if comments:
        tracker.COMMENTS = comments
    tracker.UPDATED_ON = datetime.date.today()
    db.flush()

    # Check if all docs for this candidate are now verified/completed
    _check_and_trigger_completion(db, tracker.CANDIDATE_ID)

    db.commit()
    return {
        "success": True,
        "message": "Document approved successfully",
        "document_tracker_id": document_tracker_id,
        "new_status": "Verified",
    }


def reject_document(db: Session, document_tracker_id: int, rejection_reason: str) -> dict:
    """Reject a single document (set STATUS_ID=6 REJECTED)."""
    tracker = db.query(DocumentTracker).filter(
        DocumentTracker.DOCUMENT_TRACKER_ID == document_tracker_id
    ).first()
    if not tracker:
        raise CandidateNotFoundError(f"Document tracker {document_tracker_id} not found")

    tracker.STATUS_ID = settings.STATUS_REJECTED_ID
    tracker.COMMENTS = rejection_reason
    tracker.UPDATED_ON = datetime.date.today()
    db.commit()

    return {
        "success": True,
        "message": "Document rejected",
        "document_tracker_id": document_tracker_id,
        "new_status": "Rejected",
    }


def bulk_document_action(
    db: Session, candidate_id: int, request: BulkDocumentActionRequest,
) -> BulkDocumentActionResponse:
    """Bulk approve or reject multiple documents."""
    if request.action not in ("approve", "reject"):
        return BulkDocumentActionResponse(
            success=False,
            results=[DocumentActionResult(
                document_tracker_id=0, status="error",
                message=f"Invalid action '{request.action}'. Must be 'approve' or 'reject'.",
            )],
        )

    if request.action == "reject" and not request.rejection_reason:
        return BulkDocumentActionResponse(
            success=False,
            results=[DocumentActionResult(
                document_tracker_id=0, status="error",
                message="rejection_reason is required for reject action",
            )],
        )

    results = []
    today = datetime.date.today()

    for doc_id in request.document_tracker_ids:
        tracker = db.query(DocumentTracker).filter(
            DocumentTracker.DOCUMENT_TRACKER_ID == doc_id
        ).first()

        if not tracker:
            results.append(DocumentActionResult(
                document_tracker_id=doc_id, status="error",
                message="Document not found",
            ))
            continue

        if request.action == "approve":
            tracker.STATUS_ID = settings.STATUS_VERIFIED_ID
            tracker.UPDATED_ON = today
            results.append(DocumentActionResult(
                document_tracker_id=doc_id, status="approved", message="OK",
            ))
        else:
            tracker.STATUS_ID = settings.STATUS_REJECTED_ID
            tracker.COMMENTS = request.rejection_reason
            tracker.UPDATED_ON = today
            results.append(DocumentActionResult(
                document_tracker_id=doc_id, status="rejected", message="OK",
            ))

    db.flush()

    # Check completion if any were approved
    if request.action == "approve":
        _check_and_trigger_completion(db, candidate_id)

    db.commit()

    all_ok = all(r.status != "error" for r in results)
    return BulkDocumentActionResponse(success=all_ok, results=results)


def _check_and_trigger_completion(db: Session, candidate_id: int):
    """
    After document approval, check if ALL required docs for this candidate
    are now verified/completed. If so, create an onboarding mail draft job (step 5).
    """
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        return

    ctype = candidate.CANDIDATE_TYPE_ID or 2
    col_name = CANDIDATE_TYPE_COLUMN_MAP.get(ctype, "EXPERIENCE")

    required_count = db.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).count()

    if required_count == 0:
        return

    verified_count = db.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
        DocumentTracker.STATUS_ID.in_([
            settings.STATUS_VERIFIED_ID, settings.STATUS_COMPLETED_ID,
        ]),
    ).count()

    if verified_count >= required_count:
        # All docs verified — check if step 5 job already exists
        existing = db.query(JobTracker).filter(
            JobTracker.CANDIDATE_ID == candidate_id,
            JobTracker.JOB_TYPE_ID == settings.JOB_TYPE_ONBOARDING_MAIL_ID,
        ).first()

        if not existing:
            today = datetime.date.today()
            onboarding_job = JobTracker(
                JOB_TYPE_ID=settings.JOB_TYPE_ONBOARDING_MAIL_ID,
                CANDIDATE_ID=candidate_id,
                HUMAN_ACTION_REQUIRED=1,
                STATUS_ID=settings.STATUS_PENDING_ID,
                REMARK="All documents verified - onboarding welcome mail pending",
                ACTION_DATE=today,
                UPDATED_ON=today,
            )
            db.add(onboarding_job)
            logger.info(
                f"All docs verified for candidate {candidate_id} — "
                f"created onboarding mail job (step 5)"
            )
