import math
from datetime import date
from typing import List, Optional

from sqlalchemy.orm import Session
from sqlalchemy import or_

from etl_pipeline.models.schema import (
    CandidateInfo, CandidateTypeMaster, JobTracker,
    DocumentTracker, DocumentTypeMaster,
)
from ai_onboarding_brain.src.core.config import settings, get_logger
from ai_onboarding_brain.src.schemas.dashboard import (
    DashboardSummaryResponse, CandidateHubRow, PaginatedCandidateListResponse,
)
from constants.constants import CANDIDATE_TYPE_COLUMN_MAP

logger = get_logger(__name__)

STEP_LABELS = {
    1: "Offer Released",
    2: "Document Required Mail",
    3: "Follow-up Mail Drop",
    4: "Document List",
    5: "On-Boarding Mail",
    6: "IT-Admin Mail",
}

# Map step numbers to the JOB_TYPE_ID used to detect completion
_STEP_JOB_TYPE_MAP = {
    2: settings.JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,   # 1
    3: settings.JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,        # 2
    5: settings.JOB_TYPE_ONBOARDING_MAIL_ID,             # 8
    6: settings.JOB_TYPE_IT_ADMIN_MAIL_ID,               # 9
}


def get_step_label(step: int) -> str:
    return STEP_LABELS.get(step, "Unknown")


def _is_dropout(candidate: CandidateInfo) -> bool:
    if candidate.REASON_FOR_DROP_OUT:
        return True
    if candidate.CURRENT_STATUS and "dropout" in candidate.CURRENT_STATUS.lower():
        return True
    return False


def compute_candidate_step(
    jobs: List[JobTracker],
    doc_trackers: List[DocumentTracker],
    candidate: CandidateInfo,
    required_doc_count: int,
) -> int:
    """
    Compute the current step (1-6) for a candidate.
    Returns 7 if all 6 steps are completed.

    Args:
        jobs: All JOB_TRACKER rows for this candidate
        doc_trackers: All active DOCUMENT_TRACKER rows for this candidate
        candidate: The CANDIDATE_INFO row
        required_doc_count: How many documents are required for this candidate type
    """
    # Step 1: Offer Released — always complete if candidate exists with an offer date
    if not candidate.OFFER_RELEASE_DATE:
        return 1

    # Step 2: Document Required Mail — JOB_TYPE_ID=1 with STATUS_ID=3 (Mail Sent)
    step2_done = any(
        j.JOB_TYPE_ID == settings.JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID
        and j.STATUS_ID == settings.STATUS_MAIL_SENT_ID
        for j in jobs
    )
    if not step2_done:
        return 2

    # Step 3: Follow-up Mail Drop — JOB_TYPE_ID=2 with STATUS_ID=3
    step3_done = any(
        j.JOB_TYPE_ID == settings.JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID
        and j.STATUS_ID == settings.STATUS_MAIL_SENT_ID
        for j in jobs
    )
    if not step3_done:
        return 3

    # Step 4: Document List — all required docs verified or completed
    if required_doc_count > 0:
        verified_count = sum(
            1 for d in doc_trackers
            if d.STATUS_ID in (settings.STATUS_VERIFIED_ID, settings.STATUS_COMPLETED_ID)
        )
        if verified_count < required_doc_count:
            return 4

    # Step 5: On-Boarding Mail — JOB_TYPE_ID=8 with STATUS_ID=3
    step5_done = any(
        j.JOB_TYPE_ID == settings.JOB_TYPE_ONBOARDING_MAIL_ID
        and j.STATUS_ID == settings.STATUS_MAIL_SENT_ID
        for j in jobs
    )
    if not step5_done:
        return 5

    # Step 6: IT-Admin Mail — JOB_TYPE_ID=9 with STATUS_ID=3
    step6_done = any(
        j.JOB_TYPE_ID == settings.JOB_TYPE_IT_ADMIN_MAIL_ID
        and j.STATUS_ID == settings.STATUS_MAIL_SENT_ID
        for j in jobs
    )
    if not step6_done:
        return 6

    return 7  # All steps completed


def _get_required_doc_count(db: Session, candidate_type_id: int) -> int:
    """Count how many documents are required for a candidate type."""
    col_name = CANDIDATE_TYPE_COLUMN_MAP.get(candidate_type_id, "EXPERIENCE")
    return db.query(DocumentTypeMaster).filter(
        DocumentTypeMaster.IS_ACTIVE == 1,
        getattr(DocumentTypeMaster, col_name) == 1,
    ).count()


def _get_candidate_type_label(candidate_type_id: int) -> str:
    return {1: "Fresher", 2: "Experience", 3: "Dev Partner"}.get(
        candidate_type_id, "Experience"
    )


def _classify_tab(step: int, candidate: CandidateInfo, has_any_job: bool) -> str:
    """Classify which dashboard tab a candidate belongs to."""
    if _is_dropout(candidate):
        return "dropout"
    if step == 7:
        return "completed"
    today = date.today()
    if (
        not has_any_job
        and candidate.EXPECTED_DOJ_WRT_TO_NP
        and candidate.EXPECTED_DOJ_WRT_TO_NP >= today
    ):
        return "upcoming"
    return "in_progress"


def get_dashboard_summary(db: Session) -> DashboardSummaryResponse:
    """Compute counts for all 4 dashboard tabs."""
    candidates = db.query(CandidateInfo).all()
    if not candidates:
        return DashboardSummaryResponse(
            upcoming_count=0, in_progress_count=0,
            completed_count=0, dropout_count=0,
        )

    candidate_ids = [c.CANDIDATE_ID for c in candidates]

    # Batch-fetch all jobs and doc trackers
    all_jobs = db.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID.in_(candidate_ids)
    ).all()
    all_docs = db.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID.in_(candidate_ids),
        DocumentTracker.IS_ACTIVE == 1,
    ).all()

    # Group by candidate
    jobs_by_cid = {}
    for j in all_jobs:
        jobs_by_cid.setdefault(j.CANDIDATE_ID, []).append(j)
    docs_by_cid = {}
    for d in all_docs:
        docs_by_cid.setdefault(d.CANDIDATE_ID, []).append(d)

    # Cache required doc counts per candidate type
    req_doc_cache = {}

    counts = {"upcoming": 0, "in_progress": 0, "completed": 0, "dropout": 0}

    for c in candidates:
        ctype = c.CANDIDATE_TYPE_ID or 2
        if ctype not in req_doc_cache:
            req_doc_cache[ctype] = _get_required_doc_count(db, ctype)

        cjobs = jobs_by_cid.get(c.CANDIDATE_ID, [])
        cdocs = docs_by_cid.get(c.CANDIDATE_ID, [])
        step = compute_candidate_step(cjobs, cdocs, c, req_doc_cache[ctype])
        tab = _classify_tab(step, c, len(cjobs) == 0)
        counts[tab] += 1

    return DashboardSummaryResponse(
        upcoming_count=counts["upcoming"],
        in_progress_count=counts["in_progress"],
        completed_count=counts["completed"],
        dropout_count=counts["dropout"],
    )


def get_candidates_for_tab(
    db: Session,
    tab: str,
    page: int = 1,
    page_size: int = 20,
    search: Optional[str] = None,
) -> PaginatedCandidateListResponse:
    """Fetch paginated candidate list for a specific dashboard tab."""

    # Base query
    query = db.query(CandidateInfo)
    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                CandidateInfo.CANDIDATE_NAME.ilike(search_pattern),
                CandidateInfo.CIN.ilike(search_pattern),
            )
        )

    candidates = query.all()
    if not candidates:
        return PaginatedCandidateListResponse(
            total=0, page=page, page_size=page_size, total_pages=0, items=[],
        )

    candidate_ids = [c.CANDIDATE_ID for c in candidates]

    # Batch-fetch jobs and doc trackers
    all_jobs = db.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID.in_(candidate_ids)
    ).all()
    all_docs = db.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID.in_(candidate_ids),
        DocumentTracker.IS_ACTIVE == 1,
    ).all()

    jobs_by_cid = {}
    for j in all_jobs:
        jobs_by_cid.setdefault(j.CANDIDATE_ID, []).append(j)
    docs_by_cid = {}
    for d in all_docs:
        docs_by_cid.setdefault(d.CANDIDATE_ID, []).append(d)

    req_doc_cache = {}

    # Classify and filter for the requested tab
    tab_candidates = []
    for c in candidates:
        ctype = c.CANDIDATE_TYPE_ID or 2
        if ctype not in req_doc_cache:
            req_doc_cache[ctype] = _get_required_doc_count(db, ctype)

        cjobs = jobs_by_cid.get(c.CANDIDATE_ID, [])
        cdocs = docs_by_cid.get(c.CANDIDATE_ID, [])
        step = compute_candidate_step(cjobs, cdocs, c, req_doc_cache[ctype])
        candidate_tab = _classify_tab(step, c, len(cjobs) == 0)

        if candidate_tab == tab:
            tab_candidates.append((c, step, ctype))

    total = len(tab_candidates)
    total_pages = math.ceil(total / page_size) if total > 0 else 0

    # Paginate
    start_idx = (page - 1) * page_size
    end_idx = start_idx + page_size
    page_slice = tab_candidates[start_idx:end_idx]

    items = []
    for c, step, ctype in page_slice:
        items.append(CandidateHubRow(
            candidate_id=c.CANDIDATE_ID,
            cin=c.CIN or "",
            name=c.CANDIDATE_NAME or c.CIN or "",
            address=c.CURRENT_RESIDENTIAL_ADDRESS,
            employee_type=_get_candidate_type_label(ctype),
            date=str(c.EXPECTED_DOJ_WRT_TO_NP) if c.EXPECTED_DOJ_WRT_TO_NP else None,
            current_step=step if step <= 6 else 6,
            current_step_label=get_step_label(step) if step <= 6 else "Completed",
            candidate_type_id=ctype,
            email=c.PERSONAL_EMAIL_ID,
            designation=c.DESIGNATION_TO_BE_PRINTED_ON_THE_OFFER_LETTER,
        ))

    return PaginatedCandidateListResponse(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        items=items,
    )
