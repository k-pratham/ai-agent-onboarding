from pydantic import BaseModel
from typing import Optional


class MailDraftResponse(BaseModel):
    candidate_id: int
    cin: str
    step: int
    job_id: Optional[int] = None
    to: str
    cc: Optional[str] = None
    subject: str
    body: str
    is_editable: bool = True


class SendMailRequest(BaseModel):
    step: int
    job_id: Optional[int] = None
    to: str
    cc: Optional[str] = None
    subject: str
    body: str


class SendMailResponse(BaseModel):
    success: bool
    message: str
    job_id: int
