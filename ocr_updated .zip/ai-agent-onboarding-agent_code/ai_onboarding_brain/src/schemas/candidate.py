from pydantic import BaseModel
from typing import Optional, List


class CandidateDetailResponse(BaseModel):
    candidate_id: int
    cin: str
    name: str
    email: Optional[str] = None
    contact_number: Optional[str] = None
    address: Optional[str] = None
    employee_type: str
    candidate_type_id: int
    designation: Optional[str] = None
    technology: Optional[str] = None
    grade: Optional[str] = None
    bu: Optional[str] = None
    vertical: Optional[str] = None
    reporting_location: Optional[str] = None
    work_base_location: Optional[str] = None
    offer_release_date: Optional[str] = None
    expected_doj: Optional[str] = None
    previous_experience: Optional[str] = None
    recruiter_name: Optional[str] = None
    po_name: Optional[str] = None
    manager_name: Optional[str] = None
    buddy: Optional[str] = None
    current_status: Optional[str] = None
    reason_for_dropout: Optional[str] = None


class StepDetail(BaseModel):
    step_number: int
    label: str
    status: str  # "completed" | "in_progress" | "pending"
    completed_at: Optional[str] = None
    job_id: Optional[int] = None
    has_draft: bool


class StepperResponse(BaseModel):
    candidate_id: int
    cin: str
    current_step: int
    steps: List[StepDetail]


class MarkDropoutRequest(BaseModel):
    reason: Optional[str] = None
