from pydantic import BaseModel
from typing import Optional


class GenericActionResponse(BaseModel):
    success: bool
    message: str
