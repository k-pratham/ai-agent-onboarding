from pydantic import BaseModel
from typing import Optional, List


class DocumentRow(BaseModel):
    document_tracker_id: int
    document_type_id: int
    document_name: str
    status: str
    status_id: int
    submitted: bool
    received_on: Optional[str] = None
    comments: Optional[str] = None
    is_active: bool


class CandidateDocumentListResponse(BaseModel):
    candidate_id: int
    cin: str
    candidate_name: str
    candidate_type: str
    documents: List[DocumentRow]


class DocumentActionRequest(BaseModel):
    comments: Optional[str] = None


class DocumentRejectRequest(BaseModel):
    rejection_reason: str


class BulkDocumentActionRequest(BaseModel):
    action: str  # "approve" | "reject"
    document_tracker_ids: List[int]
    rejection_reason: Optional[str] = None


class DocumentActionResult(BaseModel):
    document_tracker_id: int
    status: str
    message: str


class BulkDocumentActionResponse(BaseModel):
    success: bool
    results: List[DocumentActionResult]
