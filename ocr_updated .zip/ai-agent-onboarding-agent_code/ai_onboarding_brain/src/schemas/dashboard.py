from pydantic import BaseModel
from typing import Optional, List


class DashboardSummaryResponse(BaseModel):
    upcoming_count: int
    in_progress_count: int
    completed_count: int
    dropout_count: int


class CandidateHubRow(BaseModel):
    candidate_id: int
    cin: str
    name: str
    address: Optional[str] = None
    employee_type: str
    date: Optional[str] = None
    current_step: int
    current_step_label: str
    candidate_type_id: int
    email: Optional[str] = None
    designation: Optional[str] = None


class PaginatedCandidateListResponse(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    items: List[CandidateHubRow]
