from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from typing import List
from ai_onboarding_brain.src.schemas.job import DraftApprovalRequest, PendingDraftResponse
from ai_onboarding_brain.src.services.hr_service import process_draft_approval
from ai_onboarding_brain.src.services.escalation_service import (
    check_and_send_escalation,
    send_summary_and_joining_mail,
)
from ai_onboarding_brain.src.core.database import get_db
from ai_onboarding_brain.src.core.config import settings, get_logger
from ai_onboarding_brain.src.core.exceptions import (
    AppBaseException, CandidateNotFoundError, DatabaseTransactionError,
)
from etl_pipeline.models.schema import JobTracker, CandidateInfo, DocumentTracker

# Import new sub-routers
from ai_onboarding_brain.src.routes.dashboard import router as dashboard_router
from ai_onboarding_brain.src.routes.candidates import router as candidates_router
from ai_onboarding_brain.src.routes.documents import router as documents_router
from ai_onboarding_brain.src.routes.mail import router as mail_router

logger = get_logger(__name__)
router = APIRouter()

# Mount new sub-routers (they share the same /api/v1 prefix via main.py)
router.include_router(dashboard_router, tags=["Dashboard"])
router.include_router(candidates_router, tags=["Candidates"])
router.include_router(documents_router, tags=["Documents"])
router.include_router(mail_router, tags=["Mail"])


@router.get("/dashboard/pending-drafts", response_model=List[PendingDraftResponse])
async def get_pending_drafts(db: Session = Depends(get_db)):
    """
    Fetches draft emails waiting on human HR approval from the JobTracker.
    """
    try:
        pending_jobs = db.query(JobTracker, CandidateInfo).join(
            CandidateInfo, JobTracker.CANDIDATE_ID == CandidateInfo.CANDIDATE_ID
        ).filter(
            JobTracker.STATUS_ID.in_([settings.STATUS_PENDING_ID, settings.STATUS_MAIL_DRAFTED_ID]),
            JobTracker.HUMAN_ACTION_REQUIRED == 1,
            JobTracker.JOB_TYPE_ID.in_([
                settings.JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
                settings.JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
                settings.JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID,
            ]),
        ).all()

        results = []
        for job, candidate in pending_jobs:
            results.append(PendingDraftResponse(
                job_id=job.JOB_ID,
                candidate=candidate.CANDIDATE_NAME or candidate.CIN,
                cin=candidate.CIN,
                draft=job.DRAFT_MAIL or "",
            ))

        return results
    except Exception as e:
        logger.error(f"Failed to query pending drafts: {e}")
        raise HTTPException(status_code=500, detail="Database query failed")


@router.post("/action/approve-draft")
async def approve_draft(request: DraftApprovalRequest, db: Session = Depends(get_db)):
    """
    HR approves a generated draft and initiates email dispatch.
    Also inserts required documents into DOCUMENT_TRACKER after initial mail is sent.
    """
    try:
        response = await process_draft_approval(
            db,
            request.job_id,
            request.candidate_email,
            request.subject,
            request.approved_content,
        )
        return response
    except CandidateNotFoundError as e:
        logger.warning(f"Draft approval - candidate not found: {e}")
        raise HTTPException(status_code=404, detail=str(e))
    except DatabaseTransactionError as e:
        logger.error(f"Draft approval - DB transaction failed: {e}")
        raise HTTPException(status_code=500, detail="Database transaction failed.")
    except AppBaseException as e:
        logger.warning(f"Draft approval - business logic failure: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Draft approval failed: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to dispatch draft: {str(e)}")


@router.post("/action/check-escalation/{candidate_id}")
async def check_escalation(candidate_id: int, db: Session = Depends(get_db)):
    """
    Checks if a candidate needs escalation (2+ failed follow-ups)
    and creates an escalation draft if needed.
    """
    try:
        result = check_and_send_escalation(db, candidate_id)
        db.commit()
        return result
    except CandidateNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        db.rollback()
        logger.error(f"Escalation check failed for candidate {candidate_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/action/complete-onboarding/{candidate_id}")
async def complete_onboarding(candidate_id: int, db: Session = Depends(get_db)):
    """
    Triggered when all documents for a candidate are verified.
    Creates summary mail to HR and joining mail to candidate.
    """
    try:
        result = send_summary_and_joining_mail(db, candidate_id)
        db.commit()
        return result
    except CandidateNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        db.rollback()
        logger.error(f"Onboarding completion failed for candidate {candidate_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/dashboard/candidate-status/{cin}")
async def get_candidate_status(cin: str, db: Session = Depends(get_db)):
    """
    Returns the full document status for a specific candidate.
    Used by the HR UI to show which documents are received, pending, rejected, etc.
    """
    try:
        candidate = db.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()
        if not candidate:
            raise HTTPException(status_code=404, detail=f"Candidate CIN {cin} not found.")

        docs = db.query(DocumentTracker).filter(
            DocumentTracker.CANDIDATE_ID == candidate.CANDIDATE_ID,
            DocumentTracker.IS_ACTIVE == 1,
        ).all()

        status_map = {1: "Pending", 2: "Mail Drafted", 3: "Mail Sent",
                      4: "Mail Received", 5: "Verified", 6: "Rejected", 7: "Completed"}

        doc_statuses = []
        for doc in docs:
            doc_statuses.append({
                "tracker_id": doc.DOCUMENT_TRACKER_ID,
                "document_type_id": doc.DOCUMENT_TYPE_ID,
                "status": status_map.get(doc.STATUS_ID, "Unknown"),
                "status_id": doc.STATUS_ID,
                "comments": doc.COMMENTS,
                "received_on": str(doc.DOCUMENT_RECIVED_ON) if doc.DOCUMENT_RECIVED_ON else None,
            })

        return {
            "cin": cin,
            "candidate_name": candidate.CANDIDATE_NAME,
            "candidate_id": candidate.CANDIDATE_ID,
            "documents": doc_statuses,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get candidate status for CIN {cin}: {e}")
        raise HTTPException(status_code=500, detail=str(e))
