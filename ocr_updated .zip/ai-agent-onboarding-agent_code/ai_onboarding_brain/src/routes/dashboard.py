from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from ai_onboarding_brain.src.core.database import get_db
from ai_onboarding_brain.src.core.config import get_logger
from ai_onboarding_brain.src.schemas.dashboard import (
    DashboardSummaryResponse,
    PaginatedCandidateListResponse,
)
from ai_onboarding_brain.src.services.dashboard_service import (
    get_dashboard_summary,
    get_candidates_for_tab,
)

logger = get_logger(__name__)
router = APIRouter()

VALID_TABS = {"upcoming", "in_progress", "completed", "dropout"}


@router.get("/dashboard/summary", response_model=DashboardSummaryResponse)
async def dashboard_summary(db: Session = Depends(get_db)):
    """Returns counts for all 4 dashboard tabs: upcoming, in_progress, completed, dropout."""
    try:
        return get_dashboard_summary(db)
    except Exception as e:
        logger.error(f"Dashboard summary failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to load dashboard summary")


@router.get("/dashboard/candidates", response_model=PaginatedCandidateListResponse)
async def dashboard_candidates(
    tab: str = Query(..., description="Dashboard tab: upcoming, in_progress, completed, dropout"),
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    search: Optional[str] = Query(None, description="Search by candidate name or CIN"),
    db: Session = Depends(get_db),
):
    """Returns a paginated list of candidates for the specified dashboard tab."""
    if tab not in VALID_TABS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid tab '{tab}'. Must be one of: {', '.join(sorted(VALID_TABS))}",
        )
    try:
        return get_candidates_for_tab(db, tab, page, page_size, search)
    except Exception as e:
        logger.error(f"Dashboard candidates failed for tab={tab}: {e}")
        raise HTTPException(status_code=500, detail="Failed to load candidate list")
