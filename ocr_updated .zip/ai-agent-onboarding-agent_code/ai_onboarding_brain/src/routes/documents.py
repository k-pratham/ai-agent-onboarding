from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session

from ai_onboarding_brain.src.core.database import get_db
from ai_onboarding_brain.src.core.config import get_logger
from ai_onboarding_brain.src.core.exceptions import CandidateNotFoundError
from ai_onboarding_brain.src.schemas.document import (
    CandidateDocumentListResponse,
    DocumentActionRequest,
    DocumentRejectRequest,
    BulkDocumentActionRequest,
    BulkDocumentActionResponse,
)
from ai_onboarding_brain.src.services.document_service import (
    get_candidate_documents,
    approve_document,
    reject_document,
    bulk_document_action,
)

logger = get_logger(__name__)
router = APIRouter()


@router.get(
    "/candidates/{candidate_id}/documents",
    response_model=CandidateDocumentListResponse,
)
async def list_candidate_documents(candidate_id: int, db: Session = Depends(get_db)):
    """Returns all tracked documents for a candidate with their current status."""
    try:
        return get_candidate_documents(db, candidate_id)
    except CandidateNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to list documents for candidate {candidate_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to load document list")


@router.post("/documents/{document_tracker_id}/approve")
async def approve_single_document(
    document_tracker_id: int,
    request: DocumentActionRequest,
    db: Session = Depends(get_db),
):
    """HR approves a single document. Sets status to Verified (5)."""
    try:
        return approve_document(db, document_tracker_id, request.comments)
    except CandidateNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to approve document {document_tracker_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to approve document")


@router.post("/documents/{document_tracker_id}/reject")
async def reject_single_document(
    document_tracker_id: int,
    request: DocumentRejectRequest,
    db: Session = Depends(get_db),
):
    """HR rejects a single document with a reason. Sets status to Rejected (6)."""
    try:
        return reject_document(db, document_tracker_id, request.rejection_reason)
    except CandidateNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to reject document {document_tracker_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to reject document")


@router.post(
    "/candidates/{candidate_id}/documents/bulk-action",
    response_model=BulkDocumentActionResponse,
)
async def bulk_document_action_endpoint(
    candidate_id: int,
    request: BulkDocumentActionRequest,
    db: Session = Depends(get_db),
):
    """Bulk approve or reject multiple documents for a candidate."""
    try:
        return bulk_document_action(db, candidate_id, request)
    except Exception as e:
        db.rollback()
        logger.error(f"Bulk document action failed for candidate {candidate_id}: {e}")
        raise HTTPException(status_code=500, detail="Bulk action failed")
