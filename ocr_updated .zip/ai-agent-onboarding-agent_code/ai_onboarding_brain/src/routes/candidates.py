import datetime
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session

from ai_onboarding_brain.src.core.database import get_db
from ai_onboarding_brain.src.core.config import settings, get_logger
from ai_onboarding_brain.src.schemas.candidate import (
    CandidateDetailResponse,
    StepperResponse,
    StepDetail,
    MarkDropoutRequest,
)
from ai_onboarding_brain.src.schemas.common import GenericActionResponse
from etl_pipeline.models.schema import (
    CandidateInfo, CandidateTypeMaster, JobTracker,
    DocumentTracker, DocumentTypeMaster,
)
from ai_onboarding_brain.src.services.dashboard_service import (
    compute_candidate_step, get_step_label, _get_required_doc_count,
    STEP_LABELS, _STEP_JOB_TYPE_MAP,
)
from constants.constants import CANDIDATE_TYPE_COLUMN_MAP

logger = get_logger(__name__)
router = APIRouter()


def _get_candidate_type_label(candidate_type_id: int) -> str:
    return {1: "Fresher", 2: "Experience", 3: "Dev Partner"}.get(
        candidate_type_id, "Experience"
    )


@router.get("/candidates/{candidate_id}", response_model=CandidateDetailResponse)
async def get_candidate_detail(candidate_id: int, db: Session = Depends(get_db)):
    """Returns full detail for a single candidate."""
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found")

    ctype = candidate.CANDIDATE_TYPE_ID or 2
    return CandidateDetailResponse(
        candidate_id=candidate.CANDIDATE_ID,
        cin=candidate.CIN or "",
        name=candidate.CANDIDATE_NAME or candidate.CIN or "",
        email=candidate.PERSONAL_EMAIL_ID,
        contact_number=candidate.CONTACT_NUMBER,
        address=candidate.CURRENT_RESIDENTIAL_ADDRESS,
        employee_type=_get_candidate_type_label(ctype),
        candidate_type_id=ctype,
        designation=candidate.DESIGNATION_TO_BE_PRINTED_ON_THE_OFFER_LETTER,
        technology=candidate.TECHNOLOGY,
        grade=candidate.GRADE,
        bu=candidate.BU,
        vertical=candidate.VERTICAL,
        reporting_location=candidate.REPORTING_LOCATION,
        work_base_location=candidate.WORK_BASE_LOCATION,
        offer_release_date=str(candidate.OFFER_RELEASE_DATE) if candidate.OFFER_RELEASE_DATE else None,
        expected_doj=str(candidate.EXPECTED_DOJ_WRT_TO_NP) if candidate.EXPECTED_DOJ_WRT_TO_NP else None,
        previous_experience=candidate.PREVIOUS_EXPERIENCE,
        recruiter_name=candidate.RECRUITER_NAME,
        po_name=candidate.PO_NAME,
        manager_name=candidate.MANAGER_NAME,
        buddy=candidate.BUDDY,
        current_status=candidate.CURRENT_STATUS,
        reason_for_dropout=candidate.REASON_FOR_DROP_OUT,
    )


@router.get("/candidates/{candidate_id}/stepper", response_model=StepperResponse)
async def get_candidate_stepper(candidate_id: int, db: Session = Depends(get_db)):
    """Returns the 6-step stepper state for a candidate, derived from DB data."""
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found")

    ctype = candidate.CANDIDATE_TYPE_ID or 2
    required_doc_count = _get_required_doc_count(db, ctype)

    jobs = db.query(JobTracker).filter(
        JobTracker.CANDIDATE_ID == candidate_id
    ).order_by(JobTracker.JOB_ID).all()

    doc_trackers = db.query(DocumentTracker).filter(
        DocumentTracker.CANDIDATE_ID == candidate_id,
        DocumentTracker.IS_ACTIVE == 1,
    ).all()

    current_step = compute_candidate_step(jobs, doc_trackers, candidate, required_doc_count)

    # Build the 6-step list
    steps = []
    for step_num in range(1, 7):
        label = get_step_label(step_num)

        if step_num < current_step:
            status = "completed"
        elif step_num == current_step:
            status = "in_progress"
        else:
            status = "pending"

        completed_at = None
        job_id = None
        has_draft = False

        if step_num == 1:
            # Offer Released — completed_at is OFFER_RELEASE_DATE
            if candidate.OFFER_RELEASE_DATE:
                completed_at = str(candidate.OFFER_RELEASE_DATE)
        elif step_num in _STEP_JOB_TYPE_MAP:
            # Steps 2, 3, 5, 6 — find matching JOB_TRACKER row
            target_type = _STEP_JOB_TYPE_MAP[step_num]
            matching_jobs = [j for j in jobs if j.JOB_TYPE_ID == target_type]
            if matching_jobs:
                # Use the most recent matching job
                best = matching_jobs[-1]
                job_id = best.JOB_ID
                has_draft = bool(best.DRAFT_MAIL)
                if best.STATUS_ID == settings.STATUS_MAIL_SENT_ID:
                    completed_at = str(best.UPDATED_ON) if best.UPDATED_ON else None
        elif step_num == 4:
            # Document List — no single job, check doc tracker status
            if required_doc_count > 0:
                verified_count = sum(
                    1 for d in doc_trackers
                    if d.STATUS_ID in (settings.STATUS_VERIFIED_ID, settings.STATUS_COMPLETED_ID)
                )
                if verified_count >= required_doc_count:
                    # All docs verified — find the latest update date
                    dates = [
                        d.UPDATED_ON for d in doc_trackers
                        if d.STATUS_ID in (settings.STATUS_VERIFIED_ID, settings.STATUS_COMPLETED_ID)
                        and d.UPDATED_ON
                    ]
                    if dates:
                        completed_at = str(max(dates))

        steps.append(StepDetail(
            step_number=step_num,
            label=label,
            status=status,
            completed_at=completed_at,
            job_id=job_id,
            has_draft=has_draft,
        ))

    return StepperResponse(
        candidate_id=candidate.CANDIDATE_ID,
        cin=candidate.CIN or "",
        current_step=current_step if current_step <= 6 else 6,
        steps=steps,
    )


@router.post("/candidates/{candidate_id}/dropout", response_model=GenericActionResponse)
async def mark_candidate_dropout(
    candidate_id: int,
    request: MarkDropoutRequest,
    db: Session = Depends(get_db),
):
    """Mark a candidate as dropout with an optional reason."""
    candidate = db.query(CandidateInfo).filter(
        CandidateInfo.CANDIDATE_ID == candidate_id
    ).first()
    if not candidate:
        raise HTTPException(status_code=404, detail=f"Candidate {candidate_id} not found")

    candidate.CURRENT_STATUS = "Dropout"
    candidate.REASON_FOR_DROP_OUT = request.reason or "Marked as dropout by HR"
    candidate.UPDATED_ON = datetime.date.today()

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to mark candidate {candidate_id} as dropout: {e}")
        raise HTTPException(status_code=500, detail="Failed to update candidate status")

    return GenericActionResponse(
        success=True,
        message="Candidate marked as dropout successfully",
    )
