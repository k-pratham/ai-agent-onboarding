from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session

from ai_onboarding_brain.src.core.database import get_db
from ai_onboarding_brain.src.core.config import get_logger
from ai_onboarding_brain.src.core.exceptions import CandidateNotFoundError, ToolExecutionError
from ai_onboarding_brain.src.schemas.mail import (
    MailDraftResponse,
    SendMailRequest,
    SendMailResponse,
)
from ai_onboarding_brain.src.services.mail_service import (
    get_mail_draft,
    send_mail,
)

logger = get_logger(__name__)
router = APIRouter()

VALID_MAIL_STEPS = {2, 3, 5, 6}


@router.get(
    "/candidates/{candidate_id}/mail/draft",
    response_model=MailDraftResponse,
)
async def get_candidate_mail_draft(
    candidate_id: int,
    step: int = Query(..., description="Stepper step: 2, 3, 5, or 6"),
    regenerate: bool = Query(False, description="Force regenerate draft via LLM/template"),
    db: Session = Depends(get_db),
):
    """
    Get or generate a mail draft for a specific stepper step.
    Returns pre-filled to, cc, subject, body for the compose form.
    """
    if step not in VALID_MAIL_STEPS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid step {step}. Must be one of: {sorted(VALID_MAIL_STEPS)}",
        )
    try:
        return get_mail_draft(db, candidate_id, step, regenerate)
    except CandidateNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Failed to get mail draft for candidate {candidate_id} step {step}: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate mail draft")


@router.post(
    "/candidates/{candidate_id}/mail/send",
    response_model=SendMailResponse,
)
async def send_candidate_mail(
    candidate_id: int,
    request: SendMailRequest,
    db: Session = Depends(get_db),
):
    """
    Send a composed mail. Updates/creates JOB_TRACKER, dispatches email,
    and handles post-send actions (document tracker insert, follow-up job creation).
    """
    if request.step not in VALID_MAIL_STEPS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid step {request.step}. Must be one of: {sorted(VALID_MAIL_STEPS)}",
        )
    try:
        return await send_mail(db, candidate_id, request)
    except CandidateNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ToolExecutionError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to send mail for candidate {candidate_id} step {request.step}: {e}")
        raise HTTPException(status_code=500, detail="Failed to send email")
