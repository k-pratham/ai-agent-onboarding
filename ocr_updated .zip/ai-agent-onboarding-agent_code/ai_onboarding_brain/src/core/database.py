from constants.database import (  # noqa: F401
    _get_engine,
    _get_session,
    _ensure_session_local,
    get_db,
)

# Backward-compatible SessionLocal — lazily initialised
_SessionLocal = None


def _lazy_session_local():
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = _ensure_session_local()
    return _SessionLocal


class _SessionLocalProxy:
    """Proxy so that ``SessionLocal()`` works as before."""
    def __call__(self):
        return _lazy_session_local()()

SessionLocal = _SessionLocalProxy()
