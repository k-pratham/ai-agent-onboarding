import os
import sys
from datetime import date

# Add project root to sys.path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from constants.common_functions import get_db_uri
from etl_pipeline.models.schema import (
    StatusMaster, JobTypeMaster, DocumentTypeMaster, CandidateTypeMaster, MailTypeMaster, Base,
)

DB_URI = get_db_uri()


def seed_data():
    engine = create_engine(DB_URI)

    # Ensure tables exist
    Base.metadata.create_all(engine)

    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        # Seed Status Master
        statuses = [
            (1, "Pending"),
            (2, "Mail Drafted"),
            (3, "Mail Sent"),
            (4, "Mail Received"),
            (5, "Verified"),
            (6, "Rejected"),
            (7, "Completed"),
        ]

        for status_id, status_type in statuses:
            if not session.query(StatusMaster).filter_by(STATUS_ID=status_id).first():
                session.add(StatusMaster(STATUS_ID=status_id, STATUS_TYPE=status_type, IS_ACTIVE=1))

        # Seed Candidate Type Master
        candidate_types = [
            (1, "Fresher", "Candidate with no prior work experience"),
            (2, "Experience", "Candidate with prior work experience"),
            (3, "Dev Partner", "Development partner or contractor"),
        ]

        for type_id, type_name, description in candidate_types:
            if not session.query(CandidateTypeMaster).filter_by(CANDIDATE_TYPE_ID=type_id).first():
                session.add(CandidateTypeMaster(
                    CANDIDATE_TYPE_ID=type_id,
                    CANDIDATE_TYPE=type_name,
                    CANDIDATE_TYPE_DESCRIPTION=description,
                    CREATED_ON=date.today(),
                    UPDATED_ON=date.today(),
                    IS_ACTIVE=1,
                ))

        # Seed Job Type Master (9 job types)
        job_types = [
            (1, "mail_send", "documents_required", "Initial mail requesting onboarding documents"),
            (2, "mail_send", "follow_up", "Follow-up mail when candidate hasn't replied"),
            (3, "mail_send", "pending_documents", "Follow-up mail for pending docs after partial submission"),
            (4, "mail_read", "read_received_emails", "Read received emails from candidates"),
            (5, "doc_save", "save_in_shared_path", "Save candidate attachments in shared path"),
            (6, "gap_analysis", "document_validation", "Gap analysis and document validation"),
            (7, "attachments_saved", "", "Candidate attachments saved for processing"),
            (8, "mail_send", "onboarding_welcome", "Onboarding welcome and joining confirmation email"),
            (9, "mail_send", "it_provisioning", "IT admin provisioning request email"),
        ]

        for job_id, job_type, job_subtype, desc in job_types:
            if not session.query(JobTypeMaster).filter_by(JOB_TYPE_ID=job_id).first():
                session.add(JobTypeMaster(
                    JOB_TYPE_ID=job_id,
                    JOB_TYPE=job_type,
                    JOB_SUBTYPE=job_subtype,
                    JOB_DESCRIPTION=desc,
                    CREATED_ON=date.today(),
                    UPDATED_ON=date.today(),
                    IS_ACTIVE=1,
                ))

        # Seed Document Type Master
        # Columns: (ID, Name, Fresher, Experience, DevPartner)
        document_types = [
            (1, "Aadhaar Card", 1, 1, 1),
            (2, "PAN Card", 1, 1, 1),
            (3, "10th Marksheet", 1, 1, 1),
            (4, "12th Marksheet", 1, 1, 1),
            (5, "Degree Certificate", 1, 1, 0),
            (6, "Experience Letter", 0, 1, 1),
            (7, "Relieving Letter", 0, 1, 1),
            (8, "Salary Slips", 0, 1, 0),
        ]

        for doc_id, doc_name, fresher, exp, dev in document_types:
            if not session.query(DocumentTypeMaster).filter_by(DOCUMENT_TYPE_ID=doc_id).first():
                session.add(DocumentTypeMaster(
                    DOCUMENT_TYPE_ID=doc_id,
                    DOCUMENT_NAME=doc_name,
                    FRESHER=fresher,
                    EXPERIENCE=exp,
                    DEV_PARTNER=dev,
                    CREATED_ON=date.today(),
                    UPDATED_ON=date.today(),
                    IS_ACTIVE=1,
                ))

        # Seed Mail Type Master
        mail_types = [
            (
                1,
                "initial_documents",
                "Dear [Candidate Name],\n\n"
                "Welcome to our onboarding process! As part of the joining formalities, "
                "we require the following documents from you:\n\n[Document List]\n\n"
                "Please reply to this email with the documents attached. "
                "Include your CIN ([CIN]) in the subject line for tracking.\n\n"
                "Note: The email attachment size limit is 10 MB per email. "
                "You may send multiple emails if needed.\n\n"
                "Regards,\nHR Onboarding Team",
            ),
            (
                2,
                "followup_documents",
                "Dear [Candidate Name],\n\n"
                "This is a follow-up regarding your pending onboarding documents. "
                "We have not yet received the following required documents:\n\n[Document List]\n\n"
                "Please submit these at your earliest convenience to avoid delays "
                "in your joining process.\n\n"
                "Reply to this email with the documents attached. "
                "Include your CIN ([CIN]) in the subject line.\n\n"
                "Regards,\nHR Onboarding Team",
            ),
            (
                3,
                "escalation",
                "ESCALATION NOTICE\n\n"
                "Candidate [Candidate Name] (CIN: [CIN]) has not responded to "
                "multiple follow-up requests. Missing documents:\n[Document List]\n\n"
                "Please review and take appropriate action.\n\n"
                "HR Automation System",
            ),
        ]

        for mail_id, mail_type, mail_desc in mail_types:
            if not session.query(MailTypeMaster).filter_by(MAIL_TYPE_ID=mail_id).first():
                session.add(MailTypeMaster(
                    MAIL_TYPE_ID=mail_id,
                    MAIL_TYPE=mail_type,
                    MAIL_DESCRIPTION=mail_desc,
                    CREATED_ON=date.today(),
                    UPDATED_ON=date.today(),
                    IS_ACTIVE=1,
                ))

        session.commit()
        print("Successfully seeded all master data:")
        print(f"  - {len(statuses)} status types")
        print(f"  - {len(candidate_types)} candidate types")
        print(f"  - {len(job_types)} job types")
        print(f"  - {len(document_types)} document types")
        print(f"  - {len(mail_types)} mail types")
    except Exception as e:
        session.rollback()
        print(f"Error seeding data: {e}")
    finally:
        session.close()


if __name__ == "__main__":
    seed_data()
