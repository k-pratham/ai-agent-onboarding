import pandas as pd
from datetime import datetime, date, timedelta
from etl_pipeline.models.schema import CandidateInfo, JobTracker
from etl_pipeline.transform.schema_mapper import map_row_to_candidate_dict
from constants.constants import JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID, STATUS_PENDING_ID
from sqlalchemy.orm import Session
import logging

logger = logging.getLogger(__name__)

DAYS_BEFORE_DOJ_THRESHOLD = 60


def _compute_action_date(expected_doj) -> date:
    """
    Computes the ACTION_DATE for the initial mail-send job.
    Rule: start sending mail to candidates whose joining is within 60 days.
    If today is already within the 60-day window, action_date = tomorrow.
    Otherwise action_date = expected_doj - 60 days.
    """
    today = date.today()

    if expected_doj is None:
        return today + timedelta(days=1)

    if isinstance(expected_doj, datetime):
        expected_doj = expected_doj.date()

    if not isinstance(expected_doj, date):
        return today + timedelta(days=1)

    sixty_days_before = expected_doj - timedelta(days=DAYS_BEFORE_DOJ_THRESHOLD)

    if today >= sixty_days_before:
        # Already within the 60-day window, schedule for next day
        return today + timedelta(days=1)
    else:
        return sixty_days_before


def load_data(session: Session, transformed_df: pd.DataFrame):
    """
    Loads transformed candidate data into CANDIDATE_INFO and creates initial jobs.
    Implements full column mapping and the 60-day ACTION_DATE rule.
    """
    now = datetime.now()
    today = date.today()
    new_candidates_count = 0
    updated_candidates_count = 0

    for _, row in transformed_df.iterrows():
        row_hash = row.get("ROW_HASH")
        cin = row.get("CIN")

        # Check if record exists based on ROW_HASH (no change needed)
        existing_by_hash = session.query(CandidateInfo).filter_by(ROW_HASH=row_hash).first()
        if existing_by_hash:
            continue

        # Map full row data from Excel columns to DB columns
        row_dict = row.to_dict()
        mapped_data = map_row_to_candidate_dict(row_dict)

        # Check if candidate exists by CIN but has an updated hash
        candidate = session.query(CandidateInfo).filter_by(CIN=cin).first()

        if candidate:
            # Update existing candidate with all mapped columns
            for col_name, value in mapped_data.items():
                if col_name == "CIN":
                    continue
                if pd.notna(value):
                    setattr(candidate, col_name, value)
            candidate.ROW_HASH = row_hash
            candidate.UPDATED_ON = now
            updated_candidates_count += 1
        else:
            # New Candidate - create with all mapped columns
            new_candidate = CandidateInfo(
                ROW_HASH=row_hash,
                CREATED_ON=now,
                UPDATED_ON=now,
            )
            for col_name, value in mapped_data.items():
                if pd.notna(value):
                    setattr(new_candidate, col_name, value)

            session.add(new_candidate)
            session.flush()  # Flush to get CANDIDATE_ID

            # Compute ACTION_DATE based on EXPECTED_DOJ_WRT_TO_NP
            expected_doj = new_candidate.EXPECTED_DOJ_WRT_TO_NP
            action_date = _compute_action_date(expected_doj)

            # Create initial Job entry: mail sent / documents required
            new_job = JobTracker(
                JOB_TYPE_ID=JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
                START_TIME=now,
                CANDIDATE_ID=new_candidate.CANDIDATE_ID,
                STATUS_ID=STATUS_PENDING_ID,
                HUMAN_ACTION_REQUIRED=1,
                ACTION_DATE=action_date,
                UPDATED_ON=now,
            )
            session.add(new_job)
            new_candidates_count += 1

    session.commit()
    logger.info(f"Load complete. New: {new_candidates_count}, Updated: {updated_candidates_count}")
