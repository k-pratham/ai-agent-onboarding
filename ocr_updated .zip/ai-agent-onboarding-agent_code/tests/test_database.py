"""Tests for constants/database.py — shared database layer."""

from datetime import date, timedelta
from unittest.mock import MagicMock, patch

import pytest


class TestGetCandidateByCin:
    def test_returns_candidate_when_found(self, mock_db_session, sample_candidate):
        candidate = sample_candidate(cin="20240115_REF001")
        mock_db_session.query.return_value.filter.return_value.first.return_value = candidate

        from constants.database import get_candidate_by_cin
        result = get_candidate_by_cin(mock_db_session, "20240115_REF001")

        assert result is candidate
        assert result.CIN == "20240115_REF001"

    def test_returns_none_when_not_found(self, mock_db_session):
        mock_db_session.query.return_value.filter.return_value.first.return_value = None

        from constants.database import get_candidate_by_cin
        result = get_candidate_by_cin(mock_db_session, "NONEXISTENT")

        assert result is None


class TestCreateFollowupJob:
    def test_creates_job_with_correct_fields(self, mock_db_session):
        from constants.database import create_followup_job
        from constants.constants import STATUS_PENDING_ID, JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID

        job = create_followup_job(
            mock_db_session,
            candidate_id=42,
            job_type_id=JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
            days_offset=3,
        )

        # Verify session.add was called
        mock_db_session.add.assert_called_once()
        added_job = mock_db_session.add.call_args[0][0]
        assert added_job.CANDIDATE_ID == 42
        assert added_job.JOB_TYPE_ID == JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID
        assert added_job.STATUS_ID == STATUS_PENDING_ID
        assert added_job.ACTION_DATE == date.today() + timedelta(days=3)

    def test_default_offset_is_two_days(self, mock_db_session):
        from constants.database import create_followup_job

        create_followup_job(mock_db_session, candidate_id=1, job_type_id=2)

        added_job = mock_db_session.add.call_args[0][0]
        assert added_job.ACTION_DATE == date.today() + timedelta(days=2)
