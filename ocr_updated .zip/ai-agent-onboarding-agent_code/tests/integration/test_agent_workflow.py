"""Integration tests for the LangGraph agent workflow."""

from unittest.mock import MagicMock, patch

import pytest


class TestAgentGraph:
    """Verify the StateGraph structure and compilation."""

    def test_workflow_has_agent_and_tools_nodes(self):
        from ai_onboarding_brain.src.core.agent import workflow
        assert "agent" in workflow.nodes
        assert "tools" in workflow.nodes

    def test_get_compiled_orchestrator_returns_compiled_graph(self):
        from ai_onboarding_brain.src.core.agent import get_compiled_orchestrator

        mock_db = MagicMock()
        graph = get_compiled_orchestrator(mock_db)
        assert graph is not None

    def test_agent_state_has_messages_key(self):
        from ai_onboarding_brain.src.core.agent import AgentState
        assert "messages" in AgentState.__annotations__


class TestRouteCondition:
    def test_routes_to_tools_when_tool_calls_present(self):
        from ai_onboarding_brain.src.core.agent import route_condition
        from langgraph.graph import END

        msg = MagicMock()
        msg.tool_calls = [{"id": "1", "name": "test", "args": {}}]
        state = {"messages": [msg]}

        assert route_condition(state) == "tools"

    def test_routes_to_end_when_no_tool_calls(self):
        from ai_onboarding_brain.src.core.agent import route_condition
        from langgraph.graph import END

        msg = MagicMock()
        msg.tool_calls = []
        state = {"messages": [msg]}

        assert route_condition(state) == END

    def test_routes_to_end_when_no_tool_calls_attr(self):
        from ai_onboarding_brain.src.core.agent import route_condition
        from langgraph.graph import END

        msg = MagicMock(spec=[])  # No attributes at all
        state = {"messages": [msg]}

        assert route_condition(state) == END
