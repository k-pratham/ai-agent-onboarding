"""Shared fixtures for the HR Agentic Onboarding test suite."""

import os
import sys
import tempfile
from datetime import date
from unittest.mock import MagicMock, patch

import pytest

# Ensure project root is on sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# ── Config fixtures ─────────────────────────────────────────────────────

@pytest.fixture
def temp_config(tmp_path):
    """Creates a temporary dev.properties file and patches get_config to use it."""
    config_content = """\
[database]
db_uri=sqlite:///test.db

[ews]
server=https://mail.test.com/EWS/Exchange.asmx
username=testuser@example.com
password=testpass

[MCPSection]
MCP.HOST=127.0.0.1
MCP.PORT=8001
MCP.scheme=http

[LLMSection]
IP=localhost
PORT=8000
model_path=gpt-oss-20b
temperature=0
max_token=4096
stream=false
repitition_penalty=1.0
do_sample=false
content_type=application/json

[numarkdownSection]
IP=localhost
PORT=8000
temperature=0
model=/test/path/numarkdown-8b-thinking
prompt_file=/test/path/ocr_prompt.txt

[paths]
email_attachment_dir={attachment_dir}

[scheduler]
etl_schedule=30 16 * * *
mail_draft_schedule=30 3 * * *
inbox_read_schedule=30 15 * * *
""".format(attachment_dir=str(tmp_path / "attachments"))

    config_file = tmp_path / "dev.properties"
    config_file.write_text(config_content)

    import constants.common_functions as cf
    old_config = cf._config
    cf._config = None  # reset singleton

    with patch.object(cf, "_resolve_config_path", return_value=str(config_file)):
        cf.load_config(str(config_file))
        yield cf.get_config()

    cf._config = old_config


# ── Database fixtures ───────────────────────────────────────────────────

@pytest.fixture
def mock_db_session():
    """Returns a chainable SQLAlchemy session mock."""
    session = MagicMock()
    # Make query().filter().first() / .all() chainable
    session.query.return_value.filter.return_value.first.return_value = None
    session.query.return_value.filter.return_value.all.return_value = []
    session.query.return_value.filter.return_value.count.return_value = 0
    session.query.return_value.join.return_value.filter.return_value.all.return_value = []
    return session


# ── Model factory fixtures ──────────────────────────────────────────────

@pytest.fixture
def sample_candidate():
    """Returns a factory for CandidateInfo-like mock objects."""
    def _factory(
        candidate_id=1,
        cin="20240115_REF001",
        candidate_name="John Doe",
        candidate_type_id=2,
        personal_email_id="john.doe@email.com",
        previous_experience="3",
    ):
        candidate = MagicMock()
        candidate.CANDIDATE_ID = candidate_id
        candidate.CIN = cin
        candidate.CANDIDATE_NAME = candidate_name
        candidate.CANDIDATE_TYPE_ID = candidate_type_id
        candidate.PERSONAL_EMAIL_ID = personal_email_id
        candidate.PREVIOUS_EXPERIENCE = previous_experience
        return candidate
    return _factory


@pytest.fixture
def sample_job_tracker():
    """Returns a factory for JobTracker-like mock objects."""
    def _factory(
        job_id=1,
        job_type_id=1,
        candidate_id=1,
        status_id=1,
        action_date=None,
        draft_mail=None,
        human_action_required=0,
    ):
        job = MagicMock()
        job.JOB_ID = job_id
        job.JOB_TYPE_ID = job_type_id
        job.CANDIDATE_ID = candidate_id
        job.STATUS_ID = status_id
        job.ACTION_DATE = action_date or date.today()
        job.DRAFT_MAIL = draft_mail
        job.HUMAN_ACTION_REQUIRED = human_action_required
        return job
    return _factory


@pytest.fixture
def sample_document_tracker():
    """Returns a factory for DocumentTracker-like mock objects."""
    def _factory(
        tracker_id=1,
        candidate_id=1,
        document_type_id=1,
        status_id=1,
        comments=None,
        is_active=1,
    ):
        doc = MagicMock()
        doc.DOCUMENT_TRACKER_ID = tracker_id
        doc.CANDIDATE_ID = candidate_id
        doc.DOCUMENT_TYPE_ID = document_type_id
        doc.STATUS_ID = status_id
        doc.COMMENTS = comments
        doc.IS_ACTIVE = is_active
        return doc
    return _factory


# ── LLM Client fixtures ────────────────────────────────────────────────

@pytest.fixture
def mock_gpt_client():
    """Returns a mocked AphroditeAPIClient for gpt-oss-20b."""
    with patch("constants.llm_client.gpt_oss_client") as mock:
        mock.get_text.return_value = "Mocked LLM response"
        mock.call_api.return_value = {"content": "Mocked LLM response"}
        yield mock


@pytest.fixture
def mock_numarkdown_client():
    """Returns a mocked AphroditeAPIClient for numarkdown-8b-thinking."""
    with patch("constants.llm_client.numarkdown_client") as mock:
        mock.get_text.return_value = "CATEGORY: UNKNOWN\nCANDIDATE_NAME: NOT_FOUND\nDATE_OF_BIRTH: NOT_FOUND\nDOCUMENT_ID: NOT_FOUND"
        mock.call_api.return_value = {"content": "Mocked OCR response"}
        yield mock
