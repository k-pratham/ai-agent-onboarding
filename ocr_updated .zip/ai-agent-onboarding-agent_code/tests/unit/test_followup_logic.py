"""Tests for followup_logic.py — pure date calculation with 10 classes."""

from datetime import date, timedelta
from unittest.mock import patch

import pytest

from mcp_server.followup_classification.engine.followup_logic import calculate_followup_date


@pytest.fixture
def fixed_today():
    """Patches date.today() to return a fixed date for deterministic tests."""
    fixed = date(2026, 4, 15)
    with patch("mcp_server.followup_classification.engine.followup_logic.date") as mock_date:
        mock_date.today.return_value = fixed
        mock_date.side_effect = lambda *args, **kw: date(*args, **kw)
        yield fixed


class TestAllTenClassifications:
    def test_same_day_eod(self, fixed_today):
        assert calculate_followup_date("SAME_DAY_EOD") == fixed_today

    def test_next_day_eod(self, fixed_today):
        assert calculate_followup_date("NEXT_DAY_EOD") == fixed_today + timedelta(days=1)

    def test_short_term(self, fixed_today):
        assert calculate_followup_date("SHORT_TERM") == fixed_today + timedelta(days=3)

    def test_medium_term(self, fixed_today):
        assert calculate_followup_date("MEDIUM_TERM") == fixed_today + timedelta(days=6)

    def test_specific_date_with_extracted(self, fixed_today):
        target = date(2026, 5, 1)
        assert calculate_followup_date("SPECIFIC_DATE", target) == target

    def test_specific_date_without_extracted_falls_back(self, fixed_today):
        assert calculate_followup_date("SPECIFIC_DATE", None) == fixed_today + timedelta(days=3)

    def test_after_a_week(self, fixed_today):
        assert calculate_followup_date("AFTER_A_WEEK") == fixed_today + timedelta(days=8)

    def test_soon_asap(self, fixed_today):
        assert calculate_followup_date("SOON_ASAP") == fixed_today + timedelta(days=2)

    def test_refusal_returns_none(self):
        assert calculate_followup_date("REFUSAL") is None

    def test_unclear(self, fixed_today):
        assert calculate_followup_date("UNCLEAR") == fixed_today + timedelta(days=1)

    def test_undeterministic_returns_none(self):
        assert calculate_followup_date("UNDETERMINISTIC") is None


class TestEdgeCases:
    def test_unknown_classification_defaults_to_2_days(self, fixed_today):
        result = calculate_followup_date("TOTALLY_BOGUS")
        assert result == fixed_today + timedelta(days=2)

    def test_specific_date_in_the_past_is_still_returned(self, fixed_today):
        past_date = date(2020, 1, 1)
        result = calculate_followup_date("SPECIFIC_DATE", past_date)
        assert result == past_date
