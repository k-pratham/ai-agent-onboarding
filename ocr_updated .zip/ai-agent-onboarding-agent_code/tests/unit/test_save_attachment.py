"""Tests for save_attachment — file storage and DB tracking."""

import os
from unittest.mock import patch, MagicMock

import pytest

from mcp_server.save_attachment.engine.helper_func import store_attachment


class TestStoreAttachment:
    def test_stores_file_to_cin_directory(self, tmp_path):
        cin_dir = tmp_path / "CIN_001"
        cin_dir.mkdir()

        with patch("mcp_server.save_attachment.engine.helper_func.get_attachment_path", return_value=str(cin_dir)):
            path = store_attachment("CIN_001", "test_doc.pdf", b"PDF content here")

        assert os.path.exists(path)
        assert "test_doc.pdf" in path
        with open(path, "rb") as f:
            assert f.read() == b"PDF content here"

    def test_sanitizes_filename(self, tmp_path):
        cin_dir = tmp_path / "CIN_002"
        cin_dir.mkdir()

        with patch("mcp_server.save_attachment.engine.helper_func.get_attachment_path", return_value=str(cin_dir)):
            path = store_attachment("CIN_002", "../../../etc/passwd", b"test")

        # Should only use the basename
        assert "passwd" in os.path.basename(path)
        assert "../" not in path
