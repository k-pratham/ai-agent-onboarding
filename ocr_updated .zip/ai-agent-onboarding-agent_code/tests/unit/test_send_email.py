"""Tests for send_email — EWS dispatch and DB updates."""

from datetime import date
from unittest.mock import patch, MagicMock

import pytest


class TestUpdateJobStatusAfterSend:
    def test_updates_status_to_mail_sent(self, mock_db_session):
        from mcp_server.send_email.engine.db_engine import update_job_status_after_send
        from constants.constants import STATUS_MAIL_SENT_ID

        job = MagicMock()
        mock_db_session.query.return_value.filter.return_value.first.return_value = job

        result = update_job_status_after_send(mock_db_session, job_id=1, draft_content="Email body")

        assert job.STATUS_ID == STATUS_MAIL_SENT_ID
        assert job.HUMAN_ACTION_REQUIRED == 0
        assert job.HUMAN_ACTION == "Approved"
        assert job.DRAFT_MAIL == "Email body"

    def test_returns_none_when_job_not_found(self, mock_db_session):
        from mcp_server.send_email.engine.db_engine import update_job_status_after_send

        mock_db_session.query.return_value.filter.return_value.first.return_value = None
        result = update_job_status_after_send(mock_db_session, job_id=999, draft_content="body")
        assert result is None


class TestDispatchEmail:
    @patch("mcp_server.send_email.engine.mail_engine._get_ews_account")
    def test_sends_email_via_ews(self, mock_get_account):
        from mcp_server.send_email.engine.mail_engine import dispatch_email

        mock_account = MagicMock()
        mock_get_account.return_value = mock_account

        with patch("mcp_server.send_email.engine.mail_engine.Message") as mock_msg_class:
            mock_message = MagicMock()
            mock_msg_class.return_value = mock_message

            dispatch_email("candidate@test.com", "Subject", "Body text")

            mock_msg_class.assert_called_once()
            mock_message.send.assert_called_once()
