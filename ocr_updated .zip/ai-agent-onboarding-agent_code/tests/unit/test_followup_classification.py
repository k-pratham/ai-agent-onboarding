"""Tests for followup_classification — 10 classes + dual input."""

from datetime import date
from unittest.mock import patch, MagicMock

import pytest

from mcp_server.followup_classification.engine.helper_func import (
    classify_candidate_reply,
    _parse_classification_response,
    VALID_CLASSIFICATIONS,
)


class TestValidClassifications:
    def test_all_ten_classes_are_defined(self):
        expected = {
            "SAME_DAY_EOD", "NEXT_DAY_EOD", "SHORT_TERM", "MEDIUM_TERM",
            "SPECIFIC_DATE", "AFTER_A_WEEK", "SOON_ASAP", "REFUSAL",
            "UNCLEAR", "UNDETERMINISTIC",
        }
        assert VALID_CLASSIFICATIONS == expected


class TestParseClassificationResponse:
    def test_parses_valid_response(self):
        response = (
            "CLASSIFICATION: SHORT_TERM\n"
            "EXTRACTED_DATE: NO_DATE\n"
            "SUMMARY: Candidate will send in 3 days"
        )
        result = _parse_classification_response(response)
        assert result["classification"] == "SHORT_TERM"
        assert result["extracted_date"] is None
        assert result["summary"] == "Candidate will send in 3 days"

    def test_parses_specific_date(self):
        response = (
            "CLASSIFICATION: SPECIFIC_DATE\n"
            "EXTRACTED_DATE: 2026-05-01\n"
            "SUMMARY: Candidate will submit by May 1st"
        )
        result = _parse_classification_response(response)
        assert result["classification"] == "SPECIFIC_DATE"
        assert result["extracted_date"] == date(2026, 5, 1)

    def test_invalid_classification_defaults_to_unclear(self):
        response = "CLASSIFICATION: INVALID_CLASS\nEXTRACTED_DATE: NO_DATE\nSUMMARY: test"
        result = _parse_classification_response(response)
        assert result["classification"] == "UNCLEAR"

    def test_invalid_date_returns_none(self):
        response = "CLASSIFICATION: SPECIFIC_DATE\nEXTRACTED_DATE: not-a-date\nSUMMARY: test"
        result = _parse_classification_response(response)
        assert result["extracted_date"] is None

    def test_empty_response(self):
        result = _parse_classification_response("")
        assert result["classification"] == "UNCLEAR"
        assert result["extracted_date"] is None
        assert result["summary"] == ""

    @pytest.mark.parametrize("classification", list(VALID_CLASSIFICATIONS))
    def test_all_valid_classes_are_parsed(self, classification):
        response = f"CLASSIFICATION: {classification}\nEXTRACTED_DATE: NO_DATE\nSUMMARY: test"
        result = _parse_classification_response(response)
        assert result["classification"] == classification


class TestClassifyCandidateReply:
    @patch("mcp_server.followup_classification.engine.helper_func.gpt_oss_client")
    def test_sends_both_email_and_hr_comments(self, mock_client):
        mock_client.get_text.return_value = (
            "CLASSIFICATION: SOON_ASAP\nEXTRACTED_DATE: NO_DATE\nSUMMARY: Vague promise"
        )

        result = classify_candidate_reply("I'll send soon", "HR: candidate unresponsive")

        assert result["classification"] == "SOON_ASAP"
        # Verify the prompt included both inputs
        call_args = mock_client.get_text.call_args[0][0]
        prompt_text = call_args[0]["content"]
        assert "I'll send soon" in prompt_text
        assert "HR: candidate unresponsive" in prompt_text

    @patch("mcp_server.followup_classification.engine.helper_func.gpt_oss_client")
    def test_handles_empty_email_body(self, mock_client):
        mock_client.get_text.return_value = (
            "CLASSIFICATION: UNCLEAR\nEXTRACTED_DATE: NO_DATE\nSUMMARY: No email"
        )
        result = classify_candidate_reply("", "Some HR note")
        assert result["classification"] == "UNCLEAR"

    @patch("mcp_server.followup_classification.engine.helper_func.gpt_oss_client")
    def test_llm_failure_returns_unclear_default(self, mock_client):
        mock_client.get_text.side_effect = Exception("LLM unavailable")
        result = classify_candidate_reply("test email")
        assert result["classification"] == "UNCLEAR"
        assert result["extracted_date"] is None
