"""Tests for read_inbox — CIN extraction and email-to-CIN fallback."""

import pytest

from mcp_server.read_inbox.engine.helper_func import (
    _extract_cin_from_subject,
    _decode_header_value,
)


class TestExtractCinFromSubject:
    def test_extracts_cin_from_standard_format(self):
        assert _extract_cin_from_subject("Re: 20240115_REF001 Documents") == "20240115_REF001"

    def test_extracts_cin_with_keyword(self):
        assert _extract_cin_from_subject("Re: CIN: ABC123") == "ABC123"

    def test_extracts_cin_case_insensitive(self):
        assert _extract_cin_from_subject("Re: cin: XYZ789") == "XYZ789"

    def test_returns_none_for_no_cin(self):
        assert _extract_cin_from_subject("Just a regular email subject") is None

    def test_returns_none_for_empty_subject(self):
        assert _extract_cin_from_subject("") is None

    def test_returns_none_for_none_subject(self):
        assert _extract_cin_from_subject(None) is None


class TestDecodeHeaderValue:
    def test_decodes_plain_string(self):
        assert _decode_header_value("Hello World") == "Hello World"

    def test_returns_empty_for_none(self):
        assert _decode_header_value(None) == ""
