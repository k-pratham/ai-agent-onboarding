"""Tests for gap_analysis db_engine — document gap detection."""

from unittest.mock import MagicMock, patch

import pytest


class TestGetRequiredDocuments:
    def test_fetches_by_candidate_type(self, mock_db_session):
        from mcp_server.gap_analysis.engine.db_engine import get_required_documents_for_candidate

        doc1 = MagicMock()
        doc1.DOCUMENT_TYPE_ID = 1
        doc1.DOCUMENT_NAME = "Aadhaar Card"
        doc2 = MagicMock()
        doc2.DOCUMENT_TYPE_ID = 6
        doc2.DOCUMENT_NAME = "Experience Letter"

        mock_db_session.query.return_value.filter.return_value.all.return_value = [doc1, doc2]

        result = get_required_documents_for_candidate(mock_db_session, candidate_type_id=2)
        assert len(result) == 2


class TestGetTrackedDocuments:
    def test_returns_tracked_docs_for_candidate(self, mock_db_session):
        from mcp_server.gap_analysis.engine.db_engine import get_tracked_documents_for_candidate

        tracker = MagicMock()
        tracker.DOCUMENT_TYPE_ID = 1
        tracker.STATUS_ID = 5

        mock_db_session.query.return_value.filter.return_value.all.return_value = [tracker]

        result = get_tracked_documents_for_candidate(mock_db_session, candidate_id=1)
        assert len(result) == 1
        assert result[0].STATUS_ID == 5
