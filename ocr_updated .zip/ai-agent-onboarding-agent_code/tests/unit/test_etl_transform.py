"""Tests for ETL transform — hash generation and CIN creation."""

import pandas as pd
import pytest
from datetime import datetime

from etl_pipeline.transform.hash_generator import generate_row_hash
from etl_pipeline.transform.transformer import transform_candidate_data


class TestGenerateRowHash:
    def test_generates_sha256_hex(self):
        row = pd.Series({"name": "Alice", "age": 30})
        h = generate_row_hash(row)
        assert len(h) == 64  # SHA-256 hex digest length
        assert all(c in "0123456789abcdef" for c in h)

    def test_same_data_produces_same_hash(self):
        row1 = pd.Series({"a": "1", "b": "2"})
        row2 = pd.Series({"a": "1", "b": "2"})
        assert generate_row_hash(row1) == generate_row_hash(row2)

    def test_different_data_produces_different_hash(self):
        row1 = pd.Series({"a": "1"})
        row2 = pd.Series({"a": "2"})
        assert generate_row_hash(row1) != generate_row_hash(row2)

    def test_handles_nan_values(self):
        row = pd.Series({"a": float("nan"), "b": "ok"})
        h = generate_row_hash(row)
        assert isinstance(h, str) and len(h) == 64


class TestTransformCandidateData:
    def test_generates_cin_from_offer_date_and_ref(self):
        df = pd.DataFrame({
            "OFFER_RELEASE_DATE": [datetime(2024, 1, 15)],
            "REF_NO": ["REF001"],
            "NAME": ["Alice"],
        })
        result = transform_candidate_data({"Sheet1": df})
        assert result["CIN"].iloc[0] == "20240115_REF001"

    def test_generates_row_hash_column(self):
        df = pd.DataFrame({
            "OFFER_RELEASE_DATE": [datetime(2024, 1, 15)],
            "REF_NO": ["REF001"],
        })
        result = transform_candidate_data({"Sheet1": df})
        assert "ROW_HASH" in result.columns
        assert len(result["ROW_HASH"].iloc[0]) == 64

    def test_handles_missing_offer_date(self):
        df = pd.DataFrame({
            "OFFER_RELEASE_DATE": [None],
            "REF_NO": ["REF002"],
        })
        result = transform_candidate_data({"Sheet1": df})
        assert "UNKNOWN" in result["CIN"].iloc[0]

    def test_combines_multiple_sheets(self):
        df1 = pd.DataFrame({"OFFER_RELEASE_DATE": [datetime(2024, 1, 1)], "REF_NO": ["R1"]})
        df2 = pd.DataFrame({"OFFER_RELEASE_DATE": [datetime(2024, 2, 1)], "REF_NO": ["R2"]})
        result = transform_candidate_data({"Sheet1": df1, "Sheet2": df2})
        assert len(result) == 2
