"""Tests for draft_prepare — 3 cases: initial, follow-up, pending docs."""

from unittest.mock import patch, MagicMock

import pytest

from mcp_server.draft_prepare.engine.helper_func import (
    generate_initial_draft,
    generate_followup_draft,
    generate_pending_docs_draft,
    generate_and_save_draft,
    _fallback_draft,
)


class TestGenerateInitialDraft:
    def test_replaces_all_placeholders(self):
        template = "Dear [Candidate Name],\nSubmit: [Document List]\nCIN: [CIN]"
        draft = generate_initial_draft(
            candidate_name="Alice",
            document_list=["Aadhaar Card", "PAN Card"],
            cin="CIN_001",
            mail_template=template,
        )
        assert "Alice" in draft
        assert "- Aadhaar Card" in draft
        assert "- PAN Card" in draft
        assert "CIN_001" in draft
        assert "[Candidate Name]" not in draft
        assert "[Document List]" not in draft
        assert "[CIN]" not in draft

    def test_uses_default_template_when_none(self):
        draft = generate_initial_draft(
            candidate_name="Bob",
            document_list=["Degree Certificate"],
            cin="CIN_002",
        )
        assert "Bob" in draft
        assert "- Degree Certificate" in draft
        assert "CIN_002" in draft

    def test_empty_document_list(self):
        draft = generate_initial_draft("Test", [], "CIN_X")
        assert "Test" in draft


class TestGenerateFollowupDraft:
    @patch("mcp_server.draft_prepare.engine.helper_func.gpt_oss_client")
    def test_calls_llm_with_temperature_03(self, mock_client):
        mock_client.get_text.return_value = "Follow-up email draft text"

        draft = generate_followup_draft("Alice", ["PAN Card"], "CIN_001")

        assert draft == "Follow-up email draft text"
        mock_client.get_text.assert_called_once()
        _, kwargs = mock_client.get_text.call_args
        assert kwargs["temperature"] == 0.3

    @patch("mcp_server.draft_prepare.engine.helper_func.gpt_oss_client")
    def test_fallback_on_llm_failure(self, mock_client):
        mock_client.get_text.side_effect = Exception("LLM down")

        draft = generate_followup_draft("Alice", ["PAN Card"], "CIN_001")

        assert "Alice" in draft
        assert "PAN Card" in draft
        assert "CIN_001" in draft


class TestGeneratePendingDocsDraft:
    @patch("mcp_server.draft_prepare.engine.helper_func.gpt_oss_client")
    def test_calls_llm_with_temperature_03(self, mock_client):
        mock_client.get_text.return_value = "Pending docs draft"
        draft = generate_pending_docs_draft("Bob", ["Experience Letter"], "CIN_002")
        assert draft == "Pending docs draft"

    @patch("mcp_server.draft_prepare.engine.helper_func.gpt_oss_client")
    def test_fallback_on_llm_failure(self, mock_client):
        mock_client.get_text.side_effect = Exception("Timeout")
        draft = generate_pending_docs_draft("Bob", ["Experience Letter"], "CIN_002")
        assert "Bob" in draft
        assert "Experience Letter" in draft


class TestFallbackDraft:
    def test_contains_candidate_info(self):
        draft = _fallback_draft("Carol", ["Aadhaar Card", "PAN Card"], "CIN_003")
        assert "Carol" in draft
        assert "Aadhaar Card" in draft
        assert "PAN Card" in draft
        assert "CIN_003" in draft


class TestGenerateAndSaveDraft:
    @patch("mcp_server.draft_prepare.engine.helper_func._get_session")
    @patch("mcp_server.draft_prepare.engine.helper_func.get_candidate_by_cin")
    @patch("mcp_server.draft_prepare.engine.helper_func.get_job_type_info")
    @patch("mcp_server.draft_prepare.engine.helper_func.get_pending_docs_for_candidate")
    @patch("mcp_server.draft_prepare.engine.helper_func.get_mail_template")
    @patch("mcp_server.draft_prepare.engine.helper_func.save_draft_to_job_tracker")
    def test_case1_initial_mail_no_llm(
        self, mock_save, mock_template, mock_docs, mock_job_type, mock_candidate, mock_session
    ):
        session = MagicMock()
        mock_session.return_value = session

        # Mock job entry
        job = MagicMock()
        job.JOB_TYPE_ID = 1
        session.query.return_value.filter.return_value.first.return_value = job

        # Mock job type: documents_required
        job_type = MagicMock()
        job_type.JOB_SUBTYPE = "documents_required"
        mock_job_type.return_value = job_type

        # Mock candidate
        candidate = MagicMock()
        candidate.CANDIDATE_NAME = "Dave"
        candidate.CANDIDATE_TYPE_ID = 2
        candidate.CANDIDATE_ID = 10
        mock_candidate.return_value = candidate

        # Mock docs
        mock_docs.return_value = ["Aadhaar Card", "PAN Card"]

        # Mock template
        mock_template.return_value = "Dear [Candidate Name], docs: [Document List] CIN: [CIN]"

        draft = generate_and_save_draft("CIN_DAVE", 1)

        assert "Dave" in draft
        assert "Aadhaar Card" in draft
        mock_save.assert_called_once()

    @patch("mcp_server.draft_prepare.engine.helper_func._get_session")
    @patch("mcp_server.draft_prepare.engine.helper_func.get_candidate_by_cin")
    def test_candidate_not_found(self, mock_candidate, mock_session):
        mock_session.return_value = MagicMock()
        mock_session.return_value.query.return_value.filter.return_value.first.return_value = MagicMock(JOB_TYPE_ID=1)
        mock_candidate.return_value = None

        # Mock get_job_type_info to return something
        with patch("mcp_server.draft_prepare.engine.helper_func.get_job_type_info") as mock_jt:
            mock_jt.return_value = MagicMock(JOB_SUBTYPE="documents_required")
            result = generate_and_save_draft("NONEXISTENT", 1)

        assert "not found" in result.lower()
