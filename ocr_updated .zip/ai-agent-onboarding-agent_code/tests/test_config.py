"""Tests for constants/common_functions.py — config loading and helpers."""

import os
from unittest.mock import patch

import pytest


def test_load_config_reads_all_sections(temp_config):
    assert temp_config.has_section("database")
    assert temp_config.has_section("ews")
    assert temp_config.has_section("MCPSection")
    assert temp_config.has_section("LLMSection")
    assert temp_config.has_section("numarkdownSection")
    assert temp_config.has_section("paths")
    assert temp_config.has_section("scheduler")


def test_get_db_uri_returns_configured_value(temp_config):
    from constants.common_functions import get_db_uri
    assert get_db_uri() == "sqlite:///test.db"


def test_get_ews_config_returns_dict(temp_config):
    from constants.common_functions import get_ews_config
    ews = get_ews_config()
    assert ews["server"] == "https://mail.test.com/EWS/Exchange.asmx"
    assert ews["username"] == "testuser@example.com"
    assert ews["password"] == "testpass"


def test_get_mcp_config_returns_dict(temp_config):
    from constants.common_functions import get_mcp_config
    mcp = get_mcp_config()
    assert mcp["host"] == "127.0.0.1"
    assert mcp["port"] == 8001
    assert mcp["scheme"] == "http"


def test_get_llm_config_returns_all_fields(temp_config):
    from constants.common_functions import get_llm_config
    cfg = get_llm_config()
    assert cfg["ip"] == "localhost"
    assert cfg["port"] == 8000
    assert cfg["base_url"] == "http://localhost:8000/v1"
    assert cfg["model_path"] == "gpt-oss-20b"
    assert cfg["temperature"] == 0.0
    assert cfg["max_token"] == 4096
    assert cfg["stream"] is False
    assert cfg["repitition_penalty"] == 1.0
    assert cfg["do_sample"] is False
    assert cfg["content_type"] == "application/json"


def test_get_numarkdown_config_returns_all_fields(temp_config):
    from constants.common_functions import get_numarkdown_config
    cfg = get_numarkdown_config()
    assert cfg["ip"] == "localhost"
    assert cfg["port"] == 8000
    assert cfg["base_url"] == "http://localhost:8000/v1"
    assert cfg["temperature"] == 0.0
    assert cfg["model"] == "/test/path/numarkdown-8b-thinking"
    assert cfg["prompt_file"] == "/test/path/ocr_prompt.txt"


def test_get_attachment_path_creates_directory(temp_config, tmp_path):
    from constants.common_functions import get_attachment_path
    path = get_attachment_path("TEST_CIN_001")
    assert os.path.isdir(path)
    assert "TEST_CIN_001" in path


def test_get_config_singleton(temp_config):
    from constants.common_functions import get_config
    c1 = get_config()
    c2 = get_config()
    assert c1 is c2
