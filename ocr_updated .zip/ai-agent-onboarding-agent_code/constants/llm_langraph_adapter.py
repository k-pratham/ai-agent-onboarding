"""
AphroditeChatModel — LangGraph-compatible adapter wrapping AphroditeAPIClient.

Implements ``BaseChatModel`` so the Aphrodite on-prem LLM can be used as a
drop-in replacement for ``ChatOpenAI`` inside LangGraph StateGraph agents,
including full ``bind_tools()`` support for function / tool calling.
"""

import json
import logging
from typing import Any, Optional

from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import BaseTool

from constants.llm_client import AphroditeAPIClient

logger = logging.getLogger(__name__)


def _convert_tool_to_openai_schema(tool: BaseTool) -> dict:
    """Converts a LangChain tool into an OpenAI-format function schema."""
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description or "",
            "parameters": tool.args_schema.schema() if tool.args_schema else {"type": "object", "properties": {}},
        },
    }


def _langchain_messages_to_dicts(messages: list[BaseMessage]) -> list[dict]:
    """Converts LangChain message objects to OpenAI-format dicts."""
    result = []
    for msg in messages:
        if isinstance(msg, SystemMessage):
            result.append({"role": "system", "content": msg.content})
        elif isinstance(msg, HumanMessage):
            # Support multimodal content (list of text + image_url blocks)
            if isinstance(msg.content, list):
                result.append({"role": "user", "content": msg.content})
            else:
                result.append({"role": "user", "content": msg.content})
        elif isinstance(msg, AIMessage):
            entry: dict = {"role": "assistant"}
            if msg.content:
                entry["content"] = msg.content
            if getattr(msg, "tool_calls", None):
                entry["tool_calls"] = [
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": json.dumps(tc["args"]) if isinstance(tc["args"], dict) else tc["args"],
                        },
                    }
                    for tc in msg.tool_calls
                ]
                # OpenAI spec: content can be null when tool_calls are present
                if not msg.content:
                    entry["content"] = None
            else:
                entry.setdefault("content", "")
            result.append(entry)
        elif isinstance(msg, ToolMessage):
            result.append({
                "role": "tool",
                "tool_call_id": msg.tool_call_id,
                "content": msg.content if isinstance(msg.content, str) else json.dumps(msg.content),
            })
        else:
            # Fallback: treat as user message
            result.append({"role": "user", "content": str(msg.content)})
    return result


class AphroditeChatModel(BaseChatModel):
    """
    LangGraph-compatible chat model backed by AphroditeAPIClient.

    Usage::

        from constants.llm_langraph_adapter import AphroditeChatModel
        llm = AphroditeChatModel()  # uses gpt-oss-20b from [LLMSection]
        llm_with_tools = llm.bind_tools(AGENT_TOOLS)
    """

    temperature: Optional[float] = None
    max_tokens: Optional[int] = None

    # Private — set up in model_post_init
    _client: AphroditeAPIClient = None  # type: ignore[assignment]
    _bound_tools: list[dict] = []
    _tool_choice: Optional[str] = None

    class Config:
        arbitrary_types_allowed = True

    def model_post_init(self, __context: Any) -> None:
        self._client = AphroditeAPIClient.from_llm_config()
        self._bound_tools = []
        self._tool_choice = None

    # ── LangChain required properties ───────────────────────────────────
    @property
    def _llm_type(self) -> str:
        return "aphrodite-chat"

    @property
    def _identifying_params(self) -> dict:
        return {
            "model_name": self._client.model_name,
            "base_url": self._client.base_url,
        }

    # ── bind_tools ──────────────────────────────────────────────────────
    def bind_tools(
        self,
        tools: list,
        *,
        tool_choice: Optional[str] = None,
        **kwargs: Any,
    ) -> "AphroditeChatModel":
        """Returns a shallow copy with tools bound for function calling."""
        clone = self.model_copy()
        clone._client = self._client
        clone._bound_tools = [
            _convert_tool_to_openai_schema(t) if isinstance(t, BaseTool) else t
            for t in tools
        ]
        clone._tool_choice = tool_choice
        return clone

    # ── Core generation ─────────────────────────────────────────────────
    def _generate(
        self,
        messages: list[BaseMessage],
        stop: Optional[list[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        msg_dicts = _langchain_messages_to_dicts(messages)

        api_response = self._client.call_api(
            msg_dicts,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            tools=self._bound_tools or None,
            tool_choice=self._tool_choice,
        )

        ai_msg = self._response_to_ai_message(api_response)
        return ChatResult(generations=[ChatGeneration(message=ai_msg)])

    # ── Response conversion ─────────────────────────────────────────────
    @staticmethod
    def _response_to_ai_message(api_response: dict) -> AIMessage:
        """Converts the AphroditeAPIClient response dict to an AIMessage."""
        content = api_response.get("content") or ""
        tool_calls_raw = api_response.get("tool_calls", [])

        tool_calls = []
        for tc in tool_calls_raw:
            args = tc["function"]["arguments"]
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            tool_calls.append({
                "id": tc["id"],
                "name": tc["function"]["name"],
                "args": args,
            })

        return AIMessage(
            content=content,
            tool_calls=tool_calls if tool_calls else [],
        )
