import logging
from datetime import date, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from constants.common_functions import get_db_uri
from etl_pipeline.models.schema import CandidateInfo, JobTracker

logger = logging.getLogger(__name__)

_engine = None
_session_factory = None


def _get_engine():
    """Returns a singleton SQLAlchemy engine."""
    global _engine
    if _engine is None:
        _engine = create_engine(get_db_uri(), pool_pre_ping=True, pool_recycle=3600)
    return _engine


def _get_session() -> Session:
    """Returns a new SQLAlchemy session from the singleton factory."""
    global _session_factory
    if _session_factory is None:
        _session_factory = sessionmaker(bind=_get_engine())
    return _session_factory()


# FastAPI-compatible session dependency
SessionLocal = None  # Lazily initialised below


def _ensure_session_local():
    global SessionLocal
    if SessionLocal is None:
        SessionLocal = sessionmaker(
            autocommit=False, autoflush=False, bind=_get_engine()
        )
    return SessionLocal


def get_db():
    """FastAPI dependency that yields a DB session and closes it afterwards."""
    factory = _ensure_session_local()
    db = factory()
    try:
        yield db
    finally:
        db.close()


# ── Shared query helpers ─────────────────────────────────────────────────────

def get_candidate_by_cin(session: Session, cin: str):
    """Fetches a CandidateInfo record by CIN."""
    return session.query(CandidateInfo).filter(CandidateInfo.CIN == cin).first()


def create_followup_job(
    session: Session,
    candidate_id: int,
    job_type_id: int,
    days_offset: int = 2,
) -> JobTracker:
    """
    Creates a follow-up job entry in JOB_TRACKER.
    ACTION_DATE defaults to today + days_offset.
    """
    from constants.constants import STATUS_PENDING_ID

    today = date.today()
    new_job = JobTracker(
        JOB_TYPE_ID=job_type_id,
        CANDIDATE_ID=candidate_id,
        HUMAN_ACTION_REQUIRED=0,
        STATUS_ID=STATUS_PENDING_ID,
        ACTION_DATE=today + timedelta(days=days_offset),
        UPDATED_ON=today,
    )
    session.add(new_job)
    session.flush()
    return new_job
