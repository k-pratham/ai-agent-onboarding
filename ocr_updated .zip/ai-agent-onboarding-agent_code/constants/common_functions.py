import os
import logging
import configparser
from constants.constants import EMAIL_ATTACHMENT_DIR

logger = logging.getLogger(__name__)

_config = None


def _resolve_config_path() -> str:
    """Resolves the default config path relative to the project root."""
    # constants/ is one level below project root; config/ is at project root
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(project_root, "config", "dev.properties")


def load_config(config_path: str = None) -> configparser.ConfigParser:
    """
    Loads configuration from a .properties file using configparser.
    Defaults to config/dev.properties at the project root.
    """
    global _config
    if config_path is None:
        config_path = _resolve_config_path()
    parser = configparser.ConfigParser()
    parser.read(config_path)
    _config = parser
    logger.info(f"Configuration loaded from {config_path}")
    return parser


def get_config() -> configparser.ConfigParser:
    """Returns the already-loaded config, or loads from the default path."""
    global _config
    if _config is None:
        return load_config()
    return _config


def get_db_uri() -> str:
    """Returns the database URI from config."""
    cfg = get_config()
    return cfg.get("database", "db_uri", fallback=os.getenv(
        "DB_URI", "oracle+oracledb://user:pass@localhost:1521/?service_name=orcl"
    ))


def get_ews_config() -> dict:
    """Returns EWS (Exchange Web Services) configuration as a dict."""
    cfg = get_config()
    return {
        "server": cfg.get("ews", "server", fallback=os.getenv("EWS_SERVER", "https://mail.example.com/EWS/Exchange.asmx")),
        "username": cfg.get("ews", "username", fallback=os.getenv("EWS_USERNAME", "hr-inbox@example.com")),
        "password": cfg.get("ews", "password", fallback=os.getenv("EWS_PASSWORD", "")),
    }


def get_mcp_config() -> dict:
    """Returns MCP server configuration as a dict."""
    cfg = get_config()
    return {
        "host": cfg.get("MCPSection", "MCP.HOST", fallback=os.getenv("MCP_HOST", "0.0.0.0")),
        "port": int(cfg.get("MCPSection", "MCP.PORT", fallback=os.getenv("MCP_PORT", "8001"))),
        "scheme": cfg.get("MCPSection", "MCP.scheme", fallback=os.getenv("MCP_SCHEME", "http")),
    }


def get_llm_config() -> dict:
    """
    Returns LLM configuration for the gpt-oss-20b model from [LLMSection].
    Builds base_url from IP + PORT.
    """
    cfg = get_config()
    ip = cfg.get("LLMSection", "IP", fallback=os.getenv("LLM_IP", "localhost"))
    port = cfg.get("LLMSection", "PORT", fallback=os.getenv("LLM_PORT", "8000"))
    return {
        "ip": ip,
        "port": int(port),
        "base_url": f"http://{ip}:{port}/v1",
        "model_path": cfg.get("LLMSection", "model_path", fallback="gpt-oss-20b"),
        "temperature": float(cfg.get("LLMSection", "temperature", fallback="0")),
        "max_token": int(cfg.get("LLMSection", "max_token", fallback="4096")),
        "stream": cfg.get("LLMSection", "stream", fallback="false").lower() == "true",
        "repitition_penalty": float(cfg.get("LLMSection", "repitition_penalty", fallback="1.0")),
        "do_sample": cfg.get("LLMSection", "do_sample", fallback="false").lower() == "true",
        "content_type": cfg.get("LLMSection", "content_type", fallback="application/json"),
    }


def get_numarkdown_config() -> dict:
    """
    Returns config for the numarkdown-8b-thinking model from [numarkdownSection].
    Builds base_url from IP + PORT. Includes model path and prompt_file path.
    """
    cfg = get_config()
    ip = cfg.get("numarkdownSection", "IP", fallback=os.getenv("NUMARKDOWN_IP", "localhost"))
    port = cfg.get("numarkdownSection", "PORT", fallback=os.getenv("NUMARKDOWN_PORT", "8000"))
    return {
        "ip": ip,
        "port": int(port),
        "base_url": f"http://{ip}:{port}/v1",
        "temperature": float(cfg.get("numarkdownSection", "temperature", fallback="0")),
        "model": cfg.get("numarkdownSection", "model", fallback="/path/to/numarkdown-8b-thinking"),
        "prompt_file": cfg.get("numarkdownSection", "prompt_file", fallback="/path/to/prompts/ocr_prompt.txt"),
    }


def get_attachment_path(cin: str) -> str:
    """
    Returns the target folder path to store attachments for a specific candidate.
    Creates the directory if it does not exist.
    """
    cfg = get_config()
    base_dir = cfg.get("paths", "email_attachment_dir", fallback=EMAIL_ATTACHMENT_DIR)
    path = os.path.join(base_dir, cin)
    os.makedirs(path, exist_ok=True)
    return path
