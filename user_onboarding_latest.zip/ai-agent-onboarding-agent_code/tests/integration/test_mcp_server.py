"""Integration tests for MCP tool registration and tool function signatures."""

import inspect

import pytest


class TestMCPToolImports:
    """Verify that all MCP tool functions can be imported."""

    def test_read_inbox_tool_import(self):
        from mcp_server.read_inbox.tools.read_inbox import tool_read_inbox
        assert callable(tool_read_inbox)
        assert inspect.iscoroutinefunction(tool_read_inbox)

    def test_save_attachment_tool_import(self):
        from mcp_server.save_attachment.tools.save_attachment import tool_save_attachment
        assert callable(tool_save_attachment)

    def test_ocr_classification_tool_import(self):
        from mcp_server.ocr_classification.engine.helper_func import classify_document_type
        assert callable(classify_document_type)

    def test_draft_prepare_tool_import(self):
        from mcp_server.draft_prepare.tools.draft_prepare import tool_draft_prepare
        assert callable(tool_draft_prepare)
        assert inspect.iscoroutinefunction(tool_draft_prepare)

    def test_followup_classify_tool_import(self):
        from mcp_server.followup_classification.tools.followup_classify import tool_followup_classify
        assert callable(tool_followup_classify)
        assert inspect.iscoroutinefunction(tool_followup_classify)

    def test_send_email_tool_import(self):
        from mcp_server.send_email.engine.mail_engine import dispatch_email
        assert callable(dispatch_email)


class TestAgentToolRegistry:
    """Verify the LangGraph agent tool registry."""

    def test_agent_tools_list_has_six_tools(self):
        from ai_onboarding_brain.src.core.tools import AGENT_TOOLS
        assert len(AGENT_TOOLS) == 6

    def test_all_agent_tools_are_callable(self):
        from ai_onboarding_brain.src.core.tools import AGENT_TOOLS
        for tool in AGENT_TOOLS:
            assert callable(tool)

    def test_agent_tool_names(self):
        from ai_onboarding_brain.src.core.tools import AGENT_TOOLS
        names = {t.name for t in AGENT_TOOLS}
        expected = {
            "extract_and_validate_document",
            "analyze_gap_tracker",
            "validate_candidate_identity",
            "dispatch_followup_email",
            "prepare_draft_email",
            "save_candidate_attachment",
        }
        assert names == expected
