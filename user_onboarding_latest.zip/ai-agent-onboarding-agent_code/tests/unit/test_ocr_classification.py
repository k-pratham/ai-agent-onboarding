"""Tests for ocr_classification — document type classification."""

from unittest.mock import patch

import pytest

from mcp_server.ocr_classification.engine.helper_func import (
    classify_document_type,
    _parse_classification_response,
    VALID_CATEGORIES,
    CATEGORY_TO_FOLDER,
    CATEGORY_TO_DOC_NAME,
)


class TestParseClassificationResponse:
    def test_parses_complete_response(self):
        response = (
            "CATEGORY: AADHAAR\n"
            "CANDIDATE_NAME: John Doe\n"
            "DATE_OF_BIRTH: 1990-05-15\n"
            "DOCUMENT_ID: 1234 5678 9012"
        )
        result = _parse_classification_response(response)
        assert result["category"] == "AADHAAR"
        assert result["candidate_name"] == "John Doe"
        assert result["date_of_birth"] == "1990-05-15"
        assert result["document_id"] == "1234 5678 9012"

    def test_unknown_category_remains_unknown(self):
        response = "CATEGORY: INVALID_DOC\nCANDIDATE_NAME: NOT_FOUND"
        result = _parse_classification_response(response)
        assert result["category"] == "UNKNOWN"

    def test_not_found_values_become_none(self):
        response = (
            "CATEGORY: PAN\n"
            "CANDIDATE_NAME: NOT_FOUND\n"
            "DATE_OF_BIRTH: NOT_FOUND\n"
            "DOCUMENT_ID: NOT_FOUND"
        )
        result = _parse_classification_response(response)
        assert result["category"] == "PAN"
        assert result["candidate_name"] is None
        assert result["date_of_birth"] is None
        assert result["document_id"] is None

    def test_empty_response(self):
        result = _parse_classification_response("")
        assert result["category"] == "UNKNOWN"

    @pytest.mark.parametrize("category", [
        "AADHAAR", "PAN", "TENTH_MARKSHEET", "TWELFTH_MARKSHEET",
        "DEGREE_CERTIFICATE", "EXPERIENCE_LETTER", "RELIEVING_LETTER",
        "SALARY_SLIP", "RESUME", "OFFER_LETTER", "PASSPORT",
        "DRIVING_LICENSE", "BANK_STATEMENT", "UNKNOWN",
    ])
    def test_all_valid_categories_are_parsed(self, category):
        response = f"CATEGORY: {category}\nCANDIDATE_NAME: Test"
        result = _parse_classification_response(response)
        assert result["category"] == category


class TestCategoryMappings:
    def test_all_non_unknown_categories_have_folder(self):
        for cat in VALID_CATEGORIES - {"UNKNOWN"}:
            assert cat in CATEGORY_TO_FOLDER, f"{cat} missing from CATEGORY_TO_FOLDER"

    def test_folder_values_are_valid(self):
        valid_folders = {"personal_details", "education", "employment"}
        for folder in CATEGORY_TO_FOLDER.values():
            assert folder in valid_folders


class TestClassifyDocumentType:
    @patch("mcp_server.ocr_classification.engine.helper_func.numarkdown_client")
    def test_successful_classification(self, mock_client):
        mock_client.get_text.return_value = (
            "CATEGORY: PAN\n"
            "CANDIDATE_NAME: Jane Smith\n"
            "DATE_OF_BIRTH: 1995-03-20\n"
            "DOCUMENT_ID: ABCDE1234F"
        )
        result = classify_document_type("Some OCR text with PAN details")
        assert result["category"] == "PAN"
        assert result["candidate_name"] == "Jane Smith"

    @patch("mcp_server.ocr_classification.engine.helper_func.numarkdown_client")
    def test_llm_failure_returns_unknown(self, mock_client):
        mock_client.get_text.side_effect = Exception("Model unavailable")
        result = classify_document_type("some text")
        assert result["category"] == "UNKNOWN"
        assert result["candidate_name"] is None
