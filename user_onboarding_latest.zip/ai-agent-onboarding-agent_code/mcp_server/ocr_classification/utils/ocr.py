import os
import logging

logger = logging.getLogger(__name__)


def extract_text_from_file(file_path: str) -> str:
    """
    Extracts text from PDF or image files using PyMuPDF (fitz).
    For PDFs: extracts text from all pages.
    For images: extracts text using PyMuPDF's OCR-capable text extraction.
    """
    import fitz  # PyMuPDF

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = os.path.splitext(file_path)[1].lower()
    text = ""

    try:
        if ext == ".pdf":
            doc = fitz.open(file_path)
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                page_text = page.get_text("text")
                text += page_text + "\n"
            doc.close()
        elif ext in (".png", ".jpg", ".jpeg", ".tiff", ".bmp", ".gif"):
            # Open image as a single-page PDF for text extraction
            doc = fitz.open(file_path)
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                page_text = page.get_text("text")
                text += page_text + "\n"
            doc.close()
        else:
            # Attempt generic fitz open for other formats
            doc = fitz.open(file_path)
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                page_text = page.get_text("text")
                text += page_text + "\n"
            doc.close()
    except Exception as e:
        logger.error(f"Text extraction failed for {file_path}: {e}")
        raise

    text = text.strip()
    if not text:
        logger.warning(f"No text extracted from {file_path}. File may be a scanned image without OCR layer.")

    return text
