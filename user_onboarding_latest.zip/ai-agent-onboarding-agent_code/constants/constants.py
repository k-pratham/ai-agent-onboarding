import os

# Base directory for all email attachments
EMAIL_ATTACHMENT_DIR = os.getenv("EMAIL_ATTACHMENT_DIR", "./email_attachments")

# ── Status IDs (from STATUS_MASTER) ──────────────────────────────────────────
STATUS_PENDING_ID = 1
STATUS_MAIL_DRAFTED_ID = 2
STATUS_MAIL_SENT_ID = 3
STATUS_MAIL_RECEIVED_ID = 4
STATUS_VERIFIED_ID = 5
STATUS_REJECTED_ID = 6
STATUS_COMPLETED_ID = 7

# ── Job Type IDs (from JOB_TYPE_MASTER) ──────────────────────────────────────
JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID = 1   # mail_send / documents_required
JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID = 2       # mail_send / follow_up
JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID = 3    # mail_send / pending_documents
JOB_TYPE_MAIL_READ_ID = 4                 # mail_read / read_received_emails
JOB_TYPE_DOC_SAVE_ID = 5                  # doc_save / save_in_shared_path
JOB_TYPE_GAP_ANALYSIS_ID = 6              # gap_analysis / document_validation
JOB_TYPE_ATTACHMENTS_SAVED_ID = 7         # attachments_saved

# ── Candidate Type IDs (from CANDIDATE_TYPE_MASTER) ─────────────────────────
CANDIDATE_TYPE_FRESHER_ID = 1
CANDIDATE_TYPE_EXPERIENCE_ID = 2
CANDIDATE_TYPE_DEV_PARTNER_ID = 3

# ── Candidate Type Column Map ────────────────────────────────────────────────
CANDIDATE_TYPE_COLUMN_MAP = {
    CANDIDATE_TYPE_FRESHER_ID: "FRESHER",
    CANDIDATE_TYPE_EXPERIENCE_ID: "EXPERIENCE",
    CANDIDATE_TYPE_DEV_PARTNER_ID: "DEV_PARTNER",
}
