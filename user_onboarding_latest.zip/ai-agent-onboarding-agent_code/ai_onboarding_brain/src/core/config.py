from constants.common_functions import get_db_uri, get_ews_config
from constants.constants import (
    STATUS_PENDING_ID,
    STATUS_MAIL_DRAFTED_ID,
    STATUS_MAIL_SENT_ID,
    STATUS_MAIL_RECEIVED_ID,
    STATUS_VERIFIED_ID,
    STATUS_REJECTED_ID,
    STATUS_COMPLETED_ID,
    JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID,
    JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID,
    JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID,
    JOB_TYPE_MAIL_READ_ID,
    JOB_TYPE_DOC_SAVE_ID,
    JOB_TYPE_GAP_ANALYSIS_ID,
    JOB_TYPE_ATTACHMENTS_SAVED_ID,
)


class Settings:
    """Application settings loaded from config/dev.properties."""

    def __init__(self):
        self.DB_URI = get_db_uri()
        ews = get_ews_config()
        self.EWS_SERVER = ews["server"]
        self.EWS_USERNAME = ews["username"]
        self.EWS_PASSWORD = ews["password"]

        # Status IDs
        self.STATUS_PENDING_ID = STATUS_PENDING_ID
        self.STATUS_MAIL_DRAFTED_ID = STATUS_MAIL_DRAFTED_ID
        self.STATUS_MAIL_SENT_ID = STATUS_MAIL_SENT_ID
        self.STATUS_MAIL_RECEIVED_ID = STATUS_MAIL_RECEIVED_ID
        self.STATUS_VERIFIED_ID = STATUS_VERIFIED_ID
        self.STATUS_REJECTED_ID = STATUS_REJECTED_ID
        self.STATUS_COMPLETED_ID = STATUS_COMPLETED_ID

        # Job Type IDs
        self.JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID = JOB_TYPE_MAIL_SEND_DOCS_REQUIRED_ID
        self.JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID = JOB_TYPE_MAIL_SEND_FOLLOW_UP_ID
        self.JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID = JOB_TYPE_MAIL_SEND_PENDING_DOCS_ID
        self.JOB_TYPE_MAIL_READ_ID = JOB_TYPE_MAIL_READ_ID
        self.JOB_TYPE_DOC_SAVE_ID = JOB_TYPE_DOC_SAVE_ID
        self.JOB_TYPE_GAP_ANALYSIS_ID = JOB_TYPE_GAP_ANALYSIS_ID
        self.JOB_TYPE_ATTACHMENTS_SAVED_ID = JOB_TYPE_ATTACHMENTS_SAVED_ID


settings = Settings()

import logging
import sys

def get_logger(name: str) -> logging.Logger:
    """ Generates a universally formatted logger for any backend module. """
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        logger.addHandler(handler)
    return logger
